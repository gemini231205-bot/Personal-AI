import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  devIndicators: false,
  serverExternalPackages: ["pdf-parse", "mammoth"],
  experimental: {
    // File uploads are up to 15MB. Next.js proxy defaults to 10MB and would truncate them.
    proxyClientMaxBodySize: "16mb",
  },
};

export default nextConfig;
