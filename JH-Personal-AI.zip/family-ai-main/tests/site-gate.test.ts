import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { siteCookieValue, sitePasswordEnabled, verifySiteCookie } from "@/lib/auth/site-gate";

describe("private site password gate", () => {
  it("does not import node:crypto from the request-gate modules", () => {
    const gate = readFileSync("lib/auth/site-gate.ts", "utf8");
    const proxy = readFileSync("proxy.ts", "utf8");
    expect(gate).not.toMatch(/from ["']node:crypto["']/);
    expect(proxy).not.toMatch(/from ["']node:crypto["']/);
    expect(gate).not.toMatch(/\bcreateHash\b/);
    expect(proxy).not.toMatch(/\bcreateHash\b/);
    expect(gate).toMatch(/globalThis\.crypto/);
  });

  it("stores a hash in the cookie, never the password", async () => {
    const previousSite = process.env.SITE_PASSWORD;
    const previousPrivate = process.env.PRIVATE_SITE_PASSWORD;
    delete process.env.SITE_PASSWORD;
    process.env.PRIVATE_SITE_PASSWORD = "gate-secret-value";
    try {
      expect(sitePasswordEnabled()).toBe(true);
      const cookie = await siteCookieValue();
      expect(cookie).toMatch(/^[0-9a-f]{64}$/);
      expect(cookie).not.toContain("gate-secret-value");
      expect(await verifySiteCookie(cookie)).toBe(true);
      expect(await verifySiteCookie("gate-secret-value")).toBe(false);
      expect(await verifySiteCookie("deadbeef")).toBe(false);
    } finally {
      if (previousSite === undefined) delete process.env.SITE_PASSWORD;
      else process.env.SITE_PASSWORD = previousSite;
      if (previousPrivate === undefined) delete process.env.PRIVATE_SITE_PASSWORD;
      else process.env.PRIVATE_SITE_PASSWORD = previousPrivate;
    }
  });
});
