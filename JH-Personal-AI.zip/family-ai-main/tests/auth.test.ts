import { beforeAll, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { hashPassword, passwordPolicy, verifyPassword } from "@/lib/auth/password";
import { createSession, destroySession, hashToken } from "@/lib/auth/session";

const email = `auth-${Date.now()}@example.com`;

describe("auth", () => {
  let userId = "";

  beforeAll(async () => {
    const user = await prisma.user.create({
      data: { name: "테스터", email, passwordHash: await hashPassword("GoodPass1") },
    });
    userId = user.id;
  });

  it("hashes passwords and rejects weak ones", async () => {
    expect(passwordPolicy("short")).toBeTruthy();
    expect(passwordPolicy("GoodPass1")).toBeNull();
    const hash = await hashPassword("GoodPass1");
    expect(hash).not.toContain("GoodPass1");
    expect(await verifyPassword("GoodPass1", hash)).toBe(true);
    expect(await verifyPassword("wrong", hash)).toBe(false);
  });

  it("creates and destroys sessions", async () => {
    const { token } = await createSession(userId);
    const found = await prisma.session.findUnique({ where: { tokenHash: hashToken(token) } });
    expect(found?.userId).toBe(userId);
    await destroySession(token);
    const gone = await prisma.session.findUnique({ where: { tokenHash: hashToken(token) } });
    expect(gone).toBeNull();
  });
});
