import { beforeAll, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { hashPassword } from "@/lib/auth/password";
import { joinByCode } from "@/lib/family/invite";
import { inviteCode } from "@/lib/utils";
import { getMembership, requireMembership } from "@/lib/family/permissions";
import { runTool } from "@/lib/ai/tools";
import { personalSearch, familySearch } from "@/lib/search";
import { ApiError } from "@/lib/api";

describe("family + privacy", () => {
  let ownerId = "";
  let memberId = "";
  let outsiderId = "";
  let familyId = "";
  let otherFamilyId = "";
  let personalConv = "";
  let personalFileId = "";

  beforeAll(async () => {
    const suffix = Date.now();
    const owner = await prisma.user.create({
      data: { name: "A", email: `a-${suffix}@ex.com`, passwordHash: await hashPassword("GoodPass1") },
    });
    const member = await prisma.user.create({
      data: { name: "B", email: `b-${suffix}@ex.com`, passwordHash: await hashPassword("GoodPass1") },
    });
    const outsider = await prisma.user.create({
      data: { name: "C", email: `c-${suffix}@ex.com`, passwordHash: await hashPassword("GoodPass1") },
    });
    ownerId = owner.id;
    memberId = member.id;
    outsiderId = outsider.id;
    const code = inviteCode();
    const family = await prisma.family.create({
      data: {
        name: "A가족",
        inviteCode: code,
        createdById: owner.id,
        members: { create: { userId: owner.id, role: "OWNER" } },
        invites: { create: { code, createdById: owner.id } },
      },
    });
    familyId = family.id;
    await joinByCode(member.id, code);
    const other = await prisma.family.create({
      data: {
        name: "다른가족",
        inviteCode: inviteCode(),
        createdById: outsider.id,
        members: { create: { userId: outsider.id, role: "OWNER" } },
      },
    });
    otherFamilyId = other.id;
    const conv = await prisma.conversation.create({
      data: { title: "비밀 대화", scope: "PERSONAL", userId: owner.id },
    });
    personalConv = conv.id;
    const file = await prisma.personalFile.create({
      data: {
        userId: owner.id,
        originalName: "secret.txt",
        storedName: "secret.txt",
        mimeType: "text/plain",
        size: 4,
      },
    });
    personalFileId = file.id;
    await prisma.personalMemory.create({
      data: { userId: owner.id, title: "비밀", content: "개인만 아는 프로젝트" },
    });
    await prisma.familyMemory.create({
      data: { familyId, createdById: owner.id, title: "공유", content: "일요일 저녁 식사" },
    });
  });

  it("creates family with owner and lets others join", async () => {
    const mem = await getMembership(memberId, familyId);
    expect(mem?.role).toBe("MEMBER");
  });

  it("blocks outsider from another family", async () => {
    await expect(requireMembership(outsiderId, familyId)).rejects.toBeInstanceOf(ApiError);
    await expect(requireMembership(ownerId, otherFamilyId)).rejects.toBeInstanceOf(ApiError);
  });

  it("blocks personal conversation and file IDOR", async () => {
    const conv = await prisma.conversation.findUnique({ where: { id: personalConv } });
    expect(conv?.userId).not.toBe(memberId);
    const file = await prisma.personalFile.findUnique({ where: { id: personalFileId } });
    expect(file?.userId).not.toBe(memberId);
  });

  it("Family AI cannot read personal memory or files", async () => {
    await expect(
      runTool("searchPersonalMemory", { userId: ownerId, familyId, scope: "family" }, { query: "비밀" }),
    ).rejects.toBeInstanceOf(ApiError);
    await expect(
      runTool("searchPersonalFiles", { userId: ownerId, familyId, scope: "family" }, { query: "secret" }),
    ).rejects.toBeInstanceOf(ApiError);
    const familyMem = await runTool("searchFamilyMemory", { userId: memberId, familyId, scope: "family" }, { query: "일요일" });
    expect(familyMem).toContain("일요일");
    expect(familyMem).not.toContain("개인만 아는 프로젝트");
  });

  it("search stays inside permission scope", async () => {
    const personal = await personalSearch(ownerId, "비밀");
    expect(personal.memories.length).toBeGreaterThan(0);
    const otherPersonal = await personalSearch(memberId, "비밀");
    expect(otherPersonal.memories.length).toBe(0);
    const family = await familySearch(memberId, familyId, "일요일");
    expect(family.memories.length).toBeGreaterThan(0);
    await expect(familySearch(outsiderId, familyId, "일요일")).rejects.toBeInstanceOf(ApiError);
  });
});
