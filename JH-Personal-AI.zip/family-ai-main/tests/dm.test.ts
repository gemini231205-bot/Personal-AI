import { beforeAll, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { hashPassword } from "@/lib/auth/password";
import { createInvite, joinByCode } from "@/lib/family/invite";
import { inviteCode } from "@/lib/utils";
import { openOrCreateDm, peerOf, requireDmAccess } from "@/lib/dm/access";
import { runTool } from "@/lib/ai/tools";
import { ApiError } from "@/lib/api";

describe("family members + DM isolation", () => {
  let a = "";
  let b = "";
  let c = "";
  let d = "";
  let familyId = "";
  let otherFamilyId = "";
  let outsider = "";
  let dmId = "";

  beforeAll(async () => {
    const suffix = Date.now();
    const mk = async (name: string) =>
      prisma.user.create({
        data: { name, email: `${name}-${suffix}@ex.com`, passwordHash: await hashPassword("GoodPass1") },
      });
    const [ua, ub, uc, ud, uo] = await Promise.all([
      mk("A"),
      mk("B"),
      mk("C"),
      mk("D"),
      mk("Out"),
    ]);
    a = ua.id;
    b = ub.id;
    c = uc.id;
    d = ud.id;
    outsider = uo.id;
    const code = inviteCode();
    const family = await prisma.family.create({
      data: {
        name: "확장가족",
        inviteCode: code,
        createdById: a,
        members: { create: { userId: a, role: "OWNER" } },
        invites: { create: { code, createdById: a, expiresAt: new Date(Date.now() + 86400000) } },
      },
    });
    familyId = family.id;
    await joinByCode(b, code);
    await joinByCode(c, code);
    const other = await prisma.family.create({
      data: {
        name: "다른집",
        inviteCode: inviteCode(),
        createdById: outsider,
        members: { create: { userId: outsider, role: "OWNER" } },
      },
    });
    otherFamilyId = other.id;
    await prisma.personalMemory.create({
      data: { userId: a, title: "A비밀", content: "B는 보면 안 됨" },
    });
    const dm = await openOrCreateDm(a, b);
    dmId = dm.id;
    await prisma.message.create({
      data: { conversationId: dmId, authorId: a, role: "USER", content: "B에게만" },
    });
  });

  it("TEST 1: A can DM B", async () => {
    const access = await requireDmAccess(a, dmId);
    expect(access.members.map((m) => m.userId).sort()).toEqual([a, b].sort());
    const msg = await prisma.message.findFirst({ where: { conversationId: dmId, authorId: a } });
    expect(msg?.content).toBe("B에게만");
  });

  it("TEST 2: C cannot read A-B DM", async () => {
    await expect(requireDmAccess(c, dmId)).rejects.toBeInstanceOf(ApiError);
    const leaked = await prisma.conversation.findFirst({
      where: { id: dmId, members: { some: { userId: c } } },
    });
    expect(leaked).toBeNull();
  });

  it("TEST 3: opening DM again reuses the same conversation", async () => {
    const again = await openOrCreateDm(b, a);
    expect(again.id).toBe(dmId);
    const count = await prisma.conversation.count({
      where: { familyId, scope: "DIRECT", members: { some: { userId: a } } },
    });
    expect(count).toBe(1);
  });

  it("TEST 4/10: family can grow from 3 to 4+ members", async () => {
    const before = await prisma.familyMember.count({ where: { familyId } });
    expect(before).toBe(3);
    const invite = await createInvite({ familyId, createdById: a, expiresInDays: 3 });
    await joinByCode(d, invite.code);
    const after = await prisma.familyMember.count({ where: { familyId } });
    expect(after).toBe(4);
    expect(after).not.toBe(3);
  });

  it("TEST 5: new member D can use Family Room", async () => {
    const mem = await prisma.familyMember.findUnique({
      where: { familyId_userId: { familyId, userId: d } },
    });
    expect(mem).toBeTruthy();
    const room = await prisma.familyMessage.create({
      data: { familyId, authorId: d, content: "D가 가족방에 왔습니다" },
    });
    const visible = await prisma.familyMessage.findMany({ where: { familyId } });
    expect(visible.some((m) => m.id === room.id)).toBe(true);
  });

  it("TEST 6: D can start a DM with A", async () => {
    const dm = await openOrCreateDm(d, a);
    expect(dm.members).toHaveLength(2);
    expect(dm.id).not.toBe(dmId);
    await requireDmAccess(a, dm.id);
    await requireDmAccess(d, dm.id);
  });

  it("TEST 7: B cannot use A's personal memory via Family AI tools", async () => {
    await expect(
      runTool("searchPersonalMemory", { userId: a, familyId, scope: "family" }, { query: "비밀" }),
    ).rejects.toBeInstanceOf(ApiError);
    const bPersonal = await runTool(
      "searchPersonalMemory",
      { userId: b, familyId, scope: "personal" },
      { query: "비밀" },
    );
    expect(bPersonal).not.toContain("B는 보면 안 됨");
  });

  it("TEST 8: Family AI room search never returns DM text", async () => {
    const familyCtx = await runTool(
      "searchFamilyMessages",
      { userId: c, familyId, scope: "family" },
      { query: "B에게만" },
    );
    expect(familyCtx).not.toContain("B에게만");
  });

  it("TEST 9: other family cannot open this DM by id", async () => {
    await expect(requireDmAccess(outsider, dmId)).rejects.toBeInstanceOf(ApiError);
    expect(otherFamilyId).toBeTruthy();
  });

  it("rejects expired invites and duplicate family joins", async () => {
    const expired = await prisma.familyInvite.create({
      data: {
        familyId,
        code: inviteCode(),
        createdById: a,
        expiresAt: new Date(Date.now() - 1000),
      },
    });
    const extra = await prisma.user.create({
      data: {
        name: "E",
        email: `e-${Date.now()}@ex.com`,
        passwordHash: await hashPassword("GoodPass1"),
      },
    });
    await expect(joinByCode(extra.id, expired.code)).rejects.toBeInstanceOf(ApiError);
    await expect(joinByCode(b, expired.code)).rejects.toBeInstanceOf(ApiError);
  });

  it("cannot DM yourself or a non-member", async () => {
    await expect(openOrCreateDm(a, a)).rejects.toBeInstanceOf(ApiError);
    await expect(openOrCreateDm(a, outsider)).rejects.toBeInstanceOf(ApiError);
  });

  it("DM peer payload never includes password hashes", async () => {
    const conversation = await requireDmAccess(a, dmId);
    const peer = peerOf(a, conversation.members);
    expect(peer).toMatchObject({ id: b, name: expect.any(String) });
    expect(peer).not.toHaveProperty("passwordHash");
    expect(peer).not.toHaveProperty("email");
  });
});
