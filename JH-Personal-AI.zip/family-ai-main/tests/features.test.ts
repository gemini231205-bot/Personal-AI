import { beforeAll, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { hashPassword } from "@/lib/auth/password";
import { inviteCode } from "@/lib/utils";
import { LocalProvider } from "@/lib/ai/local";
import { getAIProvider } from "@/lib/ai/provider";
import { chunkText, localEmbed } from "@/lib/rag";
import { assertSafeUpload } from "@/lib/security/sanitize";

describe("calendar shopping poll files ai", () => {
  let userId = "";
  let familyId = "";
  let listId = "";

  beforeAll(async () => {
    const user = await prisma.user.create({
      data: { name: "기능", email: `feat-${Date.now()}@ex.com`, passwordHash: await hashPassword("GoodPass1") },
    });
    userId = user.id;
    const family = await prisma.family.create({
      data: {
        name: "기능가족",
        inviteCode: inviteCode(),
        createdById: user.id,
        members: { create: { userId: user.id, role: "OWNER" } },
        shoppingLists: { create: { name: "장보기" } },
      },
    });
    familyId = family.id;
    const list = await prisma.shoppingList.findFirst({ where: { familyId } });
    listId = list!.id;
  });

  it("creates updates and deletes calendar events", async () => {
    const event = await prisma.calendarEvent.create({
      data: {
        familyId,
        title: "저녁",
        startsAt: new Date(),
        endsAt: new Date(Date.now() + 3600000),
        createdById: userId,
      },
    });
    await prisma.calendarEvent.update({ where: { id: event.id }, data: { title: "가족 저녁" } });
    const updated = await prisma.calendarEvent.findUnique({ where: { id: event.id } });
    expect(updated?.title).toBe("가족 저녁");
    await prisma.calendarEvent.delete({ where: { id: event.id } });
    expect(await prisma.calendarEvent.findUnique({ where: { id: event.id } })).toBeNull();
  });

  it("adds and completes shopping items", async () => {
    const item = await prisma.shoppingItem.create({ data: { listId, name: "우유", quantity: 2 } });
    await prisma.shoppingItem.update({ where: { id: item.id }, data: { completed: true } });
    const done = await prisma.shoppingItem.findUnique({ where: { id: item.id } });
    expect(done?.completed).toBe(true);
  });

  it("creates a poll and prevents duplicate votes", async () => {
    const poll = await prisma.poll.create({
      data: {
        familyId,
        question: "어디 갈까?",
        createdById: userId,
        options: { create: [{ label: "한강" }, { label: "집" }] },
      },
      include: { options: true },
    });
    await prisma.pollVote.create({ data: { pollId: poll.id, optionId: poll.options[0].id, userId } });
    await expect(
      prisma.pollVote.create({ data: { pollId: poll.id, optionId: poll.options[0].id, userId } }),
    ).rejects.toThrow();
  });

  it("validates uploads and indexes chunks", () => {
    expect(() => assertSafeUpload({ name: "a.exe", type: "application/x-msdownload", size: 10 }, 1000)).toThrow();
    expect(assertSafeUpload({ name: "note.txt", type: "text/plain", size: 10 }, 1000)).toBe("txt");
    expect(chunkText("hello world ".repeat(80)).length).toBeGreaterThan(1);
    expect(localEmbed("가족 여행").length).toBe(64);
  });

  it("local provider streams and provider factory falls back", async () => {
    const local = new LocalProvider();
    const result = await local.chat({ messages: [{ role: "user", content: "오늘 저녁 뭐 먹지?" }] });
    expect(result.content.length).toBeGreaterThan(10);
    expect(result.provider).toBe("local");
    const active = getAIProvider();
    expect(["local", "openai", "gemini"]).toContain(active.name);
  });

  it("labels My AI and Family AI separately even if the prompt mentions 가족", async () => {
    const local = new LocalProvider();
    const personal = await local.chat({
      system: "당신은 한 사람의 개인 AI, My AI 입니다. 다른 가족 구성원의 개인 데이터는 쓰지 마세요.",
      messages: [{ role: "user", content: "안녕" }],
    });
    expect(personal.content).toContain("🧠 My AI");
    expect(personal.content).not.toContain("✨ Family AI");
    const family = await local.chat({
      system: "당신은 가족의 공유 AI, Family AI 입니다.",
      messages: [{ role: "user", content: "일정 정리해줘" }],
    });
    expect(family.content).toContain("✨ Family AI");
  });
});
