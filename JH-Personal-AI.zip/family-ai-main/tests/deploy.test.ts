import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

describe("deploy readiness", () => {
  it("keeps env secret files out of git", () => {
    const ignore = readFileSync(".gitignore", "utf8");
    expect(ignore).toMatch(/^\.env$/m);
    expect(ignore).toMatch(/^\.env\.local$/m);
    expect(ignore).toMatch(/^\.vercel$/m);
    expect(ignore).toMatch(/^\.data\/$/m);
  });

  it("uses PostgreSQL and a Vercel query-engine target", () => {
    const schema = readFileSync("prisma/schema.prisma", "utf8");
    expect(schema).toMatch(/provider\s*=\s*"postgresql"/);
    expect(schema).toMatch(/rhel-openssl-3\.0\.x/);
    expect(schema).toMatch(/directUrl\s*=\s*env\("DIRECT_DATABASE_URL"\)/);
  });

  it("refuses a localhost DATABASE_URL during the Vercel build", () => {
    const build = readFileSync("scripts/vercel-build.mjs", "utf8");
    expect(build).toMatch(/localhost\|127\\.0\\.0\\.1/);
    expect(build).toMatch(/prisma", "migrate", "deploy"/);
    expect(build).toMatch(/AUTH_SECRET/);
  });

  it("blocks local disk storage on Vercel", () => {
    const storage = readFileSync("lib/storage/index.ts", "utf8");
    expect(storage).toMatch(/process\.env\.VERCEL/);
    expect(storage).toMatch(/STORAGE_PROVIDER=blob/);
  });

  it("does not import node:crypto from the request gate", () => {
    const gate = readFileSync("lib/auth/site-gate.ts", "utf8");
    const proxy = readFileSync("proxy.ts", "utf8");
    expect(gate).not.toMatch(/from ["']node:crypto["']/);
    expect(proxy).not.toMatch(/from ["']node:crypto["']/);
  });
});
