import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("Demo1234!", 12);
  await prisma.user.deleteMany({ where: { email: { in: ["demo@example.com", "dad@example.com", "jiho@example.com"] } } });

  const mom = await prisma.user.create({
    data: { name: "엄마", email: "demo@example.com", passwordHash, avatarColor: "amber" },
  });
  const dad = await prisma.user.create({
    data: { name: "아빠", email: "dad@example.com", passwordHash, avatarColor: "teal" },
  });
  const jiho = await prisma.user.create({
    data: { name: "지호", email: "jiho@example.com", passwordHash, avatarColor: "violet" },
  });

  const family = await prisma.family.create({
    data: {
      name: "우리 가족",
      inviteCode: "FAMILY-8K4P2",
      createdById: mom.id,
      members: {
        create: [
          { userId: mom.id, role: "OWNER" },
          { userId: dad.id, role: "ADMIN" },
          { userId: jiho.id, role: "MEMBER" },
        ],
      },
      invites: { create: { code: "FAMILY-8K4P2", createdById: mom.id } },
      shoppingLists: { create: { name: "장보기" } },
    },
  });

  await prisma.familyMemory.createMany({
    data: [
      { familyId: family.id, createdById: mom.id, title: "일요일 저녁", content: "우리 가족은 매주 일요일 저녁에 함께 식사한다." },
      { familyId: family.id, createdById: dad.id, title: "아빠 입맛", content: "아빠는 매운 음식을 좋아한다." },
      { familyId: family.id, createdById: jiho.id, title: "여름 여행", content: "이번 여름 가족여행은 제주도였다." },
    ],
  });

  await prisma.personalMemory.create({
    data: {
      userId: mom.id,
      title: "개인 프로젝트",
      content: "주말에 개인 소설 원고를 다듬고 있다. 이 내용은 가족에게 공유하지 않는다.",
    },
  });

  const start = new Date();
  start.setHours(19, 0, 0, 0);
  const end = new Date(start);
  end.setHours(21, 0, 0, 0);
  await prisma.calendarEvent.create({
    data: {
      familyId: family.id,
      title: "가족 저녁",
      location: "집",
      startsAt: start,
      endsAt: end,
      createdById: mom.id,
    },
  });

  const list = await prisma.shoppingList.findFirst({ where: { familyId: family.id } });
  if (list) {
    await prisma.shoppingItem.createMany({
      data: [
        { listId: list.id, name: "우유", quantity: 2, category: "유제품" },
        { listId: list.id, name: "계란", quantity: 1, category: "냉장" },
        { listId: list.id, name: "라면", quantity: 3, category: "가공" },
      ],
    });
  }

  await prisma.poll.create({
    data: {
      familyId: family.id,
      question: "이번 주말 어디 갈까?",
      createdById: mom.id,
      options: { create: [{ label: "한강" }, { label: "영화" }, { label: "놀이공원" }, { label: "집" }] },
    },
  });

  await prisma.familyMessage.createMany({
    data: [
      { familyId: family.id, authorId: mom.id, content: "오늘 저녁 뭐 먹지?" },
      { familyId: family.id, authorId: dad.id, content: "나는 김치찌개 괜찮아" },
      { familyId: family.id, authorId: jiho.id, content: "나도 좋아" },
    ],
  });

  console.log("Seeded demo family. demo@example.com / Demo1234! (development only)");
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
