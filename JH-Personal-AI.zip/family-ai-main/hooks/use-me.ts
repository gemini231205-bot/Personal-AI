"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/client";

export type Me = {
  user: {
    id: string;
    name: string;
    email: string;
    avatarColor: string;
    bio: string | null;
    timezone: string;
    shareFamilyContext: boolean;
    allowPersonalFileAnalysis: boolean;
  } | null;
  family: { id: string; name: string; inviteCode: string; role: string } | null;
  ai?: { configured: string; active: string; model: string; warning?: string | null };
};

export function useMe() {
  const [data, setData] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const reload = async () => {
    try {
      const next = await api<Me>("/api/auth/me");
      setData(next);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void reload();
  }, []);
  return { data, loading, reload };
}
