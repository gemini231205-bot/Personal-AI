"use client";

import { useEffect, useRef } from "react";

/**
 * EventSource that reconnects after Vercel function timeouts or network drops.
 */
export function useEventSource(
  url: string | null,
  handlers: Record<string, (data: string) => void>,
) {
  const handlersRef = useRef(handlers);

  useEffect(() => {
    handlersRef.current = handlers;
  }, [handlers]);

  useEffect(() => {
    if (!url) return;
    let es: EventSource | null = null;
    let retry: ReturnType<typeof setTimeout> | undefined;
    let stopped = false;

    const connect = () => {
      if (stopped) return;
      const current = new EventSource(url);
      es = current;
      const types = Object.keys(handlersRef.current);
      const listener = (event: Event) => {
        const message = event as MessageEvent;
        handlersRef.current[message.type]?.(message.data);
      };
      for (const type of types) {
        current.addEventListener(type, listener);
      }
      current.onerror = () => {
        current.close();
        if (!stopped) retry = setTimeout(connect, 2000);
      };
    };

    connect();
    return () => {
      stopped = true;
      if (retry) clearTimeout(retry);
      es?.close();
    };
  }, [url]);
}
