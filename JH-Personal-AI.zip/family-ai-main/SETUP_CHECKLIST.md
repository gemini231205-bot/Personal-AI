# Family AI — 직접 할 일

## 로컬

- [ ] Node.js 20+ 설치
- [ ] PostgreSQL 준비 후 데이터베이스 생성
- [ ] `.env.example`을 `.env`로 복사
- [ ] `DATABASE_URL` 입력
- [ ] `AUTH_SECRET`에 긴 무작위 문자열 입력
- [ ] (선택) `OPENAI_API_KEY` 입력, `AI_PROVIDER=openai`
- [ ] (선택) `WEB_SEARCH_API_KEY` 입력, `WEB_SEARCH_PROVIDER=tavily`
- [ ] 사이트 전체 입장 게이트가 필요하면 `PRIVATE_SITE_PASSWORD` 입력
- [ ] `npm install`
- [ ] `npx prisma migrate dev`
- [ ] `npm run db:seed`  (원하면 데모 가족)
- [ ] `npm run dev`

키가 없어도 LocalProvider로 가족 데이터 기능은 동작합니다.

프로덕션에 데모 비밀번호(`Demo1234!`)를 쓰지 마세요.

## Vercel 배포

로컬 `127.0.0.1` PostgreSQL과 `STORAGE_PROVIDER=local`은 배포에서 사용할 수 없습니다.

- [ ] Neon / Supabase / Vercel Postgres에서 호스팅 DB 생성
- [ ] Vercel 프로젝트에 Blob store 생성 (`STORAGE_PROVIDER=blob`)
- [ ] 아래 환경 변수를 Production / Preview에 입력
  - `DATABASE_URL`
  - `DIRECT_DATABASE_URL`
  - `AUTH_SECRET`
  - `PRIVATE_SITE_PASSWORD`
  - `AI_PROVIDER=openai`
  - `OPENAI_API_KEY`
  - `OPENAI_MODEL`
  - `WEB_SEARCH_PROVIDER=tavily`
  - `WEB_SEARCH_API_KEY`
  - `STORAGE_PROVIDER=blob`
  - `BLOB_READ_WRITE_TOKEN` (Blob store를 프로젝트에 연결하면 자동일 수 있음)
  - `NEXT_PUBLIC_APP_URL`
- [ ] `npx vercel login`
- [ ] `npx vercel link`
- [ ] `npx vercel --prod`
