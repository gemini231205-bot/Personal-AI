import { Prisma } from "@prisma/client";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { logServerError } from "@/lib/security/log";

export type ApiErrorCode =
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "VALIDATION"
  | "RATE_LIMITED"
  | "CONFLICT"
  | "AI_UNAVAILABLE"
  | "CONFIG"
  | "FILE_INVALID"
  | "INTERNAL";

export class ApiError extends Error {
  constructor(
    public code: ApiErrorCode,
    message: string,
    public status = 400,
  ) {
    super(message);
  }
}

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

export function fail(code: ApiErrorCode, message: string, status = 400) {
  return NextResponse.json(
    { success: false, error: { code, message } },
    { status },
  );
}

export function handleError(error: unknown) {
  if (error instanceof ApiError) {
    return fail(error.code, error.message, error.status);
  }
  if (error instanceof ZodError) {
    const message = error.issues[0]?.message ?? "입력값을 확인하세요.";
    return fail("VALIDATION", message, 422);
  }
  if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
    return fail("CONFLICT", "이미 사용 중인 값입니다.", 409);
  }
  if (
    error instanceof Prisma.PrismaClientInitializationError ||
    error instanceof Prisma.PrismaClientRustPanicError ||
    (error instanceof Error && /can't reach database server|p1001|p1017/i.test(error.message))
  ) {
    logServerError("database", error);
    return fail(
      "CONFIG",
      "데이터베이스에 연결할 수 없습니다. Next.js는 .env.local의 DATABASE_URL을 .env보다 우선합니다. 호스트가 이 서버에서 열려 있는지 확인하세요.",
      503,
    );
  }
  logServerError("api", error);
  return fail("INTERNAL", "요청을 처리하지 못했습니다.", 500);
}

export function unauthorized(message = "로그인이 필요합니다.") {
  return new ApiError("UNAUTHORIZED", message, 401);
}

export function forbidden(message = "접근 권한이 없습니다.") {
  return new ApiError("FORBIDDEN", message, 403);
}

export function notFound(message = "찾을 수 없습니다.") {
  return new ApiError("NOT_FOUND", message, 404);
}
