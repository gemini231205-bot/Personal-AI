import { prisma } from "@/lib/db";
import { loadEnv } from "@/lib/env";

const COST: Record<string, { in: number; out: number }> = {
  "gpt-4o-mini": { in: 0.15 / 1_000_000, out: 0.6 / 1_000_000 },
  "gpt-4o": { in: 2.5 / 1_000_000, out: 10 / 1_000_000 },
  "gemini-2.0-flash": { in: 0.1 / 1_000_000, out: 0.4 / 1_000_000 },
  "family-local-v1": { in: 0, out: 0 },
};

export async function logUsage(input: {
  userId: string;
  familyId?: string | null;
  provider: string;
  model: string;
  inputTokens: number;
  outputTokens: number;
}) {
  const rates = COST[input.model] ?? COST[loadEnv().OPENAI_MODEL] ?? { in: 0, out: 0 };
  const estimatedCost = input.inputTokens * rates.in + input.outputTokens * rates.out;
  await prisma.aIUsageLog.create({
    data: {
      userId: input.userId,
      familyId: input.familyId ?? undefined,
      provider: input.provider,
      model: input.model,
      inputTokens: input.inputTokens,
      outputTokens: input.outputTokens,
      estimatedCost,
    },
  });
  return estimatedCost;
}
