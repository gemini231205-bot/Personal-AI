import { getAIProvider } from "./provider";

import {
  familySystemPrompt,
  gatherToolContext,
  personalSystemPrompt,
} from "./router";

import { logUsage } from "./usage";

import type {
  ChatMessage,
  Citation,
  ToolContext,
} from "./types";

import {
  formatCitations,
  ragContextBlock,
  semanticSearch,
  semanticSearchPersonalFile,
  type RagHit,
} from "@/lib/rag";

import {
  webSearch,
  formatWebBlock,
} from "@/lib/web-search";

type WebDecision = {
  search: boolean;
  query?: string;
};

/*
 * AI에게 웹 검색 필요 여부를 판단하게 한다.
 *
 * 여기서는 provider.chat()을 사용하기 때문에
 * 현재 사용 중인 AI provider 구조를 그대로 활용한다.
 */
async function decideWebSearch(
  question: string,
): Promise<WebDecision> {
  const provider = getAIProvider();

  const result = await provider.chat({
    system: `
당신은 웹 검색 여부를 판단하는 라우터입니다.

사용자의 질문을 보고 외부 웹 검색이 필요한지 판단하세요.

웹 검색이 필요한 경우:
- 현재 정보
- 최신 뉴스
- 오늘/지금/최근 정보
- 날씨
- 맛집
- 장소/주변 시설
- 여행 정보
- 상품 가격
- 영업시간
- 최신 스포츠 정보
- 현재 인물/직책
- 인터넷에서 확인해야 하는 사실
- 사용자가 인터넷 정보를 요구하는 경우

웹 검색이 필요하지 않은 경우:
- 일반적인 지식 설명
- 수학 계산
- 글쓰기
- 번역
- 사용자가 제공한 내용의 요약
- 개인적인 대화
- 일반적인 코딩 설명

반드시 아래 JSON 하나만 출력하세요.

{
  "search": true 또는 false,
  "query": "검색할 검색어"
}

search가 false이면 query는 빈 문자열로 하세요.
`,
    messages: [
      {
        role: "user",
        content: question,
      },
    ],
  });

  try {
    const text = result.content
      .trim()
      .replace(/^```json\s*/i, "")
      .replace(/```$/i, "")
      .trim();

    const parsed =
      JSON.parse(text) as WebDecision;

    return {
      search: Boolean(parsed.search),
      query:
        typeof parsed.query === "string"
          ? parsed.query.trim()
          : undefined,
    };
  } catch {
    /*
     * 판단 결과를 파싱하지 못하면
     * 안전하게 검색하지 않는다.
     */
    return {
      search: false,
    };
  }
}

export async function orchestrateChat(input: {
  question: string;
  history: ChatMessage[];
  ctx: ToolContext;
  fileId?: string;
}) {
  const provider = getAIProvider();

  const {
    kind,
    blocks,
  } = await gatherToolContext(
    input.question,
    input.ctx,
  );

  /*
   * -----------------------------------------
   * 1. 파일 / 내부 데이터 검색
   * -----------------------------------------
   */

  let fileHits: RagHit[] = [];

  if (input.ctx.scope === "personal") {
    if (input.fileId) {
      fileHits =
        await semanticSearchPersonalFile(
          input.fileId,
          input.ctx.userId,
          input.question,
          3,
        );
    } else {
      fileHits = await semanticSearch(
        `personal_file:${input.ctx.userId}`,
        input.question,
        3,
      );
    }
  } else if (input.ctx.familyId) {
    fileHits = await semanticSearch(
      `family_file:${input.ctx.familyId}`,
      input.question,
      3,
    );
  }

  const citations =
    formatCitations(fileHits);

  const fileContext =
    ragContextBlock(fileHits);

  /*
   * -----------------------------------------
   * 2. AI가 웹 검색 필요 여부 판단
   * -----------------------------------------
   */

  let webBlock = "";

  try {
    const decision =
      await decideWebSearch(
        input.question,
      );

    if (
      decision.search &&
      decision.query
    ) {
      const hits =
        await webSearch(
          decision.query,
        );

      webBlock =
        formatWebBlock(hits);
    }
  } catch {
    /*
     * 웹 검색 판단/검색이 실패해도
     * 일반 AI 대화는 계속한다.
     */
    webBlock = "";
  }

  /*
   * -----------------------------------------
   * 3. 최종 AI system prompt 구성
   * -----------------------------------------
   */

  const system = [
    input.ctx.scope === "personal"
      ? personalSystemPrompt()
      : familySystemPrompt(),

    `의도: ${kind}`,

    blocks.join("\n\n"),

    fileContext,

    webBlock,
  ]
    .filter(Boolean)
    .join("\n\n");

  return {
    provider,
    system,
    citations: citations as Citation[],
    kind,
  };
}

export async function runAndLog(input: {
  userId: string;
  familyId?: string | null;
  question: string;
  history: ChatMessage[];
  ctx: ToolContext;
  fileId?: string;
}) {
  const {
    provider,
    system,
    citations,
  } = await orchestrateChat({
    question: input.question,
    history: input.history,
    ctx: input.ctx,
    fileId: input.fileId,
  });

  const result =
    await provider.chat({
      system,
      messages: [
        ...input.history,
        {
          role: "user",
          content: input.question,
        },
      ],
    });

  await logUsage({
    userId: input.userId,
    familyId: input.familyId,
    provider: result.provider,
    model: result.model,
    inputTokens: result.inputTokens,
    outputTokens: result.outputTokens,
  });

  return {
    ...result,
    citations,
  };
}
