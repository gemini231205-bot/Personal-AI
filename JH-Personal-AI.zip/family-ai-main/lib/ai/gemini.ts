import { GoogleGenerativeAI } from "@google/generative-ai";
import { loadEnv } from "@/lib/env";
import { ApiError } from "@/lib/api";
import { estimateTokens } from "@/lib/utils";
import type { AIProvider, ChatRequest, ChatResult } from "./types";

export class GeminiProvider implements AIProvider {
  readonly name = "gemini";

  get model() {
    return loadEnv().GEMINI_MODEL;
  }

  private modelClient() {
    const key = loadEnv().GEMINI_API_KEY;
    if (!key) {
      throw new ApiError("AI_UNAVAILABLE", "GEMINI_API_KEY가 설정되지 않았습니다.", 503);
    }
    return new GoogleGenerativeAI(key).getGenerativeModel({ model: this.model });
  }

  private prompt(request: ChatRequest) {
    const history = request.messages
      .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
      .join("\n\n");
    return `${request.system ? `${request.system}\n\n` : ""}${history}`;
  }

  async chat(request: ChatRequest): Promise<ChatResult> {
    try {
      const result = await this.modelClient().generateContent(this.prompt(request));
      const content = result.response.text();
      return {
        content,
        inputTokens: estimateTokens(this.prompt(request)),
        outputTokens: estimateTokens(content),
        provider: this.name,
        model: this.model,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Gemini 요청에 실패했습니다.";
      throw new ApiError(
        "AI_UNAVAILABLE",
        message.toLowerCase().includes("api") ? "Gemini API 키가 올바르지 않습니다." : "Gemini 응답을 받지 못했습니다.",
        503,
      );
    }
  }

  async *streamChat(request: ChatRequest) {
    let content = "";
    try {
      const stream = await this.modelClient().generateContentStream(this.prompt(request));
      for await (const chunk of stream.stream) {
        const delta = chunk.text();
        if (delta) {
          content += delta;
          yield delta;
        }
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : "Gemini 스트리밍에 실패했습니다.";
      throw new ApiError(
        "AI_UNAVAILABLE",
        message.toLowerCase().includes("api") ? "Gemini API 키가 올바르지 않습니다." : "Gemini 응답을 받지 못했습니다.",
        503,
      );
    }
    return {
      content,
      inputTokens: estimateTokens(this.prompt(request)),
      outputTokens: estimateTokens(content),
      provider: this.name,
      model: this.model,
    };
  }

  async embed(text: string) {
    const { localEmbed } = await import("@/lib/rag");
    try {
      const key = loadEnv().GEMINI_API_KEY;
      if (!key) return localEmbed(text);
      const gen = new GoogleGenerativeAI(key);
      const model = gen.getGenerativeModel({ model: "text-embedding-004" });
      const res = await model.embedContent(text.slice(0, 8000));
      return res.embedding.values ?? localEmbed(text);
    } catch {
      return localEmbed(text);
    }
  }
}
