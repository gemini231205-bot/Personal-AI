export type ChatRole = "user" | "assistant" | "system";

export type ChatMessage = {
  role: ChatRole;
  content: string;
};

export type Citation = {
  source: string;
  page?: number;
  excerpt?: string;
};

export type ChatRequest = {
  messages: ChatMessage[];
  system?: string;
  temperature?: number;
};

export type ChatResult = {
  content: string;
  inputTokens: number;
  outputTokens: number;
  provider: string;
  model: string;
  citations?: Citation[];
};

export interface AIProvider {
  readonly name: string;
  readonly model: string;
  chat(request: ChatRequest): Promise<ChatResult>;
  streamChat(request: ChatRequest): AsyncGenerator<string, ChatResult, unknown>;
  embed(text: string): Promise<number[]>;
}

export type AiScope = "personal" | "family";

export type ToolName =
  | "searchPersonalMemory"
  | "searchFamilyMemory"
  | "searchPersonalFiles"
  | "searchFamilyFiles"
  | "getCalendarEvents"
  | "createCalendarEvent"
  | "getShoppingList"
  | "addShoppingItem"
  | "completeShoppingItem"
  | "searchFamilyMessages"
  | "webSearch";

export type ToolContext = {
  userId: string;
  familyId?: string | null;
  scope: AiScope;
  allowSharedPersonal?: boolean;
};
