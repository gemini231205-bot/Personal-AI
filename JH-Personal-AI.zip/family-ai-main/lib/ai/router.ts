import type {
  AiScope,
  ToolContext,
  ToolName,
} from "./types";

import { runTool } from "./tools";

export type RouteKind =
  | "chat"
  | "rag"
  | "calendar"
  | "shopping"
  | "family_chat"
  | "meeting"
  | "meal"
  | "web";

/*
 * 기존 키워드 기반 라우팅은 그대로 유지하되,
 * 웹 검색은 여기서 판단하지 않는다.
 *
 * 웹 검색 필요 여부는 orchestrateChat()에서
 * AI가 별도로 판단한다.
 */
export function classifyIntent(
  question: string,
  scope: AiScope,
): {
  kind: RouteKind;
  tools: ToolName[];
} {
  const q = question.toLowerCase();

  if (
    /일정|캘린더|언제|가능한 날|약속/.test(q)
  ) {
    return {
      kind: "calendar",
      tools: [
        "getCalendarEvents",
        "searchFamilyMemory",
      ],
    };
  }

  if (
    /쇼핑|장보|사야|마트|우유|계란/.test(q)
  ) {
    return {
      kind: "shopping",
      tools: [
        "getShoppingList",
        "searchFamilyMemory",
      ],
    };
  }

  if (
    /회의|정리해|결정사항|할 일|미해결/.test(q)
  ) {
    return {
      kind: "meeting",
      tools: [
        "searchFamilyMessages",
        "searchFamilyMemory",
        "getCalendarEvents",
      ],
    };
  }

  if (
    /저녁|메뉴|밥|먹을|식사|레시피/.test(q)
  ) {
    return {
      kind: "meal",
      tools: [
        "searchFamilyMemory",
        "getShoppingList",
        "searchFamilyMessages",
      ],
    };
  }

  if (
    /파일|문서|pdf|첨부|계획서/.test(q)
  ) {
    return {
      kind: "rag",
      tools:
        scope === "family"
          ? [
              "searchFamilyFiles",
              "searchFamilyMemory",
            ]
          : [
              "searchPersonalFiles",
              "searchPersonalMemory",
            ],
    };
  }

  if (scope === "family") {
    return {
      kind: "family_chat",
      tools: [
        "searchFamilyMemory",
        "searchFamilyMessages",
      ],
    };
  }

  return {
    kind: "chat",
    tools: ["searchPersonalMemory"],
  };
}

export async function gatherToolContext(
  question: string,
  ctx: ToolContext,
) {
  const { kind, tools } =
    classifyIntent(question, ctx.scope);

  const allowed = tools.filter((tool) => {
    if (
      ctx.scope === "personal" &&
      (
        tool.startsWith("searchFamily") ||
        tool.startsWith("getCalendar") ||
        tool.startsWith("getShopping") ||
        tool.startsWith("addShopping") ||
        tool.startsWith("complete") ||
        tool === "searchFamilyMessages" ||
        tool === "createCalendarEvent"
      )
    ) {
      return (
        ctx.allowSharedPersonal === true &&
        tool === "searchFamilyMemory"
      );
    }

    if (
      ctx.scope === "family" &&
      (
        tool === "searchPersonalMemory" ||
        tool === "searchPersonalFiles"
      )
    ) {
      return false;
    }

    return true;
  });

  const blocks: string[] = [];

  for (const tool of allowed) {
    try {
      blocks.push(
        await runTool(
          tool,
          ctx,
          { query: question },
        ),
      );
    } catch {
      // 기존 구조처럼 개별 도구 실패는
      // 전체 AI 응답을 중단시키지 않는다.
    }
  }

  return {
    kind,
    blocks,
  };
}

export function personalSystemPrompt() {
  return [
    "당신은 한 사람의 개인 AI, My AI 입니다.",
    "이 사용자의 개인 대화, 개인 메모리, 개인 파일만 사용하세요.",
    "다른 가족 구성원의 개인 데이터나 명시적으로 공유되지 않은 가족 민감정보는 사용하지 마세요.",
    "민감한 정보(계좌, 비밀번호, 주민번호)는 기억하지 마세요.",
    "파일 근거가 있으면 '출처: 파일명 / 페이지' 형식으로 밝히세요.",
    "웹 검색 결과가 제공되면 최신 외부 정보로 활용하세요.",
    "한국어로 따뜻하고 정확하게 답하세요.",
  ].join("\n");
}

export function familySystemPrompt() {
  return [
    "당신은 가족의 공유 AI, Family AI 입니다.",
    "접근 가능한 데이터: Family Room, 가족 메모리, 가족 파일, 일정, 쇼핑, 투표, 위시리스트, 사용자가 명시적으로 공유한 정보.",
    "절대 다른 구성원의 개인 대화/개인 메모리/개인 파일을 읽지 마세요.",
    "웹 검색 결과와 가족 내부 데이터를 반드시 구분해서 표시하세요.",
    "파일 근거가 있으면 '출처: 파일명 / 페이지' 형식으로 밝히세요.",
    "회의 정리 요청이면 결정사항 / 할 일 / 담당자 / 기한 / 미해결 형식을 쓰세요.",
    "메뉴 제안 시 공유된 선호만 쓰고, 개인 건강정보를 추측하거나 저장하지 마세요.",
    "웹 검색 결과가 제공되면 최신 외부 정보로 활용하세요.",
    "한국어로 가족이 함께 읽기 쉽게 답하세요.",
  ].join("\n");
}
