import { estimateTokens } from "@/lib/utils";
import { loadEnv } from "@/lib/env";
import { localEmbed } from "@/lib/rag";
import type { AIProvider, ChatRequest, ChatResult } from "./types";

function lastUser(request: ChatRequest) {
  return [...request.messages].reverse().find((m) => m.role === "user")?.content ?? "";
}

function compose(request: ChatRequest) {
  const question = lastUser(request);
  const system = request.system ?? "";
  const dataBlocks = system
    .split("\n\n")
    .filter((block) => block.includes("[") && block.length > 20)
    .slice(0, 8);

  const lines: string[] = [];
  const isFamily = system.includes("Family AI") && !system.includes("My AI");
  if (isFamily) {
    lines.push("✨ Family AI 로컬 엔진이 공유된 가족 데이터만 보고 답합니다. 개인 비공개 기억/파일은 사용하지 않습니다.");
  } else {
    lines.push("🧠 My AI 로컬 엔진이 당신의 개인 데이터만 보고 답합니다.");
  }

  if (!question.trim()) {
    lines.push("질문을 입력해 주세요.");
    return lines.join("\n\n");
  }

  if (dataBlocks.length) {
    lines.push("관련 데이터:");
    for (const block of dataBlocks) {
      lines.push(block.slice(0, 900));
    }
    lines.push("");
    lines.push(`질문: ${question}`);
    lines.push("");
    lines.push("정리:");
    if (/일정|캘린더|언제|가능한/.test(question)) {
      lines.push("- 위에 있는 가족 일정을 기준으로 겹치는 시간과 빈 시간을 확인하세요.");
    } else if (/쇼핑|장보|사야|우유|계란/.test(question)) {
      lines.push("- 장보기 목록을 카테고리별로 묶고, 빠진 항목이 있으면 제안하세요.");
    } else if (/회의|정리|결정|할 일/.test(question)) {
      lines.push("## 결정사항\n- 대화에서 합의된 내용을 적습니다.\n\n## 할 일\n- 담당자와 기한을 분리합니다.\n\n## 미해결\n- 아직 정하지 못한 항목을 남깁니다.");
    } else if (/저녁|메뉴|밥|먹을/.test(question)) {
      lines.push("- 가족 공유 선호(매운맛, 일요일 저녁 등)만 사용합니다. 개인 건강정보는 쓰지 않습니다.");
    } else {
      lines.push("- 검색된 가족/개인 범위 데이터만 근거로 짧게 답합니다.");
    }
  } else {
    lines.push(`질문: ${question}`);
    lines.push("");
    lines.push("연결된 클라우드 모델이 없어 로컬 엔진으로 답합니다. 일정·쇼핑·파일·메모리를 함께 물어보면 더 정확한 정리를 할 수 있습니다.");
    lines.push("OpenAI 또는 Gemini 키를 넣으면 같은 화면에서 더 풍부한 문장 생성이 이어집니다. 키는 서버에만 저장됩니다.");
  }
  return lines.join("\n");
}

async function* streamText(text: string): AsyncGenerator<string, ChatResult, unknown> {
  const env = loadEnv();
  const words = text.split(/(\s+)/);
  let content = "";
  for (const word of words) {
    content += word;
    yield word;
  }
  return {
    content,
    inputTokens: estimateTokens(text),
    outputTokens: estimateTokens(content),
    provider: "local",
    model: env.LOCAL_MODEL,
  };
}

export class LocalProvider implements AIProvider {
  readonly name = "local";
  get model() {
    return loadEnv().LOCAL_MODEL;
  }

  async chat(request: ChatRequest): Promise<ChatResult> {
    const content = compose(request);
    return {
      content,
      inputTokens: estimateTokens(request.messages.map((m) => m.content).join("\n")),
      outputTokens: estimateTokens(content),
      provider: this.name,
      model: this.model,
    };
  }

  async *streamChat(request: ChatRequest) {
    const content = compose(request);
    yield* streamText(content);
    return {
      content,
      inputTokens: estimateTokens(request.messages.map((m) => m.content).join("\n")),
      outputTokens: estimateTokens(content),
      provider: this.name,
      model: this.model,
    };
  }

  async embed(text: string) {
    return localEmbed(text);
  }
}
