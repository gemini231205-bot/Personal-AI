import { prisma } from "@/lib/db";
import { endOfWeek, startOfWeek } from "@/lib/utils";
import { forbidden } from "@/lib/api";
import { requireMembership } from "@/lib/family/permissions";
import { ragContextBlock, semanticSearch } from "@/lib/rag";
import { formatWebBlock, webSearch } from "@/lib/web-search";
import type { ToolContext, ToolName } from "./types";

export const TOOL_DEFS: { name: ToolName; description: string; familyOnly?: boolean; personalOnly?: boolean }[] = [
  { name: "searchPersonalMemory", description: "내 개인 메모리 검색", personalOnly: true },
  { name: "searchFamilyMemory", description: "가족 공유 메모리 검색", familyOnly: true },
  { name: "searchPersonalFiles", description: "내 개인 파일 RAG 검색", personalOnly: true },
  { name: "searchFamilyFiles", description: "가족 공유 파일 RAG 검색", familyOnly: true },
  { name: "getCalendarEvents", description: "가족 일정 조회", familyOnly: true },
  { name: "createCalendarEvent", description: "가족 일정 생성", familyOnly: true },
  { name: "getShoppingList", description: "장보기 목록 조회", familyOnly: true },
  { name: "addShoppingItem", description: "장보기 항목 추가", familyOnly: true },
  { name: "completeShoppingItem", description: "장보기 항목 완료", familyOnly: true },
  { name: "searchFamilyMessages", description: "가족방 대화 검색", familyOnly: true },
  { name: "webSearch", description: "외부 웹 검색" },
];

async function assertFamily(ctx: ToolContext) {
  if (!ctx.familyId) throw forbidden("가족 도구는 가족 범위에서만 사용할 수 있습니다.");
  await requireMembership(ctx.userId, ctx.familyId);
  return ctx.familyId;
}

export async function runTool(
  name: ToolName,
  ctx: ToolContext,
  args: Record<string, string> = {},
): Promise<string> {
  switch (name) {
    case "searchPersonalMemory": {
      if (ctx.scope !== "personal") {
        throw forbidden("개인 메모리는 Family AI가 자동으로 읽을 수 없습니다.");
      }
      const q = args.query ?? "";
      const rows = await prisma.personalMemory.findMany({
        where: {
          userId: ctx.userId,
          OR: q
            ? [
                { title: { contains: q, mode: "insensitive" } },
                { content: { contains: q, mode: "insensitive" } },
              ]
            : undefined,
        },
        orderBy: { updatedAt: "desc" },
        take: 8,
      });
      return rows.length
        ? `[개인 메모리]\n${rows.map((r) => `- ${r.title}: ${r.content}`).join("\n")}`
        : "[개인 메모리]\n일치하는 기억이 없습니다.";
    }
    case "searchFamilyMemory": {
      const familyId = await assertFamily(ctx);
      const q = args.query ?? "";
      const rows = await prisma.familyMemory.findMany({
        where: {
          familyId,
          OR: q
            ? [
                { title: { contains: q, mode: "insensitive" } },
                { content: { contains: q, mode: "insensitive" } },
              ]
            : undefined,
        },
        take: 8,
        orderBy: { updatedAt: "desc" },
      });
      const shared = ctx.allowSharedPersonal
        ? await prisma.personalMemory.findMany({
            where: {
              sharedToFamily: true,
              user: { memberships: { some: { familyId } } },
            },
            take: 5,
          })
        : [];
      const sharedBlock = shared.length
        ? `\n[명시적으로 공유된 개인 메모리]\n${shared.map((r) => `- ${r.title}: ${r.content}`).join("\n")}`
        : "";
      return (
        (rows.length
          ? `[가족 메모리]\n${rows.map((r) => `- ${r.title}: ${r.content}`).join("\n")}`
          : "[가족 메모리]\n공유된 기억이 없습니다.") + sharedBlock
      );
    }
    case "searchPersonalFiles": {
      if (ctx.scope !== "personal") throw forbidden("개인 파일은 Family AI가 읽을 수 없습니다.");
      const hits = await semanticSearch(`personal_file:${ctx.userId}`, args.query ?? "", 5);
      return ragContextBlock(hits) || "[개인 파일]\n관련 파일을 찾지 못했습니다.";
    }
    case "searchFamilyFiles": {
      const familyId = await assertFamily(ctx);
      const hits = await semanticSearch(`family_file:${familyId}`, args.query ?? "", 5);
      return ragContextBlock(hits) || "[가족 파일]\n관련 공유 파일을 찾지 못했습니다.";
    }
    case "getCalendarEvents": {
      const familyId = await assertFamily(ctx);
      const from = args.from ? new Date(args.from) : startOfWeek();
      const to = args.to ? new Date(args.to) : endOfWeek();
      const events = await prisma.calendarEvent.findMany({
        where: { familyId, startsAt: { gte: from, lte: to } },
        include: { attendees: { include: { user: true } } },
        orderBy: { startsAt: "asc" },
      });
      return events.length
        ? `[가족 일정]\n${events
            .map(
              (e) =>
                `- ${e.title} (${e.startsAt.toISOString()} ~ ${e.endsAt.toISOString()})${e.location ? ` @ ${e.location}` : ""} 참석: ${e.attendees.map((a) => a.user.name).join(", ") || "미지정"}`,
            )
            .join("\n")}`
        : "[가족 일정]\n해당 기간 일정이 없습니다.";
    }
    case "createCalendarEvent": {
      const familyId = await assertFamily(ctx);
      if (!args.title || !args.startsAt || !args.endsAt) {
        return "일정 제목, 시작, 종료가 필요합니다.";
      }
      const event = await prisma.calendarEvent.create({
        data: {
          familyId,
          title: args.title,
          description: args.description,
          location: args.location,
          startsAt: new Date(args.startsAt),
          endsAt: new Date(args.endsAt),
          createdById: ctx.userId,
        },
      });
      return `[가족 일정] 새 일정을 만들었습니다: ${event.title}`;
    }
    case "getShoppingList": {
      const familyId = await assertFamily(ctx);
      const list = await prisma.shoppingList.findFirst({
        where: { familyId },
        include: { items: { include: { assignee: true }, orderBy: { createdAt: "asc" } } },
      });
      if (!list) return "[장보기]\n목록이 없습니다.";
      return `[장보기]\n${list.items
        .map(
          (i) =>
            `- ${i.completed ? "[x]" : "[ ]"} ${i.name} × ${i.quantity}${i.category ? ` (${i.category})` : ""}${i.assignee ? ` · ${i.assignee.name}` : ""}`,
        )
        .join("\n")}`;
    }
    case "addShoppingItem": {
      const familyId = await assertFamily(ctx);
      const list =
        (await prisma.shoppingList.findFirst({ where: { familyId } })) ??
        (await prisma.shoppingList.create({ data: { familyId, name: "장보기" } }));
      if (!args.name) return "상품 이름이 필요합니다.";
      const item = await prisma.shoppingItem.create({
        data: {
          listId: list.id,
          name: args.name,
          quantity: args.quantity ? Number(args.quantity) : 1,
          category: args.category,
        },
      });
      return `[장보기] ${item.name} × ${item.quantity} 을 추가했습니다.`;
    }
    case "completeShoppingItem": {
      const familyId = await assertFamily(ctx);
      const item = await prisma.shoppingItem.findFirst({
        where: { id: args.id, list: { familyId } },
      });
      if (!item) return "항목을 찾을 수 없습니다.";
      await prisma.shoppingItem.update({ where: { id: item.id }, data: { completed: true } });
      return `[장보기] ${item.name} 을 완료했습니다.`;
    }
    case "searchFamilyMessages": {
      const familyId = await assertFamily(ctx);
      const q = args.query ?? "";
      const rows = await prisma.familyMessage.findMany({
        // Family Room only — never DIRECT_MESSAGE / personal AI conversations.
        where: {
          familyId,
          deletedAt: null,
          content: q ? { contains: q, mode: "insensitive" } : undefined,
        },
        include: { author: true },
        orderBy: { createdAt: "desc" },
        take: 20,
      });
      return rows.length
        ? `[가족방 대화]\n${rows
            .reverse()
            .map((m) => `${m.isAi ? "✨ Family AI" : m.author?.name ?? "구성원"}: ${m.content}`)
            .join("\n")}`
        : "[가족방 대화]\n관련 메시지가 없습니다.";
    }
    case "webSearch": {
      const hits = await webSearch(args.query ?? "");
      return formatWebBlock(hits);
    }
    default:
      return "알 수 없는 도구입니다.";
  }
}
