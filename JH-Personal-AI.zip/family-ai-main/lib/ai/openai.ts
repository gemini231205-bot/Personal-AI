import OpenAI, { APIError } from "openai";
import { loadEnv } from "@/lib/env";
import { ApiError } from "@/lib/api";
import { logServerError } from "@/lib/security/log";
import type { AIProvider, ChatRequest, ChatResult } from "./types";

function mapOpenAIError(error: unknown): ApiError {
  const status = error instanceof APIError ? error.status : undefined;
  const code = error instanceof APIError ? error.code ?? undefined : undefined;
  const type = error instanceof APIError ? error.type : undefined;
  logServerError("openai", new Error(`status=${status ?? "n/a"} code=${code ?? "n/a"} type=${type ?? "n/a"}`));

  if (status === 401) {
    return new ApiError("AI_UNAVAILABLE", "OpenAI API 키가 올바르지 않습니다. (401)", 401);
  }
  if (status === 403) {
    return new ApiError("AI_UNAVAILABLE", "OpenAI 권한이 없습니다. (403)", 403);
  }
  if (status === 404) {
    return new ApiError(
      "AI_UNAVAILABLE",
      `OpenAI 모델 또는 endpoint를 찾을 수 없습니다. (404) 설정된 모델: ${loadEnv().OPENAI_MODEL}`,
      404,
    );
  }
  if (status === 429) {
    return new ApiError("RATE_LIMITED", "OpenAI 사용량 한도 또는 요청 제한에 도달했습니다. (429)", 429);
  }
  if (status === 400) {
    return new ApiError(
      "AI_UNAVAILABLE",
      `OpenAI 요청 형식이 올바르지 않습니다. (400${code ? `/${code}` : ""})`,
      400,
    );
  }
  if (status && status >= 500) {
    return new ApiError("AI_UNAVAILABLE", `OpenAI 서버 오류입니다. (${status})`, 503);
  }
  return new ApiError("AI_UNAVAILABLE", "OpenAI 응답을 받지 못했습니다.", 503);
}

export class OpenAIProvider implements AIProvider {
  readonly name = "openai";

  get model() {
    return loadEnv().OPENAI_MODEL;
  }

  private client() {
    const key = loadEnv().OPENAI_API_KEY;
    if (!key) {
      throw new ApiError("CONFIG", "OPENAI_API_KEY가 설정되지 않았습니다.", 503);
    }
    return new OpenAI({ apiKey: key });
  }

  private messages(request: ChatRequest) {
    return [
      ...(request.system ? [{ role: "system" as const, content: request.system }] : []),
      ...request.messages,
    ];
  }

  private extraParams(request: ChatRequest) {
    return typeof request.temperature === "number" ? { temperature: request.temperature } : {};
  }

  async chat(request: ChatRequest): Promise<ChatResult> {
    const client = this.client();
    try {
      const res = await client.chat.completions.create({
        model: this.model,
        messages: this.messages(request),
        ...this.extraParams(request),
      });
      const content = res.choices[0]?.message?.content ?? "";
      return {
        content,
        inputTokens: res.usage?.prompt_tokens ?? 0,
        outputTokens: res.usage?.completion_tokens ?? 0,
        provider: this.name,
        model: this.model,
      };
    } catch (error) {
      throw mapOpenAIError(error);
    }
  }

  async *streamChat(request: ChatRequest) {
    const client = this.client();
    let content = "";
    try {
      const stream = await client.chat.completions.create({
        model: this.model,
        messages: this.messages(request),
        stream: true,
        ...this.extraParams(request),
      });
      for await (const part of stream) {
        const delta = part.choices[0]?.delta?.content ?? "";
        if (delta) {
          content += delta;
          yield delta;
        }
      }
    } catch (error) {
      throw mapOpenAIError(error);
    }
    return {
      content,
      inputTokens: 0,
      outputTokens: 0,
      provider: this.name,
      model: this.model,
    };
  }

  async embed(text: string) {
    const client = this.client();
    try {
      const res = await client.embeddings.create({
        model: "text-embedding-3-small",
        input: text.slice(0, 8000),
      });
      return res.data[0]?.embedding ?? [];
    } catch (error) {
      throw mapOpenAIError(error);
    }
  }
}
