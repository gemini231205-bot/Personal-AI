import { loadEnv, requireAiKey } from "@/lib/env";
import { ApiError } from "@/lib/api";
import { LocalProvider } from "./local";
import { OpenAIProvider } from "./openai";
import { GeminiProvider } from "./gemini";
import type { AIProvider } from "./types";

export function getAIProvider(override?: string): AIProvider {
  const env = loadEnv();
  const name = (override ?? env.AI_PROVIDER) as typeof env.AI_PROVIDER;
  if (name === "openai") {
    const missing = requireAiKey("openai");
    if (missing) throw new ApiError("CONFIG", missing, 503);
    return new OpenAIProvider();
  }
  if (name === "gemini") {
    const missing = requireAiKey("gemini");
    if (missing) throw new ApiError("CONFIG", missing, 503);
    return new GeminiProvider();
  }
  return new LocalProvider();
}

export function providerStatus() {
  const env = loadEnv();
  try {
    const provider = getAIProvider();
    return {
      configured: env.AI_PROVIDER,
      active: provider.name,
      model: provider.model,
      openaiReady: Boolean(env.OPENAI_API_KEY),
      geminiReady: Boolean(env.GEMINI_API_KEY),
      warning: requireAiKey(),
    };
  } catch (error) {
    return {
      configured: env.AI_PROVIDER,
      active: null,
      model: env.AI_PROVIDER === "openai" ? env.OPENAI_MODEL : env.GEMINI_MODEL,
      openaiReady: Boolean(env.OPENAI_API_KEY),
      geminiReady: Boolean(env.GEMINI_API_KEY),
      warning: error instanceof Error ? error.message : requireAiKey(),
    };
  }
}
