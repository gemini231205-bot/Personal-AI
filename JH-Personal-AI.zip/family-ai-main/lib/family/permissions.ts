import { FamilyRole } from "@prisma/client";
import { prisma } from "@/lib/db";
import { forbidden, notFound } from "@/lib/api";

export async function getMembership(userId: string, familyId: string) {
  return prisma.familyMember.findUnique({
    where: { familyId_userId: { familyId, userId } },
    include: { family: true, user: true },
  });
}

export async function requireMembership(userId: string, familyId: string) {
  const membership = await getMembership(userId, familyId);
  if (!membership) throw forbidden("이 가족에 속해 있지 않습니다.");
  return membership;
}

export async function requireRole(userId: string, familyId: string, roles: FamilyRole[]) {
  const membership = await requireMembership(userId, familyId);
  if (!roles.includes(membership.role)) {
    throw forbidden("이 작업을 수행할 권한이 없습니다.");
  }
  return membership;
}

export async function requireFamilyOf(userId: string) {
  const membership = await prisma.familyMember.findFirst({
    where: { userId },
    include: { family: true },
    orderBy: { joinedAt: "asc" },
  });
  if (!membership) throw notFound("아직 가족이 없습니다. 가족을 만들거나 초대 코드로 참여하세요.");
  return membership;
}

export function canManageMembers(role: FamilyRole) {
  return role === "OWNER" || role === "ADMIN";
}

export function canDeleteFamily(role: FamilyRole) {
  return role === "OWNER";
}

export async function touchPresence(userId: string, familyId: string) {
  await prisma.familyMember.update({
    where: { familyId_userId: { familyId, userId } },
    data: { lastSeenAt: new Date() },
  });
}
