import { prisma } from "@/lib/db";
import { inviteCode } from "@/lib/utils";
import { ApiError, forbidden } from "@/lib/api";

const DEFAULT_DAYS = 7;

export async function createInvite(input: {
  familyId: string;
  createdById: string;
  expiresInDays?: number;
}) {
  const days = input.expiresInDays && input.expiresInDays > 0 ? Math.min(input.expiresInDays, 90) : DEFAULT_DAYS;
  const code = inviteCode();
  const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000);
  await prisma.family.update({ where: { id: input.familyId }, data: { inviteCode: code } });
  const invite = await prisma.familyInvite.create({
    data: {
      familyId: input.familyId,
      code,
      createdById: input.createdById,
      expiresAt,
    },
  });
  return invite;
}

export async function rotateInvite(familyId: string, createdById?: string) {
  const invite = await createInvite({ familyId, createdById: createdById ?? "system" });
  return invite.code;
}

export async function joinByCode(userId: string, code: string) {
  const normalized = code.trim().toUpperCase();
  const invite = await prisma.familyInvite.findUnique({ where: { code: normalized } });
  const family = invite
    ? await prisma.family.findUnique({ where: { id: invite.familyId } })
    : await prisma.family.findFirst({ where: { inviteCode: normalized } });

  if (!family) throw new ApiError("NOT_FOUND", "초대 코드를 찾을 수 없습니다.", 404);

  if (invite) {
    if (invite.revoked) throw forbidden("사용할 수 없는 초대입니다.");
    if (invite.expiresAt && invite.expiresAt < new Date()) {
      throw forbidden("초대가 만료되었습니다. 관리자에게 새 코드를 요청하세요.");
    }
    if (invite.uses >= invite.maxUses) throw forbidden("초대 사용 한도에 도달했습니다.");
  }

  const alreadyHere = await prisma.familyMember.findUnique({
    where: { familyId_userId: { familyId: family.id, userId } },
  });
  if (alreadyHere) {
    throw new ApiError("CONFLICT", "이미 이 가족에 참여하고 있습니다.", 409);
  }

  const existing = await prisma.familyMember.findFirst({ where: { userId } });
  if (existing) {
    throw new ApiError("CONFLICT", "이미 다른 가족에 소속되어 있습니다. 한 계정은 한 가족만 가질 수 있습니다.", 409);
  }

  const membership = await prisma.familyMember.create({
    data: { familyId: family.id, userId, role: "MEMBER" },
    include: { family: true },
  });

  if (invite) {
    await prisma.familyInvite.update({
      where: { id: invite.id },
      data: { uses: { increment: 1 } },
    });
  }

  return membership;
}
