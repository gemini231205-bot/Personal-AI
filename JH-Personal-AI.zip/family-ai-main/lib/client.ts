export type ApiResult<T> = { success: true; data: T } | { success: false; error: { code: string; message: string } };

export async function api<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      ...(init?.body instanceof FormData ? {} : { "Content-Type": "application/json" }),
      ...init?.headers,
    },
  });
  const json = (await res.json()) as ApiResult<T>;
  if (!json.success) {
    throw new Error(json.error.message);
  }
  return json.data;
}
