import { prisma } from "@/lib/db";
import { requireMembership } from "@/lib/family/permissions";

export async function personalSearch(userId: string, q: string) {
  const query = q.trim();
  if (!query) return { conversations: [], memories: [], files: [], messages: [] };

  const [conversations, memories, files, messages] = await Promise.all([
    prisma.conversation.findMany({
      where: { userId, scope: "PERSONAL", title: { contains: query, mode: "insensitive" } },
      take: 10,
    }),
    prisma.personalMemory.findMany({
      where: {
        userId,
        OR: [
          { title: { contains: query, mode: "insensitive" } },
          { content: { contains: query, mode: "insensitive" } },
        ],
      },
      take: 10,
    }),
    prisma.personalFile.findMany({
      where: { userId, originalName: { contains: query, mode: "insensitive" } },
      take: 10,
    }),
    prisma.message.findMany({
      where: {
        conversation: { userId, scope: "PERSONAL" },
        content: { contains: query, mode: "insensitive" },
      },
      include: { conversation: true },
      take: 15,
    }),
  ]);
  return { conversations, memories, files, messages };
}

export async function familySearch(userId: string, familyId: string, q: string) {
  await requireMembership(userId, familyId);
  const query = q.trim();
  if (!query) {
    return { room: [], memories: [], files: [], events: [], shopping: [], polls: [] };
  }
  const [room, memories, files, events, shopping, polls] = await Promise.all([
    prisma.familyMessage.findMany({
      where: { familyId, deletedAt: null, content: { contains: query, mode: "insensitive" } },
      include: { author: true },
      take: 15,
    }),
    prisma.familyMemory.findMany({
      where: {
        familyId,
        OR: [
          { title: { contains: query, mode: "insensitive" } },
          { content: { contains: query, mode: "insensitive" } },
        ],
      },
      take: 10,
    }),
    prisma.familyFile.findMany({
      where: { familyId, originalName: { contains: query, mode: "insensitive" } },
      include: { uploader: true },
      take: 10,
    }),
    prisma.calendarEvent.findMany({
      where: {
        familyId,
        OR: [
          { title: { contains: query, mode: "insensitive" } },
          { description: { contains: query, mode: "insensitive" } },
        ],
      },
      take: 10,
    }),
    prisma.shoppingItem.findMany({
      where: { list: { familyId }, name: { contains: query, mode: "insensitive" } },
      take: 10,
    }),
    prisma.poll.findMany({
      where: { familyId, question: { contains: query, mode: "insensitive" } },
      take: 10,
    }),
  ]);
  return { room, memories, files, events, shopping, polls };
}
