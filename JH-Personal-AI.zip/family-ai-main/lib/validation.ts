import { z } from "zod";

export const signupSchema = z.object({
  name: z.string().trim().min(1, "이름을 입력하세요.").max(40),
  email: z.string().trim().email("이메일 형식이 올바르지 않습니다.").toLowerCase(),
  password: z.string().min(8, "비밀번호는 8자 이상이어야 합니다."),
});

export const loginSchema = z.object({
  email: z.string().trim().email().toLowerCase(),
  password: z.string().min(1),
});

export const familyCreateSchema = z.object({
  name: z.string().trim().min(1, "가족 이름을 입력하세요.").max(40),
});

export const joinSchema = z.object({
  code: z.string().trim().min(4, "초대 코드를 입력하세요."),
});

export const memorySchema = z.object({
  title: z.string().trim().min(1).max(80),
  content: z.string().trim().min(1).max(4000),
  tags: z.array(z.string()).optional(),
  sharedToFamily: z.boolean().optional(),
});

export const eventSchema = z.object({
  title: z.string().trim().min(1).max(80),
  description: z.string().max(2000).optional(),
  location: z.string().max(120).optional(),
  startsAt: z.string(),
  endsAt: z.string(),
  allDay: z.boolean().optional(),
  recurrence: z.enum(["NONE", "DAILY", "WEEKLY", "MONTHLY", "YEARLY"]).optional(),
  attendeeIds: z.array(z.string()).optional(),
});

export const shoppingItemSchema = z.object({
  name: z.string().trim().min(1).max(80),
  quantity: z.number().int().min(1).max(99).optional(),
  category: z.string().max(40).optional(),
  notes: z.string().max(200).optional(),
  assigneeId: z.string().optional(),
});

export const pollSchema = z.object({
  question: z.string().trim().min(1).max(120),
  options: z.array(z.string().trim().min(1).max(60)).min(2).max(8),
  allowMultiple: z.boolean().optional(),
  endsAt: z.string().optional(),
});

export const wishlistSchema = z.object({
  name: z.string().trim().min(1).max(80),
  description: z.string().max(500).optional(),
  url: z.string().url().optional().or(z.literal("")),
  priority: z.number().int().min(1).max(5).optional(),
  isPublic: z.boolean().optional(),
  scope: z.enum(["PERSONAL", "FAMILY"]).optional(),
});

export const profileSchema = z.object({
  name: z.string().trim().min(1).max(40),
  bio: z.string().max(200).optional(),
  timezone: z.string().optional(),
  avatarColor: z.string().optional(),
});

export const privacySchema = z.object({
  shareFamilyContext: z.boolean(),
  allowPersonalFileAnalysis: z.boolean(),
});

export const passwordChangeSchema = z.object({
  currentPassword: z.string().min(1),
  nextPassword: z.string().min(8),
});

export const roomMessageSchema = z.object({
  content: z.string().trim().min(1).max(4000),
  replyToId: z.string().optional(),
});

export const conversationSchema = z.object({
  title: z.string().trim().min(1).max(80).optional(),
});
