import { loadEnv } from "@/lib/env";
import { ApiError } from "@/lib/api";
import * as local from "./local";
import * as s3 from "./s3";
import * as blob from "./blob";

export type StorageBackend = "local" | "s3" | "blob";

export function storageBackend(): StorageBackend {
  const env = loadEnv();
  if (env.STORAGE_PROVIDER === "s3") return "s3";
  if (env.STORAGE_PROVIDER === "blob") return "blob";
  if (process.env.BLOB_READ_WRITE_TOKEN) return "blob";
  if (process.env.VERCEL && env.STORAGE_PROVIDER === "local") {
    throw new ApiError(
      "CONFIG",
      "Vercel 서버리스 파일시스템은 영구 저장이 아닙니다. STORAGE_PROVIDER=blob (BLOB_READ_WRITE_TOKEN) 또는 STORAGE_PROVIDER=s3 를 설정하세요.",
      503,
    );
  }
  return "local";
}

function adapter() {
  const backend = storageBackend();
  if (backend === "s3") return s3;
  if (backend === "blob") return blob;
  return local;
}

export async function saveUpload(namespace: string, storedName: string, data: Buffer) {
  return adapter().saveUpload(namespace, storedName, data);
}

export async function readUpload(namespace: string, storedName: string) {
  return adapter().readUpload(namespace, storedName);
}

export async function removeUpload(namespace: string, storedName: string) {
  return adapter().removeUpload(namespace, storedName);
}
