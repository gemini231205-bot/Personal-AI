import { createWriteStream } from "node:fs";
import { mkdir, readFile, unlink } from "node:fs/promises";
import path from "node:path";
import { pipeline } from "node:stream/promises";
import { Readable } from "node:stream";
import { safePathSegment } from "@/lib/security/sanitize";

function rootDir() {
  return path.resolve(/*turbopackIgnore: true*/ process.cwd(), ".data", "uploads");
}

export async function saveUpload(namespace: string, storedName: string, data: Buffer) {
  const ns = safePathSegment(namespace);
  const file = safePathSegment(storedName);
  const dir = path.join(/*turbopackIgnore: true*/ rootDir(), ns);
  await mkdir(dir, { recursive: true });
  const dest = path.join(/*turbopackIgnore: true*/ dir, file);
  if (!dest.startsWith(rootDir())) throw new Error("경로가 허용되지 않습니다.");
  await pipeline(Readable.from(data), createWriteStream(dest));
  return dest;
}

export async function readUpload(namespace: string, storedName: string) {
  const dest = path.join(/*turbopackIgnore: true*/ rootDir(), safePathSegment(namespace), safePathSegment(storedName));
  if (!dest.startsWith(rootDir())) throw new Error("경로가 허용되지 않습니다.");
  return readFile(dest);
}

export async function removeUpload(namespace: string, storedName: string) {
  const dest = path.join(/*turbopackIgnore: true*/ rootDir(), safePathSegment(namespace), safePathSegment(storedName));
  if (!dest.startsWith(rootDir())) throw new Error("경로가 허용되지 않습니다.");
  try {
    await unlink(dest);
  } catch {
    // already gone
  }
}
