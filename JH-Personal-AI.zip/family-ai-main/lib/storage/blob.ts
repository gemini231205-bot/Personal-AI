import { del, get, put } from "@vercel/blob";
import { ApiError } from "@/lib/api";

function keyOf(namespace: string, storedName: string) {
  return `${namespace}/${storedName}`;
}

export async function saveUpload(namespace: string, storedName: string, data: Buffer) {
  const pathname = keyOf(namespace, storedName);
  await put(pathname, data, {
    access: "private",
    addRandomSuffix: false,
    allowOverwrite: true,
  });
  return pathname;
}

export async function readUpload(namespace: string, storedName: string) {
  const pathname = keyOf(namespace, storedName);
  const result = await get(pathname, { access: "private" });
  if (!result?.stream) throw new ApiError("NOT_FOUND", "파일을 찾을 수 없습니다.", 404);
  return Buffer.from(await new Response(result.stream).arrayBuffer());
}

export async function removeUpload(namespace: string, storedName: string) {
  await del(keyOf(namespace, storedName));
}
