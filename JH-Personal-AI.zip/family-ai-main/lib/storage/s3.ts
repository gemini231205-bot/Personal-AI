import { DeleteObjectCommand, GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import { loadEnv } from "@/lib/env";
import { ApiError } from "@/lib/api";

function client() {
  const env = loadEnv();
  if (!env.STORAGE_BUCKET || !env.STORAGE_ACCESS_KEY || !env.STORAGE_SECRET_KEY) {
    throw new ApiError(
      "CONFIG",
      "S3 저장소 설정이 없습니다. STORAGE_BUCKET, STORAGE_ACCESS_KEY, STORAGE_SECRET_KEY를 넣으세요.",
      503,
    );
  }
  return new S3Client({
    region: env.STORAGE_REGION || "auto",
    endpoint: env.STORAGE_ENDPOINT || undefined,
    forcePathStyle: Boolean(env.STORAGE_ENDPOINT),
    credentials: {
      accessKeyId: env.STORAGE_ACCESS_KEY,
      secretAccessKey: env.STORAGE_SECRET_KEY,
    },
  });
}

function keyOf(namespace: string, storedName: string) {
  return `${namespace}/${storedName}`;
}

export async function saveUpload(namespace: string, storedName: string, data: Buffer) {
  const env = loadEnv();
  await client().send(
    new PutObjectCommand({
      Bucket: env.STORAGE_BUCKET,
      Key: keyOf(namespace, storedName),
      Body: data,
    }),
  );
  return keyOf(namespace, storedName);
}

export async function readUpload(namespace: string, storedName: string) {
  const env = loadEnv();
  const res = await client().send(
    new GetObjectCommand({
      Bucket: env.STORAGE_BUCKET,
      Key: keyOf(namespace, storedName),
    }),
  );
  const bytes = await res.Body?.transformToByteArray();
  if (!bytes) throw new ApiError("NOT_FOUND", "파일을 찾을 수 없습니다.", 404);
  return Buffer.from(bytes);
}

export async function removeUpload(namespace: string, storedName: string) {
  const env = loadEnv();
  await client().send(
    new DeleteObjectCommand({
      Bucket: env.STORAGE_BUCKET,
      Key: keyOf(namespace, storedName),
    }),
  );
}
