import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { prisma } from "@/lib/db";
import { loadEnv } from "@/lib/env";

// Node-only: Prisma + node:crypto. Do not import this module from proxy.ts.

export const SESSION_COOKIE = "family_ai_session";
const SESSION_DAYS = 30;

export function hashToken(token: string) {
  const secret = loadEnv().AUTH_SECRET;
  return createHash("sha256").update(`${token}:${secret}`).digest("hex");
}

export function createSessionToken() {
  return randomBytes(32).toString("hex");
}

export async function createSession(userId: string, meta?: { ip?: string; userAgent?: string }) {
  const token = createSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await prisma.session.create({
    data: {
      userId,
      tokenHash: hashToken(token),
      expiresAt,
      ip: meta?.ip,
      userAgent: meta?.userAgent,
    },
  });
  return { token, expiresAt };
}

export async function destroySession(token: string) {
  await prisma.session.deleteMany({ where: { tokenHash: hashToken(token) } });
}

export async function destroyAllSessions(userId: string) {
  await prisma.session.deleteMany({ where: { userId } });
}

export async function readSessionToken() {
  const jar = await cookies();
  return jar.get(SESSION_COOKIE)?.value ?? null;
}

export async function getCurrentUser() {
  const token = await readSessionToken();
  if (!token) return null;
  const session = await prisma.session.findUnique({
    where: { tokenHash: hashToken(token) },
    include: {
      user: {
        include: {
          memberships: {
            include: { family: true },
            orderBy: { joinedAt: "asc" },
          },
        },
      },
    },
  });
  if (!session || session.expiresAt < new Date()) {
    if (session) await prisma.session.delete({ where: { id: session.id } });
    return null;
  }
  return session.user;
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) {
    const { unauthorized } = await import("@/lib/api");
    throw unauthorized();
  }
  return user;
}

export function sessionCookieOptions(expiresAt: Date) {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  };
}
