export const SITE_COOKIE = "family_ai_site";

/**
 * Hash the site password with AUTH_SECRET so the unlock cookie is never the
 * plaintext password. The typed password is compared only in /api/site/unlock.
 * This module is safe for Next.js proxy: Web Crypto only, no Node crypto import.
 *
 * Accepts PRIVATE_SITE_PASSWORD or SITE_PASSWORD.
 */
function webCrypto() {
  const subtle = globalThis.crypto?.subtle;
  if (!subtle) {
    throw new Error("이 런타임에서 Web Crypto를 사용할 수 없습니다.");
  }
  return subtle;
}

function toHex(bytes: ArrayBuffer) {
  return [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function safeEqual(left: string, right: string) {
  if (left.length !== right.length) return false;
  let mismatch = 0;
  for (let i = 0; i < left.length; i++) mismatch |= left.charCodeAt(i) ^ right.charCodeAt(i);
  return mismatch === 0;
}

export function sitePassword() {
  return (process.env.PRIVATE_SITE_PASSWORD ?? process.env.SITE_PASSWORD ?? "").trim();
}

export function sitePasswordEnabled() {
  return Boolean(sitePassword());
}

export async function siteCookieValue() {
  const password = sitePassword();
  const secret = process.env.AUTH_SECRET ?? "family-ai";
  const digest = await webCrypto().digest("SHA-256", new TextEncoder().encode(`site:${password}:${secret}`));
  return toHex(digest);
}

export async function verifySiteCookie(value?: string | null) {
  if (!sitePasswordEnabled()) return true;
  if (!value) return false;
  return safeEqual(value, await siteCookieValue());
}
