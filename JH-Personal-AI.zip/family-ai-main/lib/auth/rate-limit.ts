import { prisma } from "@/lib/db";
import { loadEnv } from "@/lib/env";
import { ApiError } from "@/lib/api";

const buckets = new Map<string, { count: number; resetAt: number }>();

export function rateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  const current = buckets.get(key);
  if (!current || current.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  current.count += 1;
  if (current.count > limit) {
    throw new ApiError("RATE_LIMITED", "요청이 너무 많습니다. 잠시 후 다시 시도하세요.", 429);
  }
}

export async function assertLoginAllowed(email: string, ip: string) {
  const max = loadEnv().AUTH_MAX_ATTEMPTS;
  const since = new Date(Date.now() - 15 * 60 * 1000);
  const failed = await prisma.loginAttempt.count({
    where: {
      success: false,
      createdAt: { gte: since },
      OR: [{ email: email.toLowerCase() }, { ip }],
    },
  });
  if (failed >= max) {
    throw new ApiError(
      "RATE_LIMITED",
      "로그인 시도가 너무 많습니다. 15분 후 다시 시도하세요.",
      429,
    );
  }
}

export async function recordLoginAttempt(input: {
  email: string;
  ip: string;
  success: boolean;
  userId?: string;
}) {
  await prisma.loginAttempt.create({
    data: {
      email: input.email.toLowerCase(),
      ip: input.ip,
      success: input.success,
      userId: input.userId,
    },
  });
}

export async function assertAiBudget(userId: string) {
  const limit = loadEnv().AI_DAILY_REQUEST_LIMIT;
  const since = new Date();
  since.setHours(0, 0, 0, 0);
  const used = await prisma.aIUsageLog.count({
    where: { userId, createdAt: { gte: since } },
  });
  if (used >= limit) {
    throw new ApiError("RATE_LIMITED", "오늘의 AI 사용 한도에 도달했습니다.", 429);
  }
}
