import type { Family, FamilyMember, User } from "@prisma/client";

export function publicUser(user: User) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    avatarColor: user.avatarColor,
    bio: user.bio,
    timezone: user.timezone,
    shareFamilyContext: user.shareFamilyContext,
    allowPersonalFileAnalysis: user.allowPersonalFileAnalysis,
    createdAt: user.createdAt,
  };
}

export function publicMember(
  member: FamilyMember & { user: User; family?: Family },
) {
  return {
    id: member.id,
    role: member.role,
    nickname: member.nickname,
    joinedAt: member.joinedAt,
    lastSeenAt: member.lastSeenAt,
    user: {
      id: member.user.id,
      name: member.user.name,
      avatarColor: member.user.avatarColor,
    },
    family: member.family
      ? { id: member.family.id, name: member.family.name, inviteCode: member.family.inviteCode }
      : undefined,
  };
}

const ONLINE_MS = 90_000;

export function isOnline(lastSeenAt?: Date | null) {
  if (!lastSeenAt) return false;
  return Date.now() - lastSeenAt.getTime() < ONLINE_MS;
}
