import { loadEnv } from "@/lib/env";
import { ApiError } from "@/lib/api";

export type WebHit = {
  title: string;
  url: string;
  snippet: string;
};

export async function webSearch(
  query: string,
): Promise<WebHit[]> {
  const env = loadEnv();

  if (
    env.WEB_SEARCH_PROVIDER === "none" ||
    !env.WEB_SEARCH_API_KEY
  ) {
    throw new ApiError(
      "CONFIG",
      "웹 검색이 설정되지 않았습니다. 기본 AI 대화는 계속 사용할 수 있습니다.",
      503,
    );
  }

  const res = await fetch(
    "https://api.tavily.com/search",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        api_key: env.WEB_SEARCH_API_KEY,
        query,
        max_results: 5,
        search_depth: "basic",
      }),
    },
  );

  if (!res.ok) {
    throw new ApiError(
      "AI_UNAVAILABLE",
      "웹 검색 서비스에 연결하지 못했습니다.",
      503,
    );
  }

  const json = (await res.json()) as {
    results?: {
      title?: string;
      url?: string;
      content?: string;
    }[];
  };

  return (json.results ?? []).map((r) => ({
    title: r.title ?? "제목 없음",
    url: r.url ?? "",
    snippet: r.content ?? "",
  }));
}

export function formatWebBlock(
  hits: WebHit[],
) {
  if (!hits.length) {
    return (
      "[웹 검색 결과]\n결과가 없습니다."
    );
  }

  return [
    "[웹 검색 결과]",
    "아래 정보는 외부 웹 검색 결과입니다.",
    "가족 내부 데이터와 혼동하지 마세요.",
    ...hits.map(
      (h, i) =>
        `${i + 1}. ${h.title}\n${h.url}\n${h.snippet}`,
    ),
  ].join("\n");
}
