import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.string().optional(),
  NEXT_PUBLIC_APP_URL: z.string().default("http://127.0.0.1:43123"),
  AUTH_SECRET: z.string().min(16, "AUTH_SECRET must be at least 16 characters"),
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
  AI_PROVIDER: z.enum(["openai", "gemini", "local"]).default("local"),
  OPENAI_API_KEY: z.string().optional().default(""),
  GEMINI_API_KEY: z.string().optional().default(""),
  OPENAI_MODEL: z.string().default("gpt-4o-mini"),
  GEMINI_MODEL: z.string().default("gemini-2.0-flash"),
  LOCAL_MODEL: z.string().default("family-local-v1"),
  WEB_SEARCH_PROVIDER: z.enum(["tavily", "none"]).default("none"),
  WEB_SEARCH_API_KEY: z.string().optional().default(""),
  STORAGE_PROVIDER: z.enum(["local", "s3", "blob"]).default("local"),
  STORAGE_DIR: z.string().default(".data/uploads"),
  STORAGE_BUCKET: z.string().optional().default(""),
  STORAGE_REGION: z.string().optional().default(""),
  STORAGE_ENDPOINT: z.string().optional().default(""),
  STORAGE_ACCESS_KEY: z.string().optional().default(""),
  STORAGE_SECRET_KEY: z.string().optional().default(""),
  BLOB_READ_WRITE_TOKEN: z.string().optional().default(""),
  DIRECT_DATABASE_URL: z.string().optional().default(""),
  MAX_UPLOAD_BYTES: z.coerce.number().default(15 * 1024 * 1024),
  AI_DAILY_REQUEST_LIMIT: z.coerce.number().default(200),
  AUTH_MAX_ATTEMPTS: z.coerce.number().default(8),
  SITE_PASSWORD: z.string().optional().default(""),
  PRIVATE_SITE_PASSWORD: z.string().optional().default(""),
});

export type AppEnv = z.infer<typeof schema>;

let cached: AppEnv | null = null;
let envError: string | null = null;

export function loadEnv(): AppEnv {
  if (cached) return cached;
  if (!process.env.DATABASE_URL && process.env.SUPABASE_DB_URL) {
    process.env.DATABASE_URL = process.env.SUPABASE_DB_URL;
  }
  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    envError = parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`).join("; ");
    throw new Error(`환경 변수 설정 오류: ${envError}`);
  }
  cached = parsed.data;
  if (!cached.DIRECT_DATABASE_URL && cached.DATABASE_URL) {
    cached = { ...cached, DIRECT_DATABASE_URL: cached.DATABASE_URL };
    process.env.DIRECT_DATABASE_URL ??= cached.DATABASE_URL;
  }
  return cached;
}

export function getEnvError() {
  try {
    loadEnv();
    return null;
  } catch (error) {
    return error instanceof Error ? error.message : "환경 변수를 확인하세요.";
  }
}

export function requireAiKey(provider = loadEnv().AI_PROVIDER) {
  const env = loadEnv();
  if (provider === "openai" && !env.OPENAI_API_KEY) {
    return "OPENAI_API_KEY가 없습니다. .env에 키를 넣거나 AI_PROVIDER=local 로 전환하세요.";
  }
  if (provider === "gemini" && !env.GEMINI_API_KEY) {
    return "GEMINI_API_KEY가 없습니다. .env에 키를 넣거나 AI_PROVIDER=local 로 전환하세요.";
  }
  return null;
}

export function appUrl() {
  const configured = (() => {
    try {
      return loadEnv().NEXT_PUBLIC_APP_URL.replace(/\/$/, "");
    } catch {
      return "";
    }
  })();
  const isLocal = !configured || /localhost|127\.0\.0\.1/.test(configured);
  if (!isLocal) return configured;
  if (process.env.VERCEL_PROJECT_PRODUCTION_URL) {
    return `https://${process.env.VERCEL_PROJECT_PRODUCTION_URL}`;
  }
  if (process.env.VERCEL_URL) return `https://${process.env.VERCEL_URL}`;
  return configured || "http://127.0.0.1:43123";
}
