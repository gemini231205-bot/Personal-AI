import { prisma } from "@/lib/db";
import { loadEnv, requireAiKey } from "@/lib/env";
import { wrapUntrusted } from "@/lib/security/sanitize";

const CHUNK_SIZE = 700;
const CHUNK_OVERLAP = 80;
const DIM = 64;

export type RagHit = {
  content: string;
  score: number;
  source: string;
  page?: number | null;
  namespace: string;
};

export function chunkText(text: string) {
  const clean = text.replace(/\r/g, "").trim();

  if (!clean) return [];

  const chunks: string[] = [];

  let i = 0;

  while (i < clean.length) {
    chunks.push(
      clean.slice(i, i + CHUNK_SIZE),
    );

    i += CHUNK_SIZE - CHUNK_OVERLAP;
  }

  return chunks;
}

function tokenize(text: string) {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter(Boolean);
}

export function localEmbed(
  text: string,
): number[] {
  const vec = new Array<number>(DIM).fill(0);

  const tokens = tokenize(text);

  for (const token of tokens) {
    let h = 2166136261;

    for (
      let i = 0;
      i < token.length;
      i += 1
    ) {
      h ^= token.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }

    const idx = Math.abs(h) % DIM;

    vec[idx] += 1;
  }

  const norm =
    Math.sqrt(
      vec.reduce(
        (s, v) => s + v * v,
        0,
      ),
    ) || 1;

  return vec.map(
    (v) => v / norm,
  );
}

export async function embedText(
  text: string,
): Promise<number[]> {
  const env = loadEnv();

  const missing = requireAiKey(
    env.AI_PROVIDER,
  );

  if (
    env.AI_PROVIDER === "openai" &&
    !missing
  ) {
    try {
      const OpenAI =
        (await import("openai")).default;

      const client = new OpenAI({
        apiKey: env.OPENAI_API_KEY,
      });

      const res =
        await client.embeddings.create({
          model:
            "text-embedding-3-small",
          input: text.slice(0, 8000),
        });

      return (
        res.data[0]?.embedding ??
        localEmbed(text)
      );
    } catch {
      return localEmbed(text);
    }
  }

  return localEmbed(text);
}

function cosine(
  a: number[],
  b: number[],
) {
  const n = Math.min(
    a.length,
    b.length,
  );

  let dot = 0;
  let na = 0;
  let nb = 0;

  for (
    let i = 0;
    i < n;
    i += 1
  ) {
    dot += a[i] * b[i];
    na += a[i] * a[i];
    nb += b[i] * b[i];
  }

  return (
    dot /
    ((Math.sqrt(na) || 1) *
      (Math.sqrt(nb) || 1))
  );
}

export async function extractText(
  buffer: Buffer,
  mime: string,
  filename: string,
) {
  const ext =
    filename
      .split(".")
      .pop()
      ?.toLowerCase() ?? "";

  if (
    ext === "txt" ||
    mime === "text/plain"
  ) {
    return buffer.toString("utf8");
  }

  if (
    ext === "csv" ||
    mime === "text/csv"
  ) {
    return buffer.toString("utf8");
  }

  if (ext === "docx") {
    const mammoth =
      await import("mammoth");

    const result =
      await mammoth.extractRawText({
        buffer,
      });

    return result.value;
  }

  if (
    ext === "xlsx" ||
    ext === "xls"
  ) {
    const XLSX =
      await import("xlsx");

    const wb = XLSX.read(buffer, {
      type: "buffer",
    });

    return wb.SheetNames.map(
      (name) => {
        const sheet =
          wb.Sheets[name];

        return `# ${name}\n${XLSX.utils.sheet_to_csv(
          sheet,
        )}`;
      },
    ).join("\n\n");
  }

  if (
    ext === "pdf" ||
    mime === "application/pdf"
  ) {
    const pdfParse =
      (
        await import(
          "pdf-parse"
        )
      ).default as (
        b: Buffer,
      ) => Promise<{
        text: string;
      }>;

    const parsed =
      await pdfParse(buffer);

    return parsed.text;
  }

  if (mime.startsWith("image/")) {
    return `[이미지 파일: ${filename}] 텍스트를 추출할 수 없는 이미지입니다. 파일명과 메타데이터만 검색에 사용됩니다.`;
  }

  return "";
}

export async function indexPersonalFile(
  fileId: string,
  userId: string,
  text: string,
  filename: string,
) {
  const namespace =
    `personal_file:${userId}`;

  await prisma.fileChunk.deleteMany({
    where: {
      personalFileId: fileId,
    },
  });

  const chunks =
    chunkText(text);

  for (
    let i = 0;
    i < chunks.length;
    i += 1
  ) {
    const embedding =
      await embedText(
        `${filename}\n${chunks[i]}`,
      );

    await prisma.fileChunk.create({
      data: {
        namespace,
        personalFileId: fileId,
        content: chunks[i],
        embedding,
        page:
          Math.floor(i / 3) + 1,
        chunkIndex: i,
      },
    });
  }
}

export async function indexFamilyFile(
  fileId: string,
  familyId: string,
  text: string,
  filename: string,
) {
  const namespace =
    `family_file:${familyId}`;

  await prisma.fileChunk.deleteMany({
    where: {
      familyFileId: fileId,
    },
  });

  const chunks =
    chunkText(text);

  for (
    let i = 0;
    i < chunks.length;
    i += 1
  ) {
    const embedding =
      await embedText(
        `${filename}\n${chunks[i]}`,
      );

    await prisma.fileChunk.create({
      data: {
        namespace,
        familyFileId: fileId,
        content: chunks[i],
        embedding,
        page:
          Math.floor(i / 3) + 1,
        chunkIndex: i,
      },
    });
  }
}

export async function semanticSearch(
  namespace: string,
  query: string,
  limit = 5,
): Promise<RagHit[]> {
  const queryVec =
    await embedText(query);

  const chunks =
    await prisma.fileChunk.findMany({
      where: {
        namespace,
      },
      include: {
        personalFile: true,
        familyFile: true,
      },
      take: 200,
    });

  return chunks
    .map((chunk) => {
      const embedding =
        Array.isArray(
          chunk.embedding,
        )
          ? (chunk.embedding as number[])
          : [];

      const source =
        chunk.personalFile
          ?.originalName ??
        chunk.familyFile
          ?.originalName ??
        "파일";

      return {
        content: chunk.content,
        score: cosine(
          queryVec,
          embedding,
        ),
        source,
        page: chunk.page,
        namespace:
          chunk.namespace,
      };
    })
    .sort(
      (a, b) =>
        b.score - a.score,
    )
    .slice(0, limit)
    .filter(
      (h) => h.score > 0.08,
    );
}

export async function semanticSearchPersonalFile(
  fileId: string,
  userId: string,
  query: string,
  limit = 5,
): Promise<RagHit[]> {
  const queryVec =
    await embedText(query);

  const chunks =
    await prisma.fileChunk.findMany({
      where: {
        personalFileId: fileId,
        namespace:
          `personal_file:${userId}`,
      },
      include: {
        personalFile: true,
      },
      take: 200,
    });

  return chunks
    .map((chunk) => {
      const embedding =
        Array.isArray(
          chunk.embedding,
        )
          ? (chunk.embedding as number[])
          : [];

      return {
        content: chunk.content,
        score: cosine(
          queryVec,
          embedding,
        ),
        source:
          chunk.personalFile
            ?.originalName ??
          "파일",
        page: chunk.page,
        namespace:
          chunk.namespace,
      };
    })
    .sort(
      (a, b) =>
        b.score - a.score,
    )
    .slice(0, limit)
    .filter(
      (h) => h.score > 0.08,
    );
}

export function formatCitations(
  hits: RagHit[],
) {
  return hits.map((h) => ({
    source: h.source,
    page:
      h.page ?? undefined,
    excerpt:
      h.content.slice(0, 180),
  }));
}

export function ragContextBlock(
  hits: RagHit[],
) {
  if (!hits.length) return "";

  return [
    "[가족/개인 파일 검색 결과]",
    ...hits.map(
      (h, i) =>
        `${i + 1}. 출처: ${h.source}${
          h.page
            ? ` / ${h.page}페이지`
            : ""
        }\n${wrapUntrusted(
          h.source,
          h.content,
        )}`,
    ),
  ].join("\n\n");
}
