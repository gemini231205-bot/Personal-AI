import { prisma } from "@/lib/db";
import { ApiError, forbidden, notFound } from "@/lib/api";
import { requireFamilyOf, requireMembership } from "@/lib/family/permissions";

export function dmPairKey(familyId: string, userA: string, userB: string) {
  const [left, right] = [userA, userB].sort();
  return `${familyId}:${left}:${right}`;
}

export async function requireDmAccess(userId: string, conversationId: string) {
  const conversation = await prisma.conversation.findUnique({
    where: { id: conversationId },
    include: {
      members: { include: { user: true } },
    },
  });
  if (!conversation || conversation.scope !== "DIRECT") {
    throw notFound("대화를 찾을 수 없습니다.");
  }
  if (conversation.members.length !== 2) {
    throw forbidden("1:1 채팅은 두 명의 참여자만 허용됩니다.");
  }
  const mine = conversation.members.find((m) => m.userId === userId);
  if (!mine) throw forbidden("이 대화에 참여하고 있지 않습니다.");
  if (!conversation.familyId) throw forbidden("잘못된 가족 대화입니다.");
  await requireMembership(userId, conversation.familyId);
  return conversation;
}

export async function openOrCreateDm(actorId: string, peerId: string) {
  if (!peerId || actorId === peerId) {
    throw new ApiError("VALIDATION", "다른 가족 구성원을 선택하세요.", 422);
  }
  const actorMem = await requireFamilyOf(actorId);
  await requireMembership(peerId, actorMem.familyId);
  const pairKey = dmPairKey(actorMem.familyId, actorId, peerId);
  const existing = await prisma.conversation.findUnique({
    where: { pairKey },
    include: { members: { include: { user: true } } },
  });
  if (existing) {
    if (existing.scope !== "DIRECT" || existing.members.length !== 2) {
      throw forbidden("잘못된 1:1 대화입니다.");
    }
    if (!existing.members.some((m) => m.userId === actorId)) {
      throw forbidden("이 대화에 참여하고 있지 않습니다.");
    }
    return existing;
  }
  return prisma.conversation.create({
    data: {
      title: "1:1 채팅",
      scope: "DIRECT",
      familyId: actorMem.familyId,
      pairKey,
      members: {
        create: [{ userId: actorId }, { userId: peerId }],
      },
    },
    include: { members: { include: { user: true } } },
  });
}

export function publicPeer(user: { id: string; name: string; avatarColor: string }) {
  return { id: user.id, name: user.name, avatarColor: user.avatarColor };
}

export function peerOf(
  userId: string,
  members: { userId: string; user: { id: string; name: string; avatarColor: string } }[],
) {
  const peer = members.find((m) => m.userId !== userId)?.user;
  return peer ? publicPeer(peer) : null;
}

export function publicDmMessage(m: {
  id: string;
  content: string;
  createdAt: Date;
  editedAt?: Date | null;
  deletedAt?: Date | null;
  authorId?: string | null;
  author?: { id: string; name: string; avatarColor: string } | null;
}) {
  return {
    id: m.id,
    content: m.deletedAt ? "삭제된 메시지입니다." : m.content,
    deletedAt: m.deletedAt,
    editedAt: m.editedAt,
    createdAt: m.createdAt,
    authorId: m.authorId,
    author: m.author ? publicPeer(m.author) : null,
  };
}
