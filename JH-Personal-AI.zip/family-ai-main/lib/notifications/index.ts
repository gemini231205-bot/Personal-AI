import { prisma } from "@/lib/db";

export async function notifyFamily(input: {
  familyId: string;
  type: string;
  title: string;
  body: string;
  href?: string;
  exceptUserId?: string;
}) {
  const members = await prisma.familyMember.findMany({
    where: { familyId: input.familyId },
    select: { userId: true },
  });
  const rows = members
    .filter((m) => m.userId !== input.exceptUserId)
    .map((m) => ({
      userId: m.userId,
      familyId: input.familyId,
      type: input.type,
      title: input.title,
      body: input.body,
      href: input.href,
    }));
  if (rows.length) await prisma.notification.createMany({ data: rows });
}

export async function notifyUser(input: {
  userId: string;
  familyId?: string;
  type: string;
  title: string;
  body: string;
  href?: string;
}) {
  await prisma.notification.create({ data: input });
}
