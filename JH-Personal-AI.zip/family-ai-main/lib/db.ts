import { PrismaClient } from "@prisma/client";

if (!process.env.DATABASE_URL && process.env.SUPABASE_DB_URL) {
  process.env.DATABASE_URL = process.env.SUPABASE_DB_URL;
}

if (!process.env.DIRECT_DATABASE_URL && process.env.DATABASE_URL) {
  process.env.DIRECT_DATABASE_URL = process.env.DATABASE_URL;
}

function datasourceUrl() {
  const url = process.env.DATABASE_URL;
  if (!url) return undefined;
  const isPooler = /pooler|:6543\b/i.test(url);
  if (process.env.VERCEL && isPooler && !/[?&]pgbouncer=/.test(url)) {
    return `${url}${url.includes("?") ? "&" : "?"}pgbouncer=true&connection_limit=1`;
  }
  return url;
}

const datasource = datasourceUrl();

const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
    ...(datasource ? { datasources: { db: { url: datasource } } } : {}),
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
