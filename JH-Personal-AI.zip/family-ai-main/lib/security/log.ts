const SECRET_KEYS = /secret|password|api[_-]?key|token|authorization|database_url/i;

export function safeDatabaseHost(url = process.env.DATABASE_URL ?? "") {
  if (!url) return "missing";
  try {
    const normalized = url.replace(/^postgres(ql)?:/i, "http:");
    const parsed = new URL(normalized);
    return parsed.hostname || "unknown";
  } catch {
    return "unparseable";
  }
}

export function logServerError(scope: string, error: unknown) {
  const name = error instanceof Error ? error.name : typeof error;
  const message = error instanceof Error ? error.message : "unknown error";
  const sanitized = message
    .replace(/[A-Za-z0-9+/_-]{24,}/g, "[redacted]")
    .replace(/(postgres(?:ql)?:\/\/)([^@/]+)@/i, "$1[redacted]@");
  const extra =
    error && typeof error === "object"
      ? {
          code: "code" in error ? String((error as { code?: unknown }).code ?? "") : undefined,
          clientVersion:
            "clientVersion" in error ? String((error as { clientVersion?: unknown }).clientVersion ?? "") : undefined,
        }
      : {};
  console.error("[server]", {
    scope,
    name,
    message: SECRET_KEYS.test(sanitized) ? name : sanitized,
    dbHost: safeDatabaseHost(),
    ...extra,
  });
}
