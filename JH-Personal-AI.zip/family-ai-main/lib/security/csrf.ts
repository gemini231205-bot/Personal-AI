import { NextRequest } from "next/server";
import { appUrl } from "@/lib/env";
import { ApiError } from "@/lib/api";

const SAFE = new Set(["GET", "HEAD", "OPTIONS"]);

export function assertCsrf(request: NextRequest) {
  if (SAFE.has(request.method)) return;
  const origin = request.headers.get("origin");
  const referer = request.headers.get("referer");
  const allowed = new URL(appUrl()).origin;
  const host = request.headers.get("host");
  const local = host ? `http://${host}` : allowed;
  const allowedOrigins = new Set([allowed, local, `https://${host}`]);

  if (origin && !allowedOrigins.has(origin)) {
    throw new ApiError("FORBIDDEN", "CSRF 검증에 실패했습니다.", 403);
  }
  if (!origin && referer) {
    try {
      const refOrigin = new URL(referer).origin;
      if (!allowedOrigins.has(refOrigin)) {
        throw new ApiError("FORBIDDEN", "CSRF 검증에 실패했습니다.", 403);
      }
    } catch {
      throw new ApiError("FORBIDDEN", "CSRF 검증에 실패했습니다.", 403);
    }
  }
}

export function clientIp(request: NextRequest) {
  return (
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "127.0.0.1"
  );
}
