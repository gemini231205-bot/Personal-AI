import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";

export async function writeAudit(input: {
  action: string;
  userId?: string | null;
  familyId?: string | null;
  metadata?: Record<string, unknown>;
  ip?: string;
}) {
  await prisma.auditLog.create({
    data: {
      action: input.action,
      userId: input.userId ?? undefined,
      familyId: input.familyId ?? undefined,
      metadata: (input.metadata as Prisma.InputJsonValue | undefined) ?? undefined,
      ip: input.ip,
    },
  });
}
