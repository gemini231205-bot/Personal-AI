import { spawnSync } from "node:child_process";

// Fall back to SUPABASE_DB_URL if DATABASE_URL is not explicitly set
if (!process.env.DATABASE_URL && process.env.SUPABASE_DB_URL) {
  process.env.DATABASE_URL = process.env.SUPABASE_DB_URL;
}

const databaseUrl = process.env.DATABASE_URL ?? "";
const authSecret = process.env.AUTH_SECRET ?? "";

if (!databaseUrl) {
  console.error(
    "DATABASE_URL is required. Set DATABASE_URL (or SUPABASE_DB_URL) to a hosted PostgreSQL URL.",
  );
  process.exit(1);
}

if (/localhost|127\.0\.0\.1/.test(databaseUrl)) {
  console.error(
    "DATABASE_URL points to localhost and cannot be reached from the build environment. Use Neon, Supabase, or Vercel Postgres.",
  );
  process.exit(1);
}

if (authSecret.length < 16) {
  console.error("AUTH_SECRET must be set to a random string of at least 16 characters before deploying.");
  process.exit(1);
}

if (!process.env.DIRECT_DATABASE_URL) {
  process.env.DIRECT_DATABASE_URL = databaseUrl;
}

const steps = [
  ["npx", "prisma", "generate"],
  ["npx", "next", "build"],
];

for (const [cmd, ...args] of steps) {
  const result = spawnSync(cmd, args, { stdio: "inherit", env: process.env, shell: true });
  if (result.status) process.exit(result.status);
}
