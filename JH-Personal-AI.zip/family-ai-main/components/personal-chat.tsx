"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  LoaderCircle,
  Paperclip,
  Plus,
  RotateCcw,
  Send,
  Square,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Markdown } from "./markdown";

type Conversation = {
  id: string;
  title: string;
  updatedAt: string;
};

type Message = {
  id: string;
  role: "USER" | "ASSISTANT" | "SYSTEM";
  content: string;
  error?: string | null;
  citations?: { source: string; page?: number }[] | null;
};

type UploadedFile = {
  id: string;
  originalName: string;
  size: number;
};

export function PersonalChat({
  conversationId,
}: {
  conversationId?: string;
}) {
  const router = useRouter();

  const [conversations, setConversations] = useState<
    Conversation[]
  >([]);

  const [messages, setMessages] = useState<Message[]>(
    [],
  );

  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);

  const [selectedFile, setSelectedFile] =
    useState<UploadedFile | null>(null);

  const [uploadingFile, setUploadingFile] =
    useState(false);

  const fileInputRef =
    useRef<HTMLInputElement>(null);

  const abortRef =
    useRef<AbortController | null>(null);

  const sendingRef = useRef(false);

  const endRef =
    useRef<HTMLDivElement>(null);

  function localId(
    kind: "user" | "assistant",
  ) {
    return `${kind}_${crypto.randomUUID()}`;
  }

  const active = useMemo(
    () =>
      conversations.find(
        (c) => c.id === conversationId,
      ),
    [conversations, conversationId],
  );

  async function loadList(q = query) {
    const data = await api<{
      conversations: Conversation[];
    }>(
      `/api/conversations?q=${encodeURIComponent(
        q,
      )}`,
    );

    setConversations(data.conversations);
  }

  async function loadThread(id: string) {
    const data = await api<{
      messages: Message[];
    }>(`/api/conversations/${id}`);

    setMessages(data.messages);
  }

  useEffect(() => {
    loadList()
      .catch((e) => toast.error(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (conversationId) {
      loadThread(conversationId).catch((e) =>
        toast.error(e.message),
      );
    } else {
      setMessages([]);
    }
  }, [conversationId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, busy]);

  async function createConversation() {
    const data = await api<{
      conversation: Conversation;
    }>("/api/conversations", {
      method: "POST",
      body: JSON.stringify({}),
    });

    await loadList();

    router.push(
      `/ai/${data.conversation.id}`,
    );
  }

  async function rename(id: string) {
    const title = window.prompt(
      "대화 이름",
      active?.title ?? "새 대화",
    );

    if (!title) return;

    await api(`/api/conversations/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ title }),
    });

    await loadList();
  }

  async function remove(id: string) {
    if (
      !window.confirm(
        "이 대화를 삭제할까요? 개인 기록만 지워집니다.",
      )
    ) {
      return;
    }

    await api(`/api/conversations/${id}`, {
      method: "DELETE",
    });

    await loadList();

    if (conversationId === id) {
      router.push("/ai");
    }
  }

  async function uploadFile(file: File) {
    setUploadingFile(true);

    try {
      const formData = new FormData();

      formData.append("file", file);

      const data = await api<{
        file: UploadedFile;
      }>("/api/files/personal", {
        method: "POST",
        body: formData,
      });

      setSelectedFile(data.file);

      toast.success(
        `"${file.name}" 업로드 완료`,
      );
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "파일 업로드에 실패했습니다.",
      );
    } finally {
      setUploadingFile(false);

      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  }

  function handleFileChange(
    event: React.ChangeEvent<HTMLInputElement>,
  ) {
    const file =
      event.target.files?.[0];

    if (!file) return;

    void uploadFile(file);
  }

  /*
   * 실제 AI 요청
   *
   * 웹 검색 여부는 이제 클라이언트에서
   * 선택하거나 전달하지 않는다.
   *
   * /api/ai/stream
   *   ↓
   * orchestrateChat()
   *   ↓
   * AI가 검색 필요 여부 판단
   *   ↓
   * 필요하면 Tavily 검색
   *   ↓
   * 최종 답변 생성
   */
  async function send(
    text = draft,
    regen = false,
    attachedFileId?: string,
  ) {
    const cleanText = text.trim();

    const fileId =
      attachedFileId ??
      selectedFile?.id;

    if (!cleanText && !fileId) return;

    if (sendingRef.current) return;

    sendingRef.current = true;

    setBusy(true);
    setDraft("");

    const userLocalId =
      localId("user");

    const assistantLocalId =
      localId("assistant");

    let id = conversationId;

    let newlyCreatedConversation =
      false;

    const fileName =
      selectedFile?.originalName;

    const question =
      cleanText ||
      (fileName
        ? `"${fileName}" 파일의 핵심 내용을 요약해줘.`
        : "첨부한 파일을 분석해줘.");

    const message = fileName
      ? `${question}\n\n[첨부 파일: ${fileName}]`
      : question;

    try {
      /*
       * 새 대화 생성
       */
      if (!id) {
        const created = await api<{
          conversation: Conversation;
        }>("/api/conversations", {
          method: "POST",
          body: JSON.stringify({
            title: question.slice(0, 32),
          }),
        });

        id =
          created.conversation.id;

        newlyCreatedConversation =
          true;
      }

      if (!regen) {
        setMessages((prev) => [
          ...prev.filter(
            (m) =>
              !m.id.startsWith("user_") &&
              !m.id.startsWith("assistant_"),
          ),

          {
            id: userLocalId,
            role: "USER",
            content: message,
          },

          {
            id: assistantLocalId,
            role: "ASSISTANT",
            content: "",
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: assistantLocalId,
            role: "ASSISTANT",
            content: "",
          },
        ]);
      }

      if (!regen) {
        setSelectedFile(null);
      }

      const controller =
        new AbortController();

      abortRef.current =
        controller;

      const res = await fetch(
        "/api/ai/stream",
        {
          method: "POST",

          headers: {
            "Content-Type":
              "application/json",
          },

          /*
           * 중요:
           * searchWeb을 보내지 않는다.
           *
           * 서버의 orchestrateChat이
           * AI에게 검색 필요 여부를 판단시킨다.
           */
          body: JSON.stringify({
            conversationId: id,
            message,
            scope: "personal",
            fileId:
              fileId ?? undefined,
          }),

          signal:
            controller.signal,
        },
      );

      if (!res.ok || !res.body) {
        const json =
          await res
            .json()
            .catch(() => null);

        throw new Error(
          json?.error?.message ??
            "AI 응답에 실패했습니다.",
        );
      }

      const reader =
        res.body.getReader();

      const decoder =
        new TextDecoder();

      let buffer = "";
      let acc = "";
      let finished = false;

      while (true) {
        const {
          value,
          done,
        } = await reader.read();

        if (done) break;

        buffer += decoder.decode(
          value,
          {
            stream: true,
          },
        );

        const parts =
          buffer.split("\n\n");

        buffer =
          parts.pop() ?? "";

        for (const part of parts) {
          const event =
            /event: (\w+)/.exec(
              part,
            )?.[1];

          const dataLine =
            part
              .split("\n")
              .find((line) =>
                line.startsWith(
                  "data: ",
                ),
              );

          if (!dataLine) continue;

          const data =
            JSON.parse(
              dataLine.slice(6),
            );

          if (event === "delta") {
            acc += data.text;

            setMessages(
              (prev) =>
                prev.map((m) =>
                  m.id ===
                  assistantLocalId
                    ? {
                        ...m,
                        content:
                          acc,
                      }
                    : m,
                ),
            );
          }

          if (event === "error") {
            throw new Error(
              data.message,
            );
          }

          if (event === "done") {
            finished = true;
          }
        }
      }

      /*
       * 스트림 종료 후
       * DB의 실제 메시지를 다시 읽는다.
       */
      if (id) {
        await loadThread(id);
      }

      await loadList();

      /*
       * 새 대화라면 완료 후 이동
       */
      if (
        newlyCreatedConversation &&
        id
      ) {
        router.push(`/ai/${id}`);
      }

      void finished;
    } catch (error) {
      if (
        (error as Error).name !==
        "AbortError"
      ) {
        toast.error(
          error instanceof Error
            ? error.message
            : "오류가 발생했습니다.",
        );

        setMessages((prev) =>
          prev.map((m) =>
            m.id ===
            assistantLocalId
              ? {
                  ...m,
                  error:
                    error instanceof
                    Error
                      ? error.message
                      : "AI 응답에 실패했습니다.",
                }
              : m,
          ),
        );
      }
    } finally {
      sendingRef.current =
        false;

      setBusy(false);

      abortRef.current =
        null;
    }
  }

  /*
   * 보내기 버튼 / Enter
   *
   * 이제 팝업을 띄우지 않고
   * 바로 서버의 AI 라우터로 보낸다.
   */
  function requestSend(
    text = draft,
    regen = false,
    attachedFileId?: string,
  ) {
    const cleanText =
      text.trim();

    const fileId =
      attachedFileId ??
      selectedFile?.id;

    if (
      !cleanText &&
      !fileId
    ) {
      return;
    }

    void send(
      text,
      regen,
      attachedFileId,
    );
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr] lg:h-[calc(100vh-8rem)]">
      <aside className="rounded-2xl border border-border bg-card p-3">
        <div className="mb-3 flex items-center justify-between">
          <div>
            <div className="text-xs text-[var(--ai)]">
              🧠 My AI
            </div>

            <div className="font-semibold">
              개인 대화
            </div>
          </div>

          <Button
            size="icon"
            variant="subtle"
            onClick={() =>
              void createConversation()
            }
            aria-label="새 대화"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>

        <Input
          placeholder="대화 검색"
          value={query}
          onChange={(e) => {
            setQuery(
              e.target.value,
            );

            void loadList(
              e.target.value,
            );
          }}
        />

        <div className="mt-3 space-y-1 overflow-y-auto lg:max-h-[calc(100vh-16rem)]">
          {loading && (
            <div className="h-16 animate-pulse rounded-xl bg-muted" />
          )}

          {!loading &&
            conversations.length ===
              0 && (
              <p className="px-2 py-8 text-center text-sm text-muted-foreground">
                아직 개인 대화가 없습니다.
              </p>
            )}

          {conversations.map(
            (c) => (
              <button
                key={c.id}
                type="button"
                onClick={() =>
                  router.push(
                    `/ai/${c.id}`,
                  )
                }
                className={`flex w-full items-center justify-between rounded-xl px-3 py-2 text-left text-sm ${
                  c.id ===
                  conversationId
                    ? "bg-muted"
                    : "hover:bg-muted/60"
                }`}
              >
                <span className="truncate">
                  {c.title}
                </span>

                <Trash2
                  className="h-3.5 w-3.5 opacity-50"
                  onClick={(
                    e,
                  ) => {
                    e.stopPropagation();

                    void remove(
                      c.id,
                    );
                  }}
                />
              </button>
            ),
          )}
        </div>
      </aside>

      <section className="flex min-h-[60vh] flex-col rounded-2xl border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <button
            type="button"
            className="font-medium"
            onClick={() =>
              active &&
              void rename(
                active.id,
              )
            }
          >
            {active?.title ??
              "새 개인 대화"}
          </button>

          <div className="text-xs text-muted-foreground">
            개인 메모리 · 개인 파일만 사용 · 웹 검색은 AI가 판단
          </div>
        </div>

        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {messages.length ===
            0 && (
            <div className="mx-auto max-w-md py-16 text-center text-sm text-muted-foreground">
              나만의 AI입니다. 여기서 나눈 대화는 가족에게 보이지 않습니다.
            </div>
          )}

          {messages.map(
            (m) => (
              <div
                key={m.id}
                className={`flex ${
                  m.role ===
                  "USER"
                    ? "justify-end"
                    : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                    m.role ===
                    "USER"
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  }`}
                >
                  {m.role ===
                    "ASSISTANT" && (
                    <div className="mb-1 text-xs font-medium text-[var(--ai)]">
                      🧠 My AI
                    </div>
                  )}

                  {m.error ? (
                    <div className="text-sm">
                      {m.error}{" "}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          requestSend(
                            messages[
                              messages.length -
                                2
                            ]?.content,
                            true,
                          )
                        }
                      >
                        다시 시도
                      </Button>
                    </div>
                  ) : m.role ===
                    "ASSISTANT" ? (
                    <Markdown
                      content={
                        m.content ||
                        (busy
                          ? "…"
                          : "")
                      }
                    />
                  ) : (
                    <div className="whitespace-pre-wrap text-sm">
                      {m.content}
                    </div>
                  )}

                  {m.citations &&
                    m.citations
                      .length >
                      0 && (
                      <div className="mt-2 text-xs opacity-80">
                        출처:{" "}
                        {m.citations
                          .map(
                            (
                              c,
                            ) =>
                              `${c.source}${
                                c.page
                                  ? ` / ${c.page}페이지`
                                  : ""
                              }`,
                          )
                          .join(
                            ", ",
                          )}
                      </div>
                    )}

                  {m.role ===
                    "ASSISTANT" &&
                    m.content && (
                      <div className="mt-2 flex gap-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            navigator.clipboard.writeText(
                              m.content,
                            )
                          }
                        >
                          복사
                        </Button>

                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            requestSend(
                              messages
                                .filter(
                                  (
                                    x,
                                  ) =>
                                    x.role ===
                                    "USER",
                                )
                                .at(
                                  -1,
                                )
                                ?.content ??
                                "",
                              true,
                            )
                          }
                        >
                          <RotateCcw className="h-3 w-3" />
                          재생성
                        </Button>
                      </div>
                    )}
                </div>
              </div>
            ),
          )}

          <div ref={endRef} />
        </div>

        <form
          className="border-t border-border p-3"
          onSubmit={(e) => {
            e.preventDefault();

            requestSend();
          }}
        >
          {selectedFile && (
            <div className="mb-2 flex items-center gap-2 rounded-xl border border-border bg-muted px-3 py-2 text-sm">
              <Paperclip className="h-4 w-4 shrink-0" />

              <span className="min-w-0 flex-1 truncate">
                {
                  selectedFile.originalName
                }
              </span>

              <button
                type="button"
                className="shrink-0 rounded-md p-1 hover:bg-background"
                onClick={() =>
                  setSelectedFile(
                    null,
                  )
                }
                aria-label="첨부 파일 제거"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          )}

          <div className="flex items-end gap-2">
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept=".pdf,.txt,.csv,.docx,.xlsx,.xls"
              onChange={
                handleFileChange
              }
            />

            <Button
              type="button"
              size="icon"
              variant="outline"
              disabled={
                busy ||
                uploadingFile
              }
              onClick={() =>
                fileInputRef.current?.click()
              }
              aria-label="파일 첨부"
              title="파일 첨부"
            >
              {uploadingFile ? (
                <LoaderCircle className="h-4 w-4 animate-spin" />
              ) : (
                <Paperclip className="h-4 w-4" />
              )}
            </Button>

            <Textarea
              value={draft}
              onChange={(e) =>
                setDraft(
                  e.target.value,
                )
              }
              placeholder={
                selectedFile
                  ? "파일에 대해 질문하세요"
                  : "개인 AI에게 메시지"
              }
              className="min-h-[52px]"
              onKeyDown={(e) => {
                if (
                  e.key ===
                    "Enter" &&
                  !e.shiftKey
                ) {
                  e.preventDefault();

                  requestSend();
                }
              }}
            />

            {busy ? (
              <Button
                type="button"
                variant="outline"
                onClick={() =>
                  abortRef.current?.abort()
                }
              >
                <Square className="h-4 w-4" />
                중지
              </Button>
            ) : (
              <Button
                type="submit"
                disabled={
                  uploadingFile
                }
              >
                <Send className="h-4 w-4" />
                보내기
              </Button>
            )}
          </div>
        </form>
      </section>
    </div>
  );
}
