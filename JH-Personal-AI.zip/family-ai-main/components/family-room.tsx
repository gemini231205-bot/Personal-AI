"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarDays,
  Copy,
  FileSearch,
  Lightbulb,
  MoreHorizontal,
  PenLine,
  Search,
  Sparkles,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client";
import { formatTime, isSameDay } from "@/lib/utils";
import { useEventSource } from "@/hooks/use-event-source";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Markdown } from "./markdown";
import { Dialog, DialogContent, DialogTitle } from "./ui/dialog";

type Member = { user: { id: string; name: string }; lastSeenAt?: string | null; online?: boolean };
type RoomMessage = {
  id: string;
  content: string;
  isAi: boolean;
  aiKind?: string | null;
  createdAt: string;
  editedAt?: string | null;
  deletedAt?: string | null;
  author?: { id: string; name: string } | null;
  replyTo?: { id: string; content: string; author?: { name: string } | null } | null;
  reads?: { userId: string }[];
};

const AI_MENU = [
  { kind: "question", label: "✨ AI에게 질문", icon: Sparkles },
  { kind: "summarize", label: "🧠 대화 요약", icon: Sparkles },
  { kind: "calendar", label: "📅 일정 정리", icon: CalendarDays },
  { kind: "search", label: "🔎 정보 찾기", icon: Search },
  { kind: "idea", label: "💡 아이디어 만들기", icon: Lightbulb },
  { kind: "draft", label: "📝 메시지 작성", icon: PenLine },
  { kind: "files", label: "📁 공유 파일 분석", icon: FileSearch },
  { kind: "free", label: "🤖 자유 질문", icon: Sparkles },
];

export function FamilyRoom({ familyName, userId, memberCount }: { familyName: string; userId: string; memberCount: number }) {
  const [messages, setMessages] = useState<RoomMessage[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [draft, setDraft] = useState("");
  const [query, setQuery] = useState("");
  const [replyTo, setReplyTo] = useState<RoomMessage | null>(null);
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const [aiOpen, setAiOpen] = useState(false);
  const [aiKind, setAiKind] = useState("question");
  const [aiPrompt, setAiPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  async function load() {
    const data = await api<{ messages: RoomMessage[] }>(`/api/room/messages?q=${encodeURIComponent(query)}`);
    setMessages(data.messages);
    const mem = await api<{ members: Member[] }>("/api/family/members");
    setMembers(mem.members);
  }

  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, [query]);

  useEventSource("/api/room/stream", {
    messages: (data) => {
      const payload = JSON.parse(data) as { messages: RoomMessage[] };
      setMessages((prev) => {
        const ids = new Set(prev.map((m) => m.id));
        return [...prev, ...payload.messages.filter((m) => !ids.has(m.id))];
      });
    },
  });

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
    const unread = messages.filter((m) => !m.reads?.some((r) => r.userId === userId)).map((m) => m.id);
    if (unread.length) {
      void api("/api/room/read", { method: "POST", body: JSON.stringify({ messageIds: unread.slice(-20) }) });
    }
  }, [messages, userId]);

  async function send() {
    if (!draft.trim()) return;
    try {
      const data = await api<{ message: RoomMessage }>("/api/room/messages", {
        method: "POST",
        body: JSON.stringify({ content: draft, replyToId: replyTo?.id }),
      });
      setMessages((prev) => [...prev.filter((m) => m.id !== data.message.id), data.message]);
      setDraft("");
      setReplyTo(null);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "전송 실패");
    }
  }

  async function callAi(kind = aiKind, prompt = aiPrompt, messageId?: string) {
    setBusy(true);
    try {
      const data = await api<{ message: RoomMessage }>("/api/room/ai", {
        method: "POST",
        body: JSON.stringify({ kind, prompt, messageId }),
      });
      setMessages((prev) => [...prev, data.message]);
      setAiOpen(false);
      setAiPrompt("");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Family AI 호출 실패");
    } finally {
      setBusy(false);
    }
  }

  const online = useMemo(() => members.filter((m) => m.online).length, [members]);

  return (
    <div className="mx-auto flex h-[calc(100vh-8rem)] max-w-3xl flex-col rounded-2xl border border-border bg-card">
      <header className="flex items-center justify-between border-b border-border px-4 py-3">
        <div>
          <div className="font-semibold">👨‍👩‍👧 {familyName}</div>
          <div className="text-xs text-muted-foreground">
            👥 {members.length || memberCount}명 · 온라인 {online}명 · ✨ Family AI는 공유 데이터만 봅니다
          </div>
        </div>
        <Input
          className="max-w-40"
          placeholder="메시지 검색"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </header>
      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        {messages.length === 0 && (
          <div className="py-16 text-center text-sm text-muted-foreground">
            가족방이 비어 있습니다. 첫 메시지를 남겨 보세요.
          </div>
        )}
        {messages.map((m, i) => {
          const showDate = i === 0 || !isSameDay(messages[i - 1].createdAt, m.createdAt);
          const mine = m.author?.id === userId;
          return (
            <div key={m.id}>
              {showDate && (
                <div className="my-3 text-center text-xs text-muted-foreground">
                  {new Date(m.createdAt).toLocaleDateString("ko-KR")}
                </div>
              )}
              <div className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                    m.isAi ? "border border-[var(--ai)]/30 bg-[color-mix(in_oklab,var(--ai)_12%,var(--card))]" : mine ? "bg-primary text-primary-foreground" : "bg-muted"
                  }`}
                >
                  <div className="mb-1 flex items-center justify-between gap-3 text-xs">
                    <span className={m.isAi ? "font-medium text-[var(--ai)]" : "opacity-80"}>
                      {m.isAi ? "✨ Family AI" : m.author?.name ?? "구성원"}
                    </span>
                    <span className="opacity-60">{formatTime(m.createdAt)}</span>
                  </div>
                  {m.replyTo && (
                    <div className="mb-2 rounded-lg bg-black/10 px-2 py-1 text-xs">
                      {m.replyTo.author?.name}: {m.replyTo.content.slice(0, 60)}
                    </div>
                  )}
                  {m.isAi ? <Markdown content={m.content} /> : <div className="whitespace-pre-wrap text-sm">{m.content}</div>}
                  {m.editedAt && <div className="mt-1 text-[10px] opacity-60">수정됨</div>}
                  <div className="relative mt-2">
                    <button type="button" onClick={() => setMenuFor(menuFor === m.id ? null : m.id)} aria-label="메시지 메뉴">
                      <MoreHorizontal className="h-4 w-4 opacity-60" />
                    </button>
                    {menuFor === m.id && (
                      <div className="absolute z-10 mt-1 w-44 rounded-xl border border-border bg-card p-1 text-sm shadow-[var(--shadow)]">
                        <button className="block w-full rounded-lg px-2 py-1.5 text-left hover:bg-muted" onClick={() => { setReplyTo(m); setMenuFor(null); }}>답장</button>
                        <button className="block w-full rounded-lg px-2 py-1.5 text-left hover:bg-muted" onClick={() => { void navigator.clipboard.writeText(m.content); setMenuFor(null); }}>
                          <Copy className="mr-1 inline h-3 w-3" />복사
                        </button>
                        {mine && !m.isAi && (
                          <>
                            <button
                              className="block w-full rounded-lg px-2 py-1.5 text-left hover:bg-muted"
                              onClick={async () => {
                                const content = window.prompt("메시지 수정", m.content);
                                if (!content) return;
                                await api("/api/room/messages", { method: "PATCH", body: JSON.stringify({ id: m.id, content }) });
                                await load();
                                setMenuFor(null);
                              }}
                            >
                              수정
                            </button>
                            <button
                              className="block w-full rounded-lg px-2 py-1.5 text-left hover:bg-muted"
                              onClick={async () => {
                                await api("/api/room/messages", { method: "DELETE", body: JSON.stringify({ id: m.id }) });
                                await load();
                                setMenuFor(null);
                              }}
                            >
                              <Trash2 className="mr-1 inline h-3 w-3" />삭제
                            </button>
                          </>
                        )}
                        <button
                          className="block w-full rounded-lg px-2 py-1.5 text-left hover:bg-muted"
                          onClick={() => {
                            setMenuFor(null);
                            void callAi("ask_message", `이 메시지에 대해 가족과 함께 답해줘: ${m.content}`, m.id);
                          }}
                        >
                          ✨ AI에게 물어보기
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      {replyTo && (
        <div className="border-t border-border px-4 py-2 text-xs">
          {replyTo.author?.name}에게 답장 · {replyTo.content.slice(0, 40)}
          <button className="ml-2 underline" onClick={() => setReplyTo(null)}>취소</button>
        </div>
      )}
      <div className="flex items-end gap-2 border-t border-border p-3">
        <Input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="메시지를 입력하세요"
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              void send();
            }
          }}
        />
        <Button type="button" onClick={() => void send()}>보내기</Button>
        <Button type="button" variant="ai" onClick={() => setAiOpen(true)}>
          ✨ AI 호출
        </Button>
      </div>
      <Dialog open={aiOpen} onOpenChange={setAiOpen}>
        <DialogContent>
          <DialogTitle>✨ Family AI 호출</DialogTitle>
          <p className="mb-3 text-sm text-muted-foreground">
            Family AI는 가족방, 공유 메모리, 공유 파일, 일정, 쇼핑만 봅니다. 개인 대화는 가져가지 않습니다.
          </p>
          <div className="grid gap-2">
            {AI_MENU.map((item) => (
              <button
                key={item.kind}
                type="button"
                onClick={() => {
                  setAiKind(item.kind);
                  if (item.kind === "summarize") void callAi("summarize", "이번 가족 대화를 회의처럼 정리해줘.");
                  if (item.kind === "calendar") void callAi("calendar", "이번 주 가족 모두가 가능한 날을 찾아줘.");
                }}
                className={`rounded-xl border px-3 py-2 text-left text-sm ${aiKind === item.kind ? "border-primary" : "border-border"}`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <Input
            className="mt-3"
            value={aiPrompt}
            onChange={(e) => setAiPrompt(e.target.value)}
            placeholder="질문을 입력하거나 위 작업을 고르세요"
          />
          <Button className="mt-3 w-full" disabled={busy} onClick={() => void callAi()}>
            {busy ? "생각 중…" : "Family AI에게 묻기"}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
