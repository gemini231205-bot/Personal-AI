"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, MoreHorizontal } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/client";
import { formatTime, isSameDay } from "@/lib/utils";
import { useEventSource } from "@/hooks/use-event-source";
import { Avatar } from "./avatar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

type Peer = { id: string; name: string; avatarColor: string };
type DmItem = {
  id: string;
  peer: Peer | null;
  lastMessage: { content: string; createdAt: string } | null;
  unread: number;
};
type Member = { user: { id: string; name: string; avatarColor?: string }; role: string };
type ChatMessage = {
  id: string;
  content: string;
  createdAt: string;
  authorId: string | null;
  deletedAt?: string | null;
  editedAt?: string | null;
  author?: { id: string; name: string; avatarColor: string } | null;
};

export function FamilyMessenger({
  userId,
  conversationId,
}: {
  userId: string;
  conversationId?: string;
}) {
  const router = useRouter();
  const [items, setItems] = useState<DmItem[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [memberCount, setMemberCount] = useState(0);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [peer, setPeer] = useState<Peer | null>(null);
  const [draft, setDraft] = useState("");
  const [menuFor, setMenuFor] = useState<string | null>(null);
  const endRef = useRef<HTMLDivElement>(null);

  async function loadList() {
    const [dms, mem] = await Promise.all([
      api<{ conversations: DmItem[] }>("/api/dm"),
      api<{ members: Member[]; memberCount: number }>("/api/family/members"),
    ]);
    setItems(dms.conversations);
    setMembers(mem.members);
    setMemberCount(mem.memberCount);
  }

  async function loadThread(id: string) {
    const data = await api<{ conversation: { peer: Peer | null }; messages: ChatMessage[] }>(`/api/dm/${id}`);
    setPeer(data.conversation.peer);
    setMessages(data.messages);
    await api(`/api/dm/${id}/read`, { method: "POST", body: JSON.stringify({}) });
  }

  useEffect(() => {
    void loadList().catch((e) => toast.error(e.message));
  }, []);

  useEffect(() => {
    if (!conversationId) {
      setMessages([]);
      setPeer(null);
      return;
    }
    void loadThread(conversationId).catch((e) => toast.error(e.message));
  }, [conversationId]);

  useEventSource(conversationId ? `/api/dm/${conversationId}/stream` : null, {
    messages: (data) => {
      const payload = JSON.parse(data) as { messages: ChatMessage[] };
      setMessages((prev) => {
        const ids = new Set(prev.map((m) => m.id));
        return [...prev, ...payload.messages.filter((m) => !ids.has(m.id))];
      });
    },
  });

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function startDm(peerId: string) {
    const data = await api<{ conversation: { id: string } }>("/api/dm", {
      method: "POST",
      body: JSON.stringify({ userId: peerId }),
    });
    router.push(`/family/dm/${data.conversation.id}`);
  }

  async function send() {
    if (!conversationId || !draft.trim()) return;
    const content = draft;
    setDraft("");
    const data = await api<{ message: ChatMessage }>(`/api/dm/${conversationId}/messages`, {
      method: "POST",
      body: JSON.stringify({ content }),
    });
    setMessages((prev) => [...prev.filter((m) => m.id !== data.message.id), data.message]);
    await loadList();
  }

  const others = members.filter((m) => m.user.id !== userId);
  const showChat = Boolean(conversationId);

  return (
    <div className="grid h-[calc(100vh-8rem)] overflow-hidden rounded-2xl border border-border bg-card lg:grid-cols-[280px_1fr]">
      <aside className={`flex flex-col border-r border-border ${showChat ? "hidden lg:flex" : "flex"}`}>
        <div className="border-b border-border p-3">
          <div className="text-xs text-muted-foreground">가족 대화</div>
          <div className="font-semibold">구성원 {memberCount}명</div>
        </div>
        <div className="flex-1 space-y-1 overflow-y-auto p-2">
          <Link
            href="/family/chat"
            className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-muted"
          >
            <Avatar name="가족" color="teal" />
            <div>
              <div className="text-sm font-medium">가족 전체</div>
              <div className="text-xs text-muted-foreground">Family Room · {memberCount}명</div>
            </div>
          </Link>
          {others.map((m) => {
            const existing = items.find((i) => i.peer?.id === m.user.id);
            return (
              <button
                key={m.user.id}
                type="button"
                onClick={() => void (existing ? router.push(`/family/dm/${existing.id}`) : startDm(m.user.id))}
                className={`flex w-full items-center gap-3 rounded-xl px-2 py-2 text-left hover:bg-muted ${existing?.id === conversationId ? "bg-muted" : ""}`}
              >
                <Avatar name={m.user.name} color={m.user.avatarColor} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-sm font-medium">{m.user.name}</span>
                    {existing?.lastMessage && (
                      <span className="text-[10px] text-muted-foreground">
                        {formatTime(existing.lastMessage.createdAt)}
                      </span>
                    )}
                  </div>
                  <div className="truncate text-xs text-muted-foreground">
                    {existing?.lastMessage?.content ?? "1:1 채팅 시작"}
                  </div>
                </div>
                {existing && existing.unread > 0 && (
                  <span className="rounded-full bg-primary px-1.5 text-[10px] text-primary-foreground">
                    {existing.unread}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </aside>
      <section className={`flex min-h-0 flex-col ${showChat ? "flex" : "hidden lg:flex"}`}>
        {!conversationId && (
          <div className="flex flex-1 items-center justify-center p-6 text-sm text-muted-foreground">
            왼쪽에서 가족 구성원을 선택해 1:1 채팅을 시작하세요. 가족 전체 대화는 Family Room입니다.
          </div>
        )}
        {conversationId && (
          <>
            <header className="flex items-center gap-3 border-b border-border px-3 py-2">
              <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => router.push("/family/dm")}>
                <ArrowLeft className="h-4 w-4" />
              </Button>
              {peer && <Avatar name={peer.name} color={peer.avatarColor} />}
              <div>
                <div className="font-medium">{peer?.name ?? "1:1 채팅"}</div>
                <div className="text-xs text-muted-foreground">개인 DM · Family Room과 분리됨</div>
              </div>
            </header>
            <div className="flex-1 space-y-3 overflow-y-auto p-4">
              {messages.length === 0 && (
                <p className="py-12 text-center text-sm text-muted-foreground">아직 메시지가 없습니다.</p>
              )}
              {messages.map((m, i) => {
                const mine = m.authorId === userId;
                const showDate = i === 0 || !isSameDay(messages[i - 1].createdAt, m.createdAt);
                return (
                  <div key={m.id}>
                    {showDate && (
                      <div className="my-2 text-center text-xs text-muted-foreground">
                        {new Date(m.createdAt).toLocaleDateString("ko-KR")}
                      </div>
                    )}
                    <div className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                      <div className={`max-w-[80%] rounded-2xl px-3 py-2 ${mine ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                        <div className="whitespace-pre-wrap text-sm">{m.content}</div>
                        <div className="mt-1 text-[10px] opacity-70">
                          {formatTime(m.createdAt)}
                          {m.editedAt && !m.deletedAt ? " · 수정됨" : ""}
                        </div>
                        {mine && !m.deletedAt && (
                          <div className="relative mt-1">
                            <button type="button" onClick={() => setMenuFor(menuFor === m.id ? null : m.id)}>
                              <MoreHorizontal className="h-3 w-3 opacity-70" />
                            </button>
                            {menuFor === m.id && (
                              <div className="absolute right-0 z-10 mt-1 w-28 rounded-xl border border-border bg-card p-1 text-xs text-foreground">
                                <button
                                  className="block w-full rounded-lg px-2 py-1 text-left hover:bg-muted"
                                  onClick={async () => {
                                    const content = window.prompt("메시지 수정", m.content);
                                    if (!content) return;
                                    await api(`/api/dm/${conversationId}/messages`, {
                                      method: "PATCH",
                                      body: JSON.stringify({ messageId: m.id, content }),
                                    });
                                    await loadThread(conversationId);
                                    setMenuFor(null);
                                  }}
                                >
                                  수정
                                </button>
                                <button
                                  className="block w-full rounded-lg px-2 py-1 text-left hover:bg-muted"
                                  onClick={async () => {
                                    await api(`/api/dm/${conversationId}/messages`, {
                                      method: "DELETE",
                                      body: JSON.stringify({ messageId: m.id }),
                                    });
                                    await loadThread(conversationId);
                                    setMenuFor(null);
                                  }}
                                >
                                  삭제
                                </button>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={endRef} />
            </div>
            <form
              className="flex gap-2 border-t border-border p-3"
              onSubmit={(e) => {
                e.preventDefault();
                void send();
              }}
            >
              <Input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                placeholder="메시지 입력"
              />
              <Button type="submit">전송</Button>
            </form>
          </>
        )}
      </section>
    </div>
  );
}
