"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { Brain, Files, Home, Search, Settings } from "lucide-react";
import { useMe } from "@/hooks/use-me";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/dashboard", label: "홈", icon: Home },
  { href: "/ai", label: "JH AI", icon: Brain },
  { href: "/memory", label: "내 기억", icon: Brain },
  { href: "/files", label: "내 파일", icon: Files },
  { href: "/search", label: "검색", icon: Search },
  { href: "/settings", label: "설정", icon: Settings },
];

const MOBILE = [
  { href: "/dashboard", label: "홈", icon: Home },
  { href: "/ai", label: "JH AI", icon: Brain },
  { href: "/memory", label: "기억", icon: Brain },
  { href: "/files", label: "파일", icon: Files },
  { href: "/settings", label: "설정", icon: Settings },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { data, loading } = useMe();

  useEffect(() => {
    if (!loading && !data?.user) router.replace("/login");
  }, [loading, data?.user, router]);

  if (loading || !data?.user) {
    return (
      <div className="flex min-h-screen items-center justify-center text-muted-foreground">
        JH AI를 불러오는 중…
      </div>
    );
  }

  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[240px_1fr]">
      <aside className="hidden border-r border-border bg-card/80 p-4 lg:flex lg:flex-col">
        <Link href="/dashboard" className="mb-6 px-2">
          <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Personal AI</div>
          <div className="text-lg font-semibold">JH AI</div>
        </Link>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex items-center gap-2 rounded-xl px-3 py-2 text-sm",
                  active ? "bg-primary text-primary-foreground" : "hover:bg-muted",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-4 rounded-xl bg-muted p-3 text-sm">
          <div className="font-medium">{data.user.name}</div>
          <div className="text-xs text-muted-foreground">{data.user.email}</div>
        </div>
      </aside>

      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-30 border-b border-border bg-background/80 px-4 py-3 backdrop-blur">
          <div className="text-sm text-muted-foreground">🧠 Personal AI</div>
          <div className="font-semibold">JH AI</div>
        </header>

        <main className="flex-1 px-4 pb-24 pt-4 lg:px-8 lg:pb-8">{children}</main>

        <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-border bg-card/95 px-1 py-2 backdrop-blur lg:hidden">
          {MOBILE.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex flex-col items-center gap-1 rounded-xl py-1 text-[11px]",
                  active ? "text-primary" : "text-muted-foreground",
                )}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}

