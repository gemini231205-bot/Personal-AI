import { cn, initials } from "@/lib/utils";

const COLORS: Record<string, string> = {
  amber: "bg-amber-500",
  teal: "bg-teal-600",
  violet: "bg-violet-600",
  rose: "bg-rose-500",
  sky: "bg-sky-600",
};

export function Avatar({
  name,
  color = "amber",
  className,
}: {
  name: string;
  color?: string;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-xs font-semibold text-white",
        COLORS[color] ?? "bg-primary",
        className,
      )}
    >
      {initials(name)}
    </span>
  );
}
