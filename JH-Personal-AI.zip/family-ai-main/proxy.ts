import { NextRequest, NextResponse } from "next/server";
import { SITE_COOKIE, sitePasswordEnabled, verifySiteCookie } from "@/lib/auth/site-gate";

const PUBLIC = ["/", "/login", "/signup", "/gate", "/api/auth/login", "/api/auth/signup", "/api/site/unlock"];

/**
 * Next.js 16 request gate (proxy, Node runtime).
 * Site-password cookie is a SHA-256 digest — never the password.
 * Typed PRIVATE_SITE_PASSWORD / SITE_PASSWORD is checked only in /api/site/unlock.
 * Login sessions are validated on the server (Prisma + node:crypto), not here.
 */
export async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  if (pathname.startsWith("/_next") || pathname.includes(".")) {
    return NextResponse.next();
  }

  if (sitePasswordEnabled() && !pathname.startsWith("/api/site") && pathname !== "/gate") {
    const unlocked = await verifySiteCookie(request.cookies.get(SITE_COOKIE)?.value);
    if (!unlocked) {
      return NextResponse.redirect(new URL("/gate", request.url));
    }
  }

  if (PUBLIC.includes(pathname) || pathname.startsWith("/api/auth") || pathname.startsWith("/api/site")) {
    return NextResponse.next();
  }
  const token = request.cookies.get("family_ai_session")?.value;
  if (
    !token &&
    (pathname.startsWith("/dashboard") ||
      pathname.startsWith("/ai") ||
      pathname.startsWith("/family") ||
      pathname.startsWith("/settings") ||
      pathname.startsWith("/onboarding") ||
      pathname.startsWith("/memory") ||
      pathname.startsWith("/files") ||
      pathname.startsWith("/search") ||
      pathname.startsWith("/notifications"))
  ) {
    return NextResponse.redirect(new URL("/login", request.url));
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
