export type Scope = "personal" | "family";
