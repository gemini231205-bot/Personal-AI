"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";
import { formatDate } from "@/lib/utils";

type FileRow = { id: string; originalName: string; size: number; createdAt: string };

export default function PersonalFilesPage() {
  const [files, setFiles] = useState<FileRow[]>([]);
  const [q, setQ] = useState("");

  async function load(query = q) {
    const data = await api<{ files: FileRow[] }>(`/api/files/personal?q=${encodeURIComponent(query)}`);
    setFiles(data.files);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, []);

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">개인 파일</h1>
      <p className="text-sm text-muted-foreground">My AI만 분석합니다. Family AI는 이 폴더를 보지 않습니다.</p>
      <div className="flex gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="파일 검색" />
        <Button variant="outline" onClick={() => void load()}>검색</Button>
        <label className="inline-flex h-10 cursor-pointer items-center rounded-xl bg-primary px-4 text-sm text-primary-foreground">
          업로드
          <input
            type="file"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              const form = new FormData();
              form.append("file", file);
              const res = await fetch("/api/files/personal", { method: "POST", body: form });
              const json = await res.json();
              if (!json.success) toast.error(json.error.message);
              else await load();
            }}
          />
        </label>
      </div>
      {files.map((f) => (
        <Card key={f.id} className="flex items-center justify-between">
          <div>
            <div className="font-medium">{f.originalName}</div>
            <div className="text-xs text-muted-foreground">{formatDate(f.createdAt)}</div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" asChild>
              <a href={`/api/files/${f.id}`}>다운로드</a>
            </Button>
            <Button size="sm" variant="ghost" onClick={async () => { await fetch(`/api/files/${f.id}`, { method: "DELETE" }); await load(); }}>
              삭제
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
