import { PersonalChat } from "@/components/personal-chat";

export default function AiPage() {
  return <PersonalChat />;
}
