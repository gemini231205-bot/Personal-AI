import { PersonalChat } from "@/components/personal-chat";

export default async function ConversationPage({
  params,
}: {
  params: Promise<{ conversationId: string }>;
}) {
  const { conversationId } = await params;
  return <PersonalChat conversationId={conversationId} />;
}
