"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/client";

type Memory = { id: string; title: string; content: string; sharedToFamily: boolean };

export default function PersonalMemoryPage() {
  const [memories, setMemories] = useState<Memory[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  async function load() {
    const data = await api<{ memories: Memory[] }>("/api/memories/personal");
    setMemories(data.memories);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-3xl font-semibold">개인 메모리</h1>
        <p className="text-muted-foreground">My AI만 봅니다. 가족에게 공유할 때는 매번 확인합니다.</p>
      </div>
      <Card>
        <form
          className="space-y-3"
          onSubmit={async (e) => {
            e.preventDefault();
            const res = await api<{ blocked?: boolean; message?: string; memory?: Memory }>("/api/memories/personal", {
              method: "POST",
              body: JSON.stringify({ title, content }),
            });
            if (res.blocked) {
              toast.error(res.message);
              return;
            }
            setTitle("");
            setContent("");
            await load();
          }}
        >
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="좋아하는 것, 프로젝트, 요청한 기억" required />
          <Textarea value={content} onChange={(e) => setContent(e.target.value)} required />
          <Button type="submit">개인 기억 저장</Button>
        </form>
      </Card>
      {memories.map((m) => (
        <Card key={m.id}>
          <h2 className="font-semibold">{m.title}</h2>
          <p className="mt-2 text-sm">{m.content}</p>
          <div className="mt-3 flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={async () => {
                if (!window.confirm("이 정보를 Family Memory에 공유할까요?")) return;
                await api("/api/memories/personal", {
                  method: "PATCH",
                  body: JSON.stringify({ id: m.id, sharedToFamily: true }),
                });
                toast.success("가족에게 공유했습니다.");
                await load();
              }}
            >
              {m.sharedToFamily ? "공유됨" : "가족에게 공유"}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={async () => {
                await api("/api/memories/personal", { method: "DELETE", body: JSON.stringify({ id: m.id }) });
                await load();
              }}
            >
              삭제
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
