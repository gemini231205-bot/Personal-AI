import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { Card } from "@/components/ui/card";

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const [conversations, memories, files] = await Promise.all([
    prisma.conversation.findMany({
      where: { userId: user.id, scope: "PERSONAL" },
      orderBy: { updatedAt: "desc" },
      take: 5,
    }),
    prisma.personalMemory.count({ where: { userId: user.id } }),
    prisma.personalFile.count({ where: { userId: user.id } }),
  ]);

  return (
    <div className="space-y-6">
      <div>
        <div className="text-xs text-[var(--ai)]">🧠 Personal AI</div>
        <h1 className="text-3xl font-semibold">안녕, {user.name}!</h1>
        <p className="mt-1 text-muted-foreground">오늘도 JH AI와 작업을 이어가 보자.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Link href="/ai">
          <Card className="h-full transition hover:-translate-y-0.5">
            <h2 className="font-semibold">🧠 JH AI</h2>
            <p className="mt-2 text-sm text-muted-foreground">대화하고, 코딩하고, 질문하세요.</p>
          </Card>
        </Link>
        <Link href="/memory">
          <Card className="h-full transition hover:-translate-y-0.5">
            <h2 className="font-semibold">기억</h2>
            <p className="mt-2 text-sm text-muted-foreground">{memories}개의 개인 기억이 있습니다.</p>
          </Card>
        </Link>
        <Link href="/files">
          <Card className="h-full transition hover:-translate-y-0.5">
            <h2 className="font-semibold">파일</h2>
            <p className="mt-2 text-sm text-muted-foreground">{files}개의 개인 파일이 있습니다.</p>
          </Card>
        </Link>
      </div>

      <Card>
        <div className="flex items-center justify-between">
          <h2 className="font-semibold">최근 대화</h2>
          <Link className="text-sm underline" href="/ai">전체 보기</Link>
        </div>
        {conversations.length === 0 ? (
          <p className="mt-4 text-sm text-muted-foreground">아직 대화가 없습니다. JH AI에서 첫 대화를 시작해 보세요.</p>
        ) : (
          <ul className="mt-4 space-y-2">
            {conversations.map((c) => (
              <li key={c.id}>
                <Link href={`/ai/${c.id}`} className="block rounded-xl px-3 py-2 text-sm hover:bg-muted">
                  {c.title}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
