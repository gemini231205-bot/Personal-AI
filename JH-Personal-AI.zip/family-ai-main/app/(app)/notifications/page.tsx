"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/client";

type Note = { id: string; title: string; body: string; href?: string | null; readAt?: string | null; createdAt: string };

export default function NotificationsPage() {
  const [notes, setNotes] = useState<Note[]>([]);

  async function load() {
    const data = await api<{ notifications: Note[] }>("/api/notifications");
    setNotes(data.notifications);
  }
  useEffect(() => {
    void load();
  }, []);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold">알림</h1>
        <Button variant="outline" onClick={async () => { await api("/api/notifications", { method: "PATCH", body: JSON.stringify({ all: true }) }); await load(); }}>
          모두 읽음
        </Button>
      </div>
      {notes.length === 0 && <p className="text-sm text-muted-foreground">알림이 없습니다.</p>}
      {notes.map((n) => (
        <Card key={n.id} className={n.readAt ? "opacity-70" : ""}>
          <Link href={n.href ?? "/dashboard"} onClick={() => void api("/api/notifications", { method: "PATCH", body: JSON.stringify({ id: n.id }) })}>
            <div className="font-medium">{n.title}</div>
            <p className="text-sm text-muted-foreground">{n.body}</p>
          </Link>
        </Card>
      ))}
    </div>
  );
}
