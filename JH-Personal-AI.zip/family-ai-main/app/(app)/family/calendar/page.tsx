"use client";

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/client";
import { addMonths, format, startOfMonth } from "date-fns";
import { ko } from "date-fns/locale";

type Event = {
  id: string;
  title: string;
  description?: string | null;
  location?: string | null;
  startsAt: string;
  endsAt: string;
  recurrence: string;
};

export default function CalendarPage() {
  const [month, setMonth] = useState(startOfMonth(new Date()));
  const [events, setEvents] = useState<Event[]>([]);
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [description, setDescription] = useState("");
  const [startsAt, setStartsAt] = useState("");
  const [endsAt, setEndsAt] = useState("");
  const [recurrence, setRecurrence] = useState("NONE");
  const [view, setView] = useState<"month" | "week" | "today">("month");

  async function load(next = month) {
    const from = next.toISOString();
    const to = addMonths(next, 1).toISOString();
    const data = await api<{ events: Event[] }>(`/api/calendar?from=${from}&to=${to}`);
    setEvents(data.events);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, [month]);

  const todayEvents = useMemo(
    () => events.filter((e) => new Date(e.startsAt).toDateString() === new Date().toDateString()),
    [events],
  );
  const shown = view === "today" ? todayEvents : events;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-semibold">가족 캘린더</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setMonth(addMonths(month, -1))}>이전</Button>
          <div className="px-2 py-2 text-sm">{format(month, "yyyy년 M월", { locale: ko })}</div>
          <Button variant="outline" onClick={() => setMonth(addMonths(month, 1))}>다음</Button>
          <Button variant={view === "today" ? "default" : "ghost"} onClick={() => setView("today")}>오늘</Button>
          <Button variant={view === "month" ? "default" : "ghost"} onClick={() => setView("month")}>월간</Button>
        </div>
      </div>
      <Card>
        <form
          className="grid gap-3 md:grid-cols-2"
          onSubmit={async (e) => {
            e.preventDefault();
            await api("/api/calendar", {
              method: "POST",
              body: JSON.stringify({ title, location, description, startsAt, endsAt, recurrence }),
            });
            setTitle("");
            await load();
          }}
        >
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="일정 제목" required />
          <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="장소" />
          <Input type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} required />
          <Input type="datetime-local" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} required />
          <select className="h-10 rounded-xl border border-border bg-card px-3" value={recurrence} onChange={(e) => setRecurrence(e.target.value)}>
            <option value="NONE">반복 없음</option>
            <option value="DAILY">매일</option>
            <option value="WEEKLY">매주</option>
            <option value="MONTHLY">매월</option>
            <option value="YEARLY">매년</option>
          </select>
          <Textarea className="md:col-span-2" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="설명" />
          <Button type="submit">일정 추가</Button>
        </form>
      </Card>
      {shown.length === 0 && <p className="text-sm text-muted-foreground">이 기간에 일정이 없습니다.</p>}
      {shown.map((e) => (
        <Card key={e.id} className="flex items-start justify-between gap-3">
          <div>
            <h2 className="font-semibold">{e.title}</h2>
            <p className="text-sm text-muted-foreground">
              {new Date(e.startsAt).toLocaleString("ko-KR")} – {new Date(e.endsAt).toLocaleString("ko-KR")}
              {e.location ? ` · ${e.location}` : ""}
            </p>
            {e.description && <p className="mt-2 text-sm">{e.description}</p>}
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={async () => {
                const next = window.prompt("일정 제목", e.title);
                if (!next) return;
                await api("/api/calendar", { method: "PATCH", body: JSON.stringify({ id: e.id, title: next }) });
                await load();
              }}
            >
              수정
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={async () => {
                if (!window.confirm("이 일정을 삭제할까요?")) return;
                await api("/api/calendar", { method: "DELETE", body: JSON.stringify({ id: e.id }) });
                await load();
              }}
            >
              삭제
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
