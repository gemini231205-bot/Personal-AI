import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { FamilyRoom } from "@/components/family-room";

export default async function FamilyChatPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const membership = user.memberships[0];
  if (!membership) redirect("/onboarding");
  const count = await prisma.familyMember.count({ where: { familyId: membership.familyId } });
  return (
    <FamilyRoom
      familyName={membership.family.name}
      userId={user.id}
      memberCount={count}
    />
  );
}
