"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";

type Item = {
  id: string;
  name: string;
  quantity: number;
  category?: string | null;
  notes?: string | null;
  completed: boolean;
  assignee?: { name: string } | null;
};

export default function ShoppingPage() {
  const [items, setItems] = useState<Item[]>([]);
  const [name, setName] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [category, setCategory] = useState("");

  async function load() {
    const data = await api<{ list: { items: Item[] } }>("/api/shopping");
    setItems(data.list.items);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, []);

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">장보기 목록</h1>
      <form
        className="grid gap-2 md:grid-cols-[1fr_80px_140px_auto]"
        onSubmit={async (e) => {
          e.preventDefault();
          await api("/api/shopping", { method: "POST", body: JSON.stringify({ name, quantity, category }) });
          setName("");
          await load();
        }}
      >
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="우유" required />
        <Input type="number" min={1} value={quantity} onChange={(e) => setQuantity(Number(e.target.value))} />
        <Input value={category} onChange={(e) => setCategory(e.target.value)} placeholder="카테고리" />
        <Button type="submit">추가</Button>
      </form>
      {items.length === 0 && <p className="text-sm text-muted-foreground">목록이 비어 있습니다.</p>}
      {items.map((item) => (
        <Card key={item.id} className="flex items-center justify-between gap-3">
          <label className="flex items-center gap-3 text-sm">
            <input
              type="checkbox"
              checked={item.completed}
              onChange={async () => {
                await api("/api/shopping", { method: "PATCH", body: JSON.stringify({ id: item.id, completed: !item.completed }) });
                await load();
              }}
            />
            <span className={item.completed ? "line-through opacity-60" : ""}>
              {item.name} × {item.quantity}
              {item.category ? ` · ${item.category}` : ""}
            </span>
          </label>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={async () => {
                await api("/api/shopping", { method: "PATCH", body: JSON.stringify({ id: item.id, quantity: item.quantity + 1 }) });
                await load();
              }}
            >
              +
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={async () => {
                await api("/api/shopping", { method: "DELETE", body: JSON.stringify({ id: item.id }) });
                await load();
              }}
            >
              삭제
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
