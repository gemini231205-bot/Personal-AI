"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";

type Poll = {
  id: string;
  question: string;
  closed: boolean;
  options: { id: string; label: string; votes: { userId: string }[] }[];
  votes: { userId: string }[];
};

export default function PollsPage() {
  const [polls, setPolls] = useState<Poll[]>([]);
  const [userId, setUserId] = useState("");
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState("한강\n영화\n놀이공원\n집");

  async function load() {
    const data = await api<{ polls: Poll[]; userId: string }>("/api/polls");
    setPolls(data.polls);
    setUserId(data.userId);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, []);

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">가족 투표</h1>
      <Card>
        <form
          className="space-y-3"
          onSubmit={async (e) => {
            e.preventDefault();
            await api("/api/polls", {
              method: "POST",
              body: JSON.stringify({ question, options: options.split("\n").map((s) => s.trim()).filter(Boolean) }),
            });
            setQuestion("");
            await load();
          }}
        >
          <Input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="이번 주말 어디 갈까?" required />
          <textarea className="min-h-28 w-full rounded-xl border border-border bg-card p-3 text-sm" value={options} onChange={(e) => setOptions(e.target.value)} />
          <Button type="submit">투표 만들기</Button>
        </form>
      </Card>
      {polls.map((poll) => (
        <Card key={poll.id}>
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">{poll.question}</h2>
            {!poll.closed && (
              <Button size="sm" variant="outline" onClick={async () => { await api("/api/polls", { method: "PATCH", body: JSON.stringify({ id: poll.id, closed: true }) }); await load(); }}>
                종료
              </Button>
            )}
          </div>
          <div className="mt-3 space-y-2">
            {poll.options.map((opt, i) => (
              <button
                key={opt.id}
                type="button"
                disabled={poll.closed || poll.votes.some((v) => v.userId === userId)}
                onClick={async () => {
                  try {
                    await api("/api/polls", { method: "PATCH", body: JSON.stringify({ id: poll.id, optionId: opt.id }) });
                    await load();
                  } catch (error) {
                    toast.error(error instanceof Error ? error.message : "투표 실패");
                  }
                }}
                className="flex w-full items-center justify-between rounded-xl border border-border px-3 py-2 text-left text-sm disabled:opacity-70"
              >
                <span>
                  {i + 1}. {opt.label}
                </span>
                <span>{opt.votes.length}표</span>
              </button>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
}
