"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/client";
import { Markdown } from "@/components/markdown";

const ACTIONS = [
  { kind: "summarize", title: "가족 회의 AI", prompt: "최근 가족 대화를 회의록으로 정리해줘. 결정사항, 할 일, 담당자, 기한, 미해결." },
  { kind: "calendar", title: "일정 조율", prompt: "이번 주 가족 모두가 가능한 날을 찾아줘." },
  { kind: "free", title: "식사/메뉴 AI", prompt: "오늘 저녁 메뉴를 가족 공유 선호만 보고 제안해줘. 개인 건강정보는 쓰지 마." },
  { kind: "files", title: "공유 파일 분석", prompt: "가족 공유 파일에서 중요한 내용을 요약하고 출처를 밝혀줘." },
];

export default function FamilyAiPage() {
  const [prompt, setPrompt] = useState("");
  const [answer, setAnswer] = useState("");
  const [busy, setBusy] = useState(false);

  async function run(kind: string, text: string) {
    setBusy(true);
    try {
      const data = await api<{ message: { content: string } }>("/api/room/ai", {
        method: "POST",
        body: JSON.stringify({ kind, prompt: text }),
      });
      setAnswer(data.message.content);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "호출 실패");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-5">
      <div>
        <div className="text-xs text-[var(--ai)]">✨ Family AI</div>
        <h1 className="text-3xl font-semibold">가족이 함께 쓰는 AI</h1>
        <p className="text-muted-foreground">개인 대화·개인 메모리·개인 파일은 자동으로 열리지 않습니다.</p>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {ACTIONS.map((a) => (
          <Card key={a.kind}>
            <h2 className="font-semibold">{a.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{a.prompt}</p>
            <Button className="mt-4" variant="ai" disabled={busy} onClick={() => void run(a.kind, a.prompt)}>
              실행
            </Button>
          </Card>
        ))}
      </div>
      <Card>
        <h2 className="font-semibold">자유 질문</h2>
        <Textarea className="mt-3" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="가족 공유 범위에서 물어볼 내용" />
        <Button className="mt-3" disabled={busy} onClick={() => void run("free", prompt)}>✨ 질문하기</Button>
        {answer && (
          <div className="mt-4 rounded-xl bg-muted p-4">
            <div className="mb-2 text-xs text-[var(--ai)]">✨ Family AI</div>
            <Markdown content={answer} />
          </div>
        )}
      </Card>
    </div>
  );
}
