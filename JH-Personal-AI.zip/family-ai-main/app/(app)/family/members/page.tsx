"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar } from "@/components/avatar";
import { api } from "@/lib/client";
import { useMe } from "@/hooks/use-me";

type Member = {
  id: string;
  role: string;
  online?: boolean;
  user: { id: string; name: string; avatarColor?: string };
};

export default function MembersPage() {
  const router = useRouter();
  const { data } = useMe();
  const [members, setMembers] = useState<Member[]>([]);
  const [memberCount, setMemberCount] = useState(0);
  const [invite, setInvite] = useState<{ code: string | null; link: string | null; expiresAt: string | null } | null>(null);
  const [days, setDays] = useState(7);

  async function load() {
    const mem = await api<{ members: Member[]; memberCount: number }>("/api/family/members");
    setMembers(mem.members);
    setMemberCount(mem.memberCount);
    const inv = await api<{ code: string | null; link: string | null; expiresAt: string | null }>("/api/family/invite");
    setInvite(inv);
  }

  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, []);

  const canManage = data?.family?.role === "OWNER" || data?.family?.role === "ADMIN";

  async function startDm(userId: string) {
    const res = await api<{ conversation: { id: string } }>("/api/dm", {
      method: "POST",
      body: JSON.stringify({ userId }),
    });
    router.push(`/family/dm/${res.conversation.id}`);
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-3xl font-semibold">가족 구성원</h1>
        <p className="text-muted-foreground">현재 {memberCount}명이 함께합니다. 인원 제한은 없습니다.</p>
      </div>
      <Card>
        <h2 className="font-semibold">구성원 초대</h2>
        <p className="mt-2 text-sm text-muted-foreground">코드 또는 링크로 새 구성원을 추가하세요. 만료된 코드는 사용할 수 없습니다.</p>
        <div className="mt-3 font-mono text-lg">{invite?.code ?? "초대 코드 없음"}</div>
        <div className="mt-1 break-all text-xs text-muted-foreground">{invite?.link}</div>
        {invite?.expiresAt && (
          <div className="mt-1 text-xs text-muted-foreground">
            만료: {new Date(invite.expiresAt).toLocaleString("ko-KR")}
          </div>
        )}
        {canManage && (
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Input
              type="number"
              min={1}
              max={90}
              className="w-24"
              value={days}
              onChange={(e) => setDays(Number(e.target.value))}
            />
            <span className="text-xs text-muted-foreground">일 후 만료</span>
            <Button
              variant="outline"
              onClick={async () => {
                const next = await api<{ code: string; link: string; expiresAt: string }>(
                  "/api/family/invite",
                  { method: "POST", body: JSON.stringify({ expiresInDays: days }) },
                );
                setInvite(next);
                toast.success("새 초대 코드를 만들었습니다.");
              }}
            >
              초대 코드 만들기
            </Button>
          </div>
        )}
      </Card>
      <div className="grid gap-3">
        {members.map((m) => (
          <Card key={m.id} className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Avatar name={m.user.name} color={m.user.avatarColor} />
              <div>
                <div className="font-medium">
                  {m.user.name} {m.online ? "· 온라인" : ""}
                </div>
                <div className="text-xs text-muted-foreground">{m.role === "OWNER" || m.role === "ADMIN" ? `관리자 · ${m.role}` : m.role}</div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {m.user.id !== data?.user?.id && (
                <Button size="sm" onClick={() => void startDm(m.user.id)}>
                  1:1 채팅
                </Button>
              )}
              {canManage && m.role !== "OWNER" && m.user.id !== data?.user?.id && (
                <>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() =>
                      void api("/api/family/members", {
                        method: "PATCH",
                        body: JSON.stringify({ userId: m.user.id, role: m.role === "ADMIN" ? "MEMBER" : "ADMIN" }),
                      }).then(load)
                    }
                  >
                    {m.role === "ADMIN" ? "멤버로" : "관리자로"}
                  </Button>
                  <Button
                    size="sm"
                    variant="danger"
                    onClick={() => {
                      if (!window.confirm("이 구성원을 가족에서 제거할까요?")) return;
                      void api("/api/family/members", {
                        method: "PATCH",
                        body: JSON.stringify({ userId: m.user.id, remove: true }),
                      }).then(load);
                    }}
                  >
                    제거
                  </Button>
                </>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
