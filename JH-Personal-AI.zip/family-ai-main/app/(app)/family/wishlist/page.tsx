"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";

type Item = { id: string; name: string; description?: string | null; url?: string | null; priority: number; isPublic: boolean; user?: { name: string } };

export default function WishlistPage() {
  const [scope, setScope] = useState<"PERSONAL" | "FAMILY">("FAMILY");
  const [items, setItems] = useState<Item[]>([]);
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");

  async function load(next = scope) {
    const data = await api<{ items: Item[] }>(`/api/wishlist?scope=${next}`);
    setItems(data.items);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, [scope]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-semibold">위시리스트</h1>
        <div className="flex gap-2">
          <Button variant={scope === "FAMILY" ? "default" : "outline"} onClick={() => setScope("FAMILY")}>가족 공유</Button>
          <Button variant={scope === "PERSONAL" ? "default" : "outline"} onClick={() => setScope("PERSONAL")}>개인</Button>
        </div>
      </div>
      <form
        className="grid gap-2 md:grid-cols-[1fr_1fr_auto]"
        onSubmit={async (e) => {
          e.preventDefault();
          await api("/api/wishlist", { method: "POST", body: JSON.stringify({ name, url, scope, isPublic: scope === "FAMILY" }) });
          setName("");
          setUrl("");
          await load();
        }}
      >
        <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="원하는 것" required />
        <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://" />
        <Button type="submit">추가</Button>
      </form>
      {items.map((item) => (
        <Card key={item.id} className="flex items-center justify-between">
          <div>
            <div className="font-medium">{item.name}</div>
            <div className="text-xs text-muted-foreground">
              우선순위 {item.priority} · {item.user?.name} {item.isPublic ? "· 공개" : "· 비공개"}
            </div>
            {item.url && (
              <a className="text-sm underline" href={item.url} target="_blank" rel="noreferrer">
                링크
              </a>
            )}
          </div>
          <Button size="sm" variant="ghost" onClick={async () => { await api("/api/wishlist", { method: "DELETE", body: JSON.stringify({ id: item.id }) }); await load(); }}>
            삭제
          </Button>
        </Card>
      ))}
    </div>
  );
}
