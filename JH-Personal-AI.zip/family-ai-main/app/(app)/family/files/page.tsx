"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";
import { formatDate } from "@/lib/utils";

type FileRow = {
  id: string;
  originalName: string;
  size: number;
  createdAt: string;
  uploader?: { name: string };
};

export default function FamilyFilesPage() {
  const [files, setFiles] = useState<FileRow[]>([]);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);

  async function load(query = q) {
    const data = await api<{ files: FileRow[] }>(`/api/files/family?q=${encodeURIComponent(query)}`);
    setFiles(data.files);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, []);

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">가족 파일 보관함</h1>
      <div className="flex flex-wrap gap-2">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="파일 검색" onKeyDown={(e) => e.key === "Enter" && void load()} />
        <Button variant="outline" onClick={() => void load()}>검색</Button>
        <label className="inline-flex h-10 cursor-pointer items-center rounded-xl bg-primary px-4 text-sm text-primary-foreground">
          {busy ? "올리는 중…" : "업로드"}
          <input
            type="file"
            className="hidden"
            onChange={async (e) => {
              const file = e.target.files?.[0];
              if (!file) return;
              setBusy(true);
              try {
                const form = new FormData();
                form.append("file", file);
                const res = await fetch("/api/files/family", { method: "POST", body: form });
                const json = await res.json();
                if (!json.success) throw new Error(json.error.message);
                await load();
              } catch (error) {
                toast.error(error instanceof Error ? error.message : "업로드 실패");
              } finally {
                setBusy(false);
              }
            }}
          />
        </label>
      </div>
      {files.length === 0 && <p className="text-sm text-muted-foreground">공유된 파일이 없습니다.</p>}
      {files.map((f) => (
        <Card key={f.id} className="flex items-center justify-between gap-3">
          <div>
            <div className="font-medium">{f.originalName}</div>
            <div className="text-xs text-muted-foreground">
              {f.uploader?.name} · {formatDate(f.createdAt)} · {Math.round(f.size / 1024)}KB
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" asChild>
              <a href={`/api/files/${f.id}`}>다운로드</a>
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={async () => {
                if (!window.confirm("이 가족 파일을 삭제할까요?")) return;
                await fetch(`/api/files/${f.id}`, { method: "DELETE" });
                await load();
              }}
            >
              삭제
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
