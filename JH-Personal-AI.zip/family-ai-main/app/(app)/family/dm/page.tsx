import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { FamilyMessenger } from "@/components/direct-chat";

export default async function DmInboxPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.memberships[0]) redirect("/onboarding");
  return <FamilyMessenger userId={user.id} />;
}
