import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth/session";
import { requireDmAccess } from "@/lib/dm/access";
import { FamilyMessenger } from "@/components/direct-chat";

export default async function DmThreadPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.memberships[0]) redirect("/onboarding");
  const { id } = await params;
  try {
    await requireDmAccess(user.id, id);
  } catch {
    redirect("/family/dm");
  }
  return <FamilyMessenger userId={user.id} conversationId={id} />;
}
