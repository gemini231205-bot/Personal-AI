"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/client";

type Memory = { id: string; title: string; content: string };

export default function FamilyMemoryPage() {
  const [memories, setMemories] = useState<Memory[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");

  async function load() {
    const data = await api<{ memories: Memory[] }>("/api/memories/family");
    setMemories(data.memories);
  }
  useEffect(() => {
    void load().catch((e) => toast.error(e.message));
  }, []);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-3xl font-semibold">가족 메모리</h1>
        <p className="text-muted-foreground">여기에 적은 내용만 Family AI가 볼 수 있습니다. 개인 메모리는 자동으로 오지 않습니다.</p>
      </div>
      <Card>
        <form
          className="space-y-3"
          onSubmit={async (e) => {
            e.preventDefault();
            await api("/api/memories/family", { method: "POST", body: JSON.stringify({ title, content }) });
            setTitle("");
            setContent("");
            await load();
          }}
        >
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="제목 · 예: 일요일 저녁 식사" required />
          <Textarea value={content} onChange={(e) => setContent(e.target.value)} placeholder="가족이 함께 기억할 내용" required />
          <Button type="submit">가족에게 공유</Button>
        </form>
      </Card>
      {memories.length === 0 && <p className="text-sm text-muted-foreground">아직 공유된 가족 기억이 없습니다.</p>}
      {memories.map((m) => (
        <Card key={m.id}>
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-semibold">{m.title}</h2>
              <p className="mt-2 text-sm">{m.content}</p>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={async () => {
                if (!window.confirm("이 가족 메모리를 삭제할까요?")) return;
                await api("/api/memories/family", { method: "DELETE", body: JSON.stringify({ id: m.id }) });
                await load();
              }}
            >
              삭제
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
}
