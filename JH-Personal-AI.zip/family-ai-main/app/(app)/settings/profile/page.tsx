"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { api } from "@/lib/client";

export default function ProfilePage() {
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [avatarColor, setAvatarColor] = useState("amber");

  useEffect(() => {
    void api<{ user: { name: string; bio?: string | null; avatarColor: string } }>("/api/settings").then((d) => {
      setName(d.user.name);
      setBio(d.user.bio ?? "");
      setAvatarColor(d.user.avatarColor);
    });
  }, []);

  return (
    <form
      className="max-w-lg space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        await api("/api/settings", { method: "PATCH", body: JSON.stringify({ profile: { name, bio, avatarColor } }) });
        toast.success("프로필을 저장했습니다.");
      }}
    >
      <h1 className="text-3xl font-semibold">프로필</h1>
      <Input value={name} onChange={(e) => setName(e.target.value)} />
      <Textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="소개" />
      <Input value={avatarColor} onChange={(e) => setAvatarColor(e.target.value)} />
      <Button type="submit">저장</Button>
    </form>
  );
}
