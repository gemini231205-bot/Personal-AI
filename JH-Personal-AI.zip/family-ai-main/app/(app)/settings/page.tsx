import Link from "next/link";
import { Card } from "@/components/ui/card";

const LINKS = [
  { href: "/settings/profile", title: "프로필", body: "이름, 소개, 색상" },
  { href: "/settings/privacy", title: "개인정보", body: "개인 파일 분석 설정" },
  { href: "/settings/security", title: "보안", body: "비밀번호 변경, 계정 삭제" },
  { href: "/settings/ai", title: "AI 설정", body: "현재 provider와 사용량" },
  { href: "/memory", title: "개인 메모리", body: "JH AI가 기억하는 내용" },
  { href: "/files", title: "개인 파일", body: "JH AI가 분석할 수 있는 파일" },
];

export default function SettingsPage() {
  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">설정</h1>
      <div className="grid gap-3 md:grid-cols-2">
        {LINKS.map((l) => (
          <Link key={l.href} href={l.href}>
            <Card>
              <h2 className="font-semibold">{l.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{l.body}</p>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
