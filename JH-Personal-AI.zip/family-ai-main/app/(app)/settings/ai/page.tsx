"use client";

import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { api } from "@/lib/client";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";

export default function AiSettingsPage() {
  const { theme, setTheme } = useTheme();
  const [info, setInfo] = useState<{
    ai: { configured: string; active: string | null; model: string; warning?: string | null };
    usage: { _count: number; _sum: { estimatedCost: number | null; inputTokens: number | null; outputTokens: number | null } };
  } | null>(null);

  useEffect(() => {
    void api<NonNullable<typeof info>>("/api/settings").then(setInfo);
  }, []);

  return (
    <div className="space-y-5">
      <h1 className="text-3xl font-semibold">AI · 화면</h1>
      <Card>
        <h2 className="font-semibold">현재 AI provider</h2>
        <p className="mt-2 text-sm">설정: {info?.ai.configured} · 실제: {info?.ai.active} · 모델: {info?.ai.model}</p>
        {info?.ai.warning && <p className="mt-2 text-sm text-[var(--danger)]">{info.ai.warning}</p>}
        <p className="mt-3 text-sm text-muted-foreground">
          provider는 서버 환경 변수 `AI_PROVIDER`로만 바꿉니다. 키는 브라우저에 내려가지 않습니다.
        </p>
      </Card>
      <Card>
        <h2 className="font-semibold">사용량</h2>
        <p className="mt-2 text-sm">
          호출 {info?.usage._count ?? 0}회 · 입력 토큰 {info?.usage._sum.inputTokens ?? 0} · 출력 {info?.usage._sum.outputTokens ?? 0} ·
          추정 비용 ${((info?.usage._sum.estimatedCost ?? 0) as number).toFixed(4)}
        </p>
      </Card>
      <Card>
        <h2 className="font-semibold">다크 모드</h2>
        <div className="mt-3 flex gap-2">
          <Button variant={theme === "light" ? "default" : "outline"} onClick={() => setTheme("light")}>라이트</Button>
          <Button variant={theme === "dark" ? "default" : "outline"} onClick={() => setTheme("dark")}>다크</Button>
          <Button variant={theme === "system" ? "default" : "outline"} onClick={() => setTheme("system")}>시스템</Button>
        </div>
      </Card>
    </div>
  );
}
