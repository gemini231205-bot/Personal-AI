"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";
import { useMe } from "@/hooks/use-me";

export default function FamilySettingsPage() {
  const { data } = useMe();
  const [name, setName] = useState("");

  useEffect(() => {
    if (data?.family?.name) setName(data.family.name);
  }, [data]);

  return (
    <div className="max-w-lg space-y-4">
      <h1 className="text-3xl font-semibold">가족 설정</h1>
      <form
        className="space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            await api("/api/family", { method: "PATCH", body: JSON.stringify({ name }) });
            toast.success("가족 이름을 바꿨습니다.");
          } catch (error) {
            toast.error(error instanceof Error ? error.message : "권한이 없습니다.");
          }
        }}
      >
        <Input value={name} onChange={(e) => setName(e.target.value)} />
        <Button type="submit">저장</Button>
      </form>
      <p className="text-sm text-muted-foreground">초대, 역할, 제거, 1:1 채팅은 구성원 수 제한 없이 구성원 페이지에서 관리합니다.</p>
      <div className="flex gap-2">
        <Button variant="outline" asChild>
          <Link href="/family/members">구성원 관리</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link href="/family/dm">1:1 채팅</Link>
        </Button>
      </div>
    </div>
  );
}
