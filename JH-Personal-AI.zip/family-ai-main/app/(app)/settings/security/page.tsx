"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";

export default function SecurityPage() {
  const router = useRouter();
  const [currentPassword, setCurrent] = useState("");
  const [nextPassword, setNext] = useState("");

  return (
    <div className="max-w-lg space-y-8">
      <form
        className="space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          try {
            await api("/api/auth/password", { method: "POST", body: JSON.stringify({ currentPassword, nextPassword }) });
            toast.success("비밀번호를 바꿨습니다. 다시 로그인해 주세요.");
            router.replace("/login");
          } catch (error) {
            toast.error(error instanceof Error ? error.message : "변경 실패");
          }
        }}
      >
        <h1 className="text-3xl font-semibold">보안</h1>
        <Input type="password" value={currentPassword} onChange={(e) => setCurrent(e.target.value)} placeholder="현재 비밀번호" required />
        <Input type="password" value={nextPassword} onChange={(e) => setNext(e.target.value)} placeholder="새 비밀번호" required />
        <Button type="submit">비밀번호 변경</Button>
      </form>
      <Button
        variant="outline"
        onClick={async () => {
          await api("/api/auth/logout", { method: "POST" });
          router.replace("/login");
        }}
      >
        로그아웃
      </Button>
      <Button
        variant="danger"
        onClick={async () => {
          if (!window.confirm("계정을 삭제하면 개인 데이터가 모두 지워집니다. 계속할까요?")) return;
          await api("/api/auth/account", { method: "DELETE" });
          router.replace("/");
        }}
      >
        계정 삭제
      </Button>
    </div>
  );
}
