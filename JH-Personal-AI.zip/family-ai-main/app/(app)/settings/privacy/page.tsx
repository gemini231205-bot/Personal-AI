"use client";

import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/client";

export default function PrivacyPage() {
  const [allowPersonalFileAnalysis, setFiles] = useState(true);

  useEffect(() => {
    void api<{ user: { allowPersonalFileAnalysis: boolean } }>("/api/settings").then((d) => {
      setFiles(d.user.allowPersonalFileAnalysis);
    });
  }, []);

  return (
    <form
      className="max-w-lg space-y-4"
      onSubmit={async (e) => {
        e.preventDefault();
        await api("/api/settings", {
          method: "PATCH",
          body: JSON.stringify({ privacy: { allowPersonalFileAnalysis } }),
        });
        toast.success("개인정보 설정을 저장했습니다.");
      }}
    >
      <h1 className="text-3xl font-semibold">개인정보</h1>
      <label className="flex items-start gap-3 text-sm">
        <input type="checkbox" checked={allowPersonalFileAnalysis} onChange={(e) => setFiles(e.target.checked)} />
        <span>개인 파일을 JH AI가 분석(RAG)하도록 허용합니다.</span>
      </label>
      <Button type="submit">저장</Button>
    </form>
  );
}
