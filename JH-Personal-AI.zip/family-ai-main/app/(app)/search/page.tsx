"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";

export default function SearchPage() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<Record<string, unknown[]> | null>(null);

  async function run() {
    if (!q.trim()) return;
    try {
      const data = await api<{ results: Record<string, unknown[]> }>(
        `/api/search?scope=personal&q=${encodeURIComponent(q)}`,
      );
      setResults(data.results);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "검색 실패");
    }
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-3xl font-semibold">개인 검색</h1>
        <p className="text-sm text-muted-foreground">내 대화, 기억, 파일 등 개인 범위만 검색합니다.</p>
      </div>
      <div className="flex gap-2">
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="대화, 메모리, 파일 검색…"
          onKeyDown={(e) => e.key === "Enter" && void run()}
        />
        <Button onClick={() => void run()}>검색</Button>
      </div>
      {results &&
        Object.entries(results).map(([key, rows]) => (
          <Card key={key}>
            <h2 className="font-semibold">{key}</h2>
            <ul className="mt-2 space-y-1 text-sm">
              {(rows as { id?: string; title?: string; name?: string; content?: string; question?: string; originalName?: string }[]).map((row, i) => (
                <li key={row.id ?? i}>
                  {row.title || row.name || row.question || row.originalName || row.content?.slice(0, 80)}
                </li>
              ))}
              {rows.length === 0 && <li className="text-muted-foreground">결과 없음</li>}
            </ul>
          </Card>
        ))}
    </div>
  );
}
