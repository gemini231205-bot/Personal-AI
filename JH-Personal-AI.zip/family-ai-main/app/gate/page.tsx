"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { api } from "@/lib/client";

export default function SiteGatePage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">
      <h1 className="text-3xl font-semibold">Family AI</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        사이트 접근용 공통 비밀번호입니다. 개인 계정 로그인과는 별도입니다.
      </p>
      <form
        className="mt-8 space-y-3"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          try {
            await api("/api/site/unlock", { method: "POST", body: JSON.stringify({ password }) });
            router.replace("/");
            router.refresh();
          } catch (error) {
            toast.error(error instanceof Error ? error.message : "입장에 실패했습니다.");
          } finally {
            setBusy(false);
          }
        }}
      >
        <Input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="사이트 비밀번호"
          required
        />
        <Button className="w-full" disabled={busy}>
          {busy ? "확인 중…" : "입장"}
        </Button>
      </form>
    </main>
  );
}
