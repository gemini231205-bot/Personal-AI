import { NextRequest } from "next/server";
import { handleError, ok, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf, requireMembership } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { shoppingItemSchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";
import { notifyFamily } from "@/lib/notifications";
import { z } from "zod";

async function listOf(familyId: string) {
  return (
    (await prisma.shoppingList.findFirst({
      where: { familyId },
      include: { items: { include: { assignee: true }, orderBy: { createdAt: "asc" } } },
    })) ??
    (await prisma.shoppingList.create({
      data: { familyId, name: "장보기" },
      include: { items: { include: { assignee: true } } },
    }))
  );
}

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const list = await listOf(membership.familyId);
    return ok({ list });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const body = shoppingItemSchema.parse(await request.json());
    const list = await listOf(membership.familyId);
    const item = await prisma.shoppingItem.create({
      data: {
        listId: list.id,
        name: body.name,
        quantity: body.quantity ?? 1,
        category: body.category,
        notes: body.notes,
        assigneeId: body.assigneeId,
      },
      include: { assignee: true },
    });
    await notifyFamily({
      familyId: membership.familyId,
      type: "shopping.add",
      title: "장보기 목록이 바뀌었습니다",
      body: `${item.name} × ${item.quantity}`,
      href: "/family/shopping",
      exceptUserId: user.id,
    });
    return ok({ item }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = shoppingItemSchema.partial().extend({
      id: z.string(),
      completed: z.boolean().optional(),
      quantity: z.number().int().min(1).max(99).optional(),
    }).parse(await request.json());
    const existing = await prisma.shoppingItem.findUnique({
      where: { id: body.id },
      include: { list: true },
    });
    if (!existing) throw notFound();
    await requireMembership(user.id, existing.list.familyId);
    const item = await prisma.shoppingItem.update({
      where: { id: body.id },
      data: {
        name: body.name,
        quantity: body.quantity,
        category: body.category,
        notes: body.notes,
        assigneeId: body.assigneeId,
        completed: body.completed,
      },
      include: { assignee: true },
    });
    return ok({ item });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = z.object({ id: z.string() }).parse(await request.json());
    const existing = await prisma.shoppingItem.findUnique({
      where: { id },
      include: { list: true },
    });
    if (!existing) throw notFound();
    await requireMembership(user.id, existing.list.familyId);
    await prisma.shoppingItem.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (error) {
    return handleError(error);
  }
}
