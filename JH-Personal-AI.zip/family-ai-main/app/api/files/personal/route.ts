import { NextRequest } from "next/server";
import { handleError, ok, ApiError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { loadEnv } from "@/lib/env";
import { assertSafeUpload } from "@/lib/security/sanitize";
import { saveUpload } from "@/lib/storage";
import { extractText, indexPersonalFile } from "@/lib/rag";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { uid } from "@/lib/utils";

export async function GET(request: NextRequest) {
  try {
    const user = await requireUser();
    const q = request.nextUrl.searchParams.get("q") ?? "";
    const files = await prisma.personalFile.findMany({
      where: {
        userId: user.id,
        originalName: q ? { contains: q, mode: "insensitive" } : undefined,
      },
      orderBy: { createdAt: "desc" },
    });
    return ok({ files });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) throw new ApiError("FILE_INVALID", "파일이 필요합니다.", 400);
    const ext = assertSafeUpload(file, loadEnv().MAX_UPLOAD_BYTES);
    const storedName = `${uid("file")}.${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await saveUpload(`personal_${user.id}`, storedName, buffer);
    let text = "";
    try {
      text = await extractText(buffer, file.type, file.name);
    } catch {
      text = "";
    }
    const row = await prisma.personalFile.create({
      data: {
        userId: user.id,
        originalName: file.name,
        storedName,
        mimeType: file.type || "application/octet-stream",
        size: file.size,
        textExtracted: text.slice(0, 20000) || null,
      },
    });
    if (text && user.allowPersonalFileAnalysis) {
      await indexPersonalFile(row.id, user.id, text, file.name);
    }
    await writeAudit({
      action: "file.personal_upload",
      userId: user.id,
      metadata: { fileId: row.id },
      ip: clientIp(request),
    });
    return ok({ file: row }, 201);
  } catch (error) {
    return handleError(error);
  }
}
