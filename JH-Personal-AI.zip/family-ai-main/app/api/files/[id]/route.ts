import { NextRequest } from "next/server";
import { handleError, ok, forbidden, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireMembership } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { readUpload, removeUpload } from "@/lib/storage";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { z } from "zod";

export async function GET(_request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const personal = await prisma.personalFile.findUnique({ where: { id } });
    if (personal) {
      if (personal.userId !== user.id) throw forbidden("이 파일에 접근할 수 없습니다.");
      const buf = await readUpload(`personal_${user.id}`, personal.storedName);
      return new Response(buf, {
        headers: {
          "Content-Type": personal.mimeType,
          "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(personal.originalName)}`,
        },
      });
    }
    const family = await prisma.familyFile.findUnique({ where: { id } });
    if (!family) throw notFound("파일을 찾을 수 없습니다.");
    await requireMembership(user.id, family.familyId);
    const buf = await readUpload(`family_${family.familyId}`, family.storedName);
    return new Response(buf, {
      headers: {
        "Content-Type": family.mimeType,
        "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(family.originalName)}`,
      },
    });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    const body = z.object({ originalName: z.string().min(1).max(180) }).parse(await request.json());
    const personal = await prisma.personalFile.findUnique({ where: { id } });
    if (personal) {
      if (personal.userId !== user.id) throw forbidden();
      const file = await prisma.personalFile.update({
        where: { id },
        data: { originalName: body.originalName },
      });
      return ok({ file });
    }
    const family = await prisma.familyFile.findUnique({ where: { id } });
    if (!family) throw notFound();
    await requireMembership(user.id, family.familyId);
    const file = await prisma.familyFile.update({
      where: { id },
      data: { originalName: body.originalName },
    });
    return ok({ file });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    const personal = await prisma.personalFile.findUnique({ where: { id } });
    if (personal) {
      if (personal.userId !== user.id) throw forbidden();
      await removeUpload(`personal_${user.id}`, personal.storedName);
      await prisma.personalFile.delete({ where: { id } });
      await writeAudit({
        action: "file.personal_delete",
        userId: user.id,
        metadata: { fileId: id },
        ip: clientIp(request),
      });
      return ok({ deleted: true });
    }
    const family = await prisma.familyFile.findUnique({ where: { id } });
    if (!family) throw notFound();
    await requireMembership(user.id, family.familyId);
    await removeUpload(`family_${family.familyId}`, family.storedName);
    await prisma.familyFile.delete({ where: { id } });
    await writeAudit({
      action: "file.family_delete",
      userId: user.id,
      familyId: family.familyId,
      metadata: { fileId: id },
      ip: clientIp(request),
    });
    return ok({ deleted: true });
  } catch (error) {
    return handleError(error);
  }
}
