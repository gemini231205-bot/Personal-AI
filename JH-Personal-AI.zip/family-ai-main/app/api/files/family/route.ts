import { NextRequest } from "next/server";
import { handleError, ok, ApiError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { loadEnv } from "@/lib/env";
import { assertSafeUpload } from "@/lib/security/sanitize";
import { saveUpload } from "@/lib/storage";
import { extractText, indexFamilyFile } from "@/lib/rag";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { notifyFamily } from "@/lib/notifications";
import { uid } from "@/lib/utils";

export async function GET(request: NextRequest) {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const q = request.nextUrl.searchParams.get("q") ?? "";
    const files = await prisma.familyFile.findMany({
      where: {
        familyId: membership.familyId,
        originalName: q ? { contains: q, mode: "insensitive" } : undefined,
      },
      include: { uploader: true },
      orderBy: { createdAt: "desc" },
    });
    return ok({ files });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) throw new ApiError("FILE_INVALID", "파일이 필요합니다.", 400);
    const ext = assertSafeUpload(file, loadEnv().MAX_UPLOAD_BYTES);
    const storedName = `${uid("file")}.${ext}`;
    const buffer = Buffer.from(await file.arrayBuffer());
    await saveUpload(`family_${membership.familyId}`, storedName, buffer);
    let text = "";
    try {
      text = await extractText(buffer, file.type, file.name);
    } catch {
      text = "";
    }
    const row = await prisma.familyFile.create({
      data: {
        familyId: membership.familyId,
        uploaderId: user.id,
        originalName: file.name,
        storedName,
        mimeType: file.type || "application/octet-stream",
        size: file.size,
        textExtracted: text.slice(0, 20000) || null,
      },
      include: { uploader: true },
    });
    if (text) await indexFamilyFile(row.id, membership.familyId, text, file.name);
    await writeAudit({
      action: "file.family_upload",
      userId: user.id,
      familyId: membership.familyId,
      metadata: { fileId: row.id },
      ip: clientIp(request),
    });
    await notifyFamily({
      familyId: membership.familyId,
      type: "file.upload",
      title: "가족 파일이 올라왔습니다",
      body: `${user.name}님이 ${file.name} 을 공유했습니다.`,
      href: "/family/files",
      exceptUserId: user.id,
    });
    return ok({ file: row }, 201);
  } catch (error) {
    return handleError(error);
  }
}
