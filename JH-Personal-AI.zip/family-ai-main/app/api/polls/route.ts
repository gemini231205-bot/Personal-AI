import { NextRequest } from "next/server";
import { handleError, ok, notFound, ApiError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf, requireMembership } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { pollSchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";
import { notifyFamily } from "@/lib/notifications";
import { z } from "zod";

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const polls = await prisma.poll.findMany({
      where: { familyId: membership.familyId },
      include: {
        options: { include: { votes: true } },
        votes: true,
        createdBy: true,
      },
      orderBy: { createdAt: "desc" },
    });
    return ok({ polls, userId: user.id });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const body = pollSchema.parse(await request.json());
    const poll = await prisma.poll.create({
      data: {
        familyId: membership.familyId,
        question: body.question,
        createdById: user.id,
        allowMultiple: body.allowMultiple ?? false,
        endsAt: body.endsAt ? new Date(body.endsAt) : undefined,
        options: { create: body.options.map((label) => ({ label })) },
      },
      include: { options: { include: { votes: true } }, votes: true, createdBy: true },
    });
    await notifyFamily({
      familyId: membership.familyId,
      type: "poll.create",
      title: "새 가족 투표",
      body: poll.question,
      href: "/family/polls",
      exceptUserId: user.id,
    });
    return ok({ poll }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = z
      .object({
        id: z.string(),
        optionId: z.string().optional(),
        closed: z.boolean().optional(),
      })
      .parse(await request.json());
    const poll = await prisma.poll.findUnique({
      where: { id: body.id },
      include: { options: true, votes: true },
    });
    if (!poll) throw notFound();
    await requireMembership(user.id, poll.familyId);
    if (body.closed !== undefined) {
      const updated = await prisma.poll.update({
        where: { id: poll.id },
        data: { closed: body.closed },
        include: { options: { include: { votes: true } }, votes: true, createdBy: true },
      });
      return ok({ poll: updated });
    }
    if (poll.closed || (poll.endsAt && poll.endsAt < new Date())) {
      throw new ApiError("CONFLICT", "종료된 투표입니다.", 409);
    }
    if (!body.optionId) throw new ApiError("VALIDATION", "선택지를 고르세요.", 422);
    if (!poll.options.some((o) => o.id === body.optionId)) throw notFound();
    const existing = await prisma.pollVote.findMany({
      where: { pollId: poll.id, userId: user.id },
    });
    if (!poll.allowMultiple && existing.length) {
      throw new ApiError("CONFLICT", "이미 투표했습니다.", 409);
    }
    if (existing.some((v) => v.optionId === body.optionId)) {
      throw new ApiError("CONFLICT", "이미 이 항목에 투표했습니다.", 409);
    }
    await prisma.pollVote.create({
      data: { pollId: poll.id, optionId: body.optionId, userId: user.id },
    });
    const updated = await prisma.poll.findUnique({
      where: { id: poll.id },
      include: { options: { include: { votes: true } }, votes: true, createdBy: true },
    });
    return ok({ poll: updated });
  } catch (error) {
    return handleError(error);
  }
}
