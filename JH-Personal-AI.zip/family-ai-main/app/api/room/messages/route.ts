import { NextRequest } from "next/server";
import { handleError, ok, forbidden, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf, touchPresence } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { roomMessageSchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";
import { notifyFamily, notifyUser } from "@/lib/notifications";
import { z } from "zod";

export async function GET(request: NextRequest) {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    await touchPresence(user.id, membership.familyId);
    const cursor = request.nextUrl.searchParams.get("cursor");
    const q = request.nextUrl.searchParams.get("q") ?? "";
    const take = 40;
    const messages = await prisma.familyMessage.findMany({
      where: {
        familyId: membership.familyId,
        content: q ? { contains: q, mode: "insensitive" } : undefined,
        createdAt: cursor ? { lt: new Date(cursor) } : undefined,
      },
      include: { author: true, replyTo: { include: { author: true } }, reads: true },
      orderBy: { createdAt: "desc" },
      take,
    });
    return ok({ messages: messages.reverse(), nextCursor: messages[0]?.createdAt ?? null });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const body = roomMessageSchema.parse(await request.json());
    const message = await prisma.familyMessage.create({
      data: {
        familyId: membership.familyId,
        authorId: user.id,
        content: body.content,
        replyToId: body.replyToId,
      },
      include: { author: true, replyTo: { include: { author: true } }, reads: true },
    });
    await notifyFamily({
      familyId: membership.familyId,
      type: "room.message",
      title: `${user.name}님의 메시지`,
      body: body.content.slice(0, 80),
      href: "/family/chat",
      exceptUserId: user.id,
    });
    if (body.replyToId) {
      const parent = await prisma.familyMessage.findUnique({ where: { id: body.replyToId } });
      if (parent?.authorId && parent.authorId !== user.id) {
        await notifyUser({
          userId: parent.authorId,
          familyId: membership.familyId,
          type: "room.reply",
          title: `${user.name}님이 답장했습니다`,
          body: body.content.slice(0, 80),
          href: "/family/chat",
        });
      }
    }
    return ok({ message }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = z.object({ id: z.string(), content: z.string().trim().min(1).max(4000) }).parse(await request.json());
    const existing = await prisma.familyMessage.findUnique({ where: { id: body.id } });
    if (!existing || existing.deletedAt) throw notFound();
    if (existing.authorId !== user.id) throw forbidden("본인 메시지만 수정할 수 있습니다.");
    const message = await prisma.familyMessage.update({
      where: { id: body.id },
      data: { content: body.content, editedAt: new Date() },
      include: { author: true, replyTo: true, reads: true },
    });
    return ok({ message });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = z.object({ id: z.string() }).parse(await request.json());
    const existing = await prisma.familyMessage.findUnique({ where: { id } });
    if (!existing) throw notFound();
    if (existing.authorId !== user.id) throw forbidden("본인 메시지만 삭제할 수 있습니다.");
    const message = await prisma.familyMessage.update({
      where: { id },
      data: { deletedAt: new Date(), content: "삭제된 메시지입니다." },
    });
    return ok({ message });
  } catch (error) {
    return handleError(error);
  }
}
