import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { assertCsrf } from "@/lib/security/csrf";
import { assertAiBudget, rateLimit } from "@/lib/auth/rate-limit";
import { runAndLog } from "@/lib/ai/orchestrate";
import { notifyFamily } from "@/lib/notifications";
import { z } from "zod";

export const maxDuration = 60;

const schema = z.object({
  kind: z
    .enum(["question", "summarize", "calendar", "search", "idea", "draft", "files", "free", "ask_message"])
    .default("free"),
  prompt: z.string().trim().min(1).max(4000),
  messageId: z.string().optional(),
});

const KIND_PREFIX: Record<string, string> = {
  question: "가족에게 도움이 되도록 질문에 답하세요.",
  summarize: "최근 가족 대화를 회의록처럼 정리하세요. 결정사항/할 일/담당자/기한/미해결.",
  calendar: "가족 일정을 분석하고 겹치는 시간, 가능한 날을 찾으세요.",
  search: "가족 메모리와 파일에서 정보를 찾으세요.",
  idea: "가족이 함께할 아이디어를 구체적으로 제안하세요.",
  draft: "가족이 보내기 좋은 메시지 초안을 작성하세요.",
  files: "공유 파일을 근거로 분석하세요. 출처를 밝히세요.",
  free: "가족 공유 데이터만 사용해 답하세요.",
  ask_message: "아래 메시지를 맥락으로 답하세요.",
};

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    rateLimit(`family-ai:${user.id}`, 20, 60_000);
    await assertAiBudget(user.id);
    const body = schema.parse(await request.json());

    let extra = "";
    if (body.messageId) {
      const msg = await prisma.familyMessage.findFirst({
        where: { id: body.messageId, familyId: membership.familyId },
        include: { author: true },
      });
      if (msg) extra = `\n대상 메시지 (${msg.author?.name ?? "구성원"}): ${msg.content}`;
    }

    const result = await runAndLog({
      userId: user.id,
      familyId: membership.familyId,
      question: `${KIND_PREFIX[body.kind]}\n\n${body.prompt}${extra}`,
      history: [],
      ctx: {
        userId: user.id,
        familyId: membership.familyId,
        scope: "family",
        allowSharedPersonal: user.shareFamilyContext,
      },
    });

    const message = await prisma.familyMessage.create({
      data: {
        familyId: membership.familyId,
        authorId: null,
        content: result.content,
        isAi: true,
        aiKind: body.kind,
        replyToId: body.messageId,
      },
      include: { author: true, replyTo: { include: { author: true } }, reads: true },
    });

    await notifyFamily({
      familyId: membership.familyId,
      type: "ai.reply",
      title: "✨ Family AI가 답했습니다",
      body: result.content.slice(0, 80),
      href: "/family/chat",
      exceptUserId: user.id,
    });

    return ok({ message, citations: result.citations });
  } catch (error) {
    return handleError(error);
  }
}
