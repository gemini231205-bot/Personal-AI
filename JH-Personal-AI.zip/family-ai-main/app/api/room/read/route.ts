import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf, touchPresence } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { assertCsrf } from "@/lib/security/csrf";
import { z } from "zod";

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    await touchPresence(user.id, membership.familyId);
    const body = z.object({ messageIds: z.array(z.string()).max(50) }).parse(await request.json());
    const owned = await prisma.familyMessage.findMany({
      where: { id: { in: body.messageIds }, familyId: membership.familyId },
      select: { id: true },
    });
    await prisma.messageRead.createMany({
      data: owned.map((m) => ({ messageId: m.id, userId: user.id })),
      skipDuplicates: true,
    });
    return ok({ read: owned.length });
  } catch (error) {
    return handleError(error);
  }
}
