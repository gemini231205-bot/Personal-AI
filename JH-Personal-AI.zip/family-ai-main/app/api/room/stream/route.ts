import { handleError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf, touchPresence } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";

export const maxDuration = 60;

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const encoder = new TextEncoder();
    let last = new Date();
    const stream = new ReadableStream({
      start(controller) {
        const tick = async () => {
          try {
            await touchPresence(user.id, membership.familyId);
            const messages = await prisma.familyMessage.findMany({
              where: { familyId: membership.familyId, createdAt: { gt: last } },
              include: { author: true, replyTo: { include: { author: true } }, reads: true },
              orderBy: { createdAt: "asc" },
            });
            if (messages.length) {
              last = messages[messages.length - 1].createdAt;
              controller.enqueue(
                encoder.encode(`event: messages\ndata: ${JSON.stringify({ messages })}\n\n`),
              );
            }
            const members = await prisma.familyMember.findMany({
              where: { familyId: membership.familyId },
              include: { user: true },
            });
            controller.enqueue(
              encoder.encode(`event: presence\ndata: ${JSON.stringify({ members })}\n\n`),
            );
          } catch {
            controller.enqueue(encoder.encode(`event: ping\ndata: {}\n\n`));
          }
        };
        const interval = setInterval(() => {
          void tick();
        }, 2000);
        void tick();
        const keepalive = setInterval(() => {
          controller.enqueue(encoder.encode(`event: ping\ndata: {}\n\n`));
        }, 15000);
        const close = () => {
          clearInterval(interval);
          clearInterval(keepalive);
        };
        controller.enqueue(encoder.encode(`event: ready\ndata: {}\n\n`));
        (controller as unknown as { close: () => void }).close = () => {
          close();
        };
      },
      cancel() {
        // intervals cleaned when process GC; Next.js aborts the request
      },
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
      },
    });
  } catch (error) {
    return handleError(error);
  }
}
