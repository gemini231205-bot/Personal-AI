import { handleError, ok } from "@/lib/api";
import { getCurrentUser } from "@/lib/auth/session";
import { publicUser } from "@/lib/serializers";
import { providerStatus } from "@/lib/ai/provider";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return ok({ user: null, family: null });
    const membership = user.memberships[0];
    return ok({
      user: publicUser(user),
      family: membership
        ? {
            id: membership.family.id,
            name: membership.family.name,
            inviteCode: membership.family.inviteCode,
            role: membership.role,
          }
        : null,
      members: user.memberships.map((m) => ({
        id: m.id,
        role: m.role,
        family: { id: m.family.id, name: m.family.name, inviteCode: m.family.inviteCode },
      })),
      ai: providerStatus(),
    });
  } catch (error) {
    return handleError(error);
  }
}
