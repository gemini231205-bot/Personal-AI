import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser, SESSION_COOKIE } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";

export async function DELETE(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    await writeAudit({ action: "auth.account_delete", userId: user.id, ip: clientIp(request) });
    await prisma.user.delete({ where: { id: user.id } });
    const res = ok({ deleted: true });
    res.cookies.set(SESSION_COOKIE, "", { path: "/", expires: new Date(0) });
    return res;
  } catch (error) {
    return handleError(error);
  }
}
