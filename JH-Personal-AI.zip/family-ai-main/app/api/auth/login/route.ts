import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, handleError, ApiError } from "@/lib/api";
import { loginSchema } from "@/lib/validation";
import { verifyPassword } from "@/lib/auth/password";
import { createSession, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth/session";
import { assertLoginAllowed, recordLoginAttempt } from "@/lib/auth/rate-limit";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { publicUser } from "@/lib/serializers";

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const ip = clientIp(request);
    const body = loginSchema.parse(await request.json());
    await assertLoginAllowed(body.email, ip);
    const user = await prisma.user.findUnique({ where: { email: body.email } });
    const valid = user ? await verifyPassword(body.password, user.passwordHash) : false;
    await recordLoginAttempt({ email: body.email, ip, success: valid, userId: user?.id });
    if (!user || !valid) {
      throw new ApiError("UNAUTHORIZED", "이메일 또는 비밀번호가 올바르지 않습니다.", 401);
    }
    const { token, expiresAt } = await createSession(user.id, {
      ip,
      userAgent: request.headers.get("user-agent") ?? undefined,
    });
    await writeAudit({ action: "auth.login", userId: user.id, ip });
    const res = ok({ user: publicUser(user) });
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
    return res;
  } catch (error) {
    return handleError(error);
  }
}
