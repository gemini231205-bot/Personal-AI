import { NextRequest } from "next/server";
import { prisma } from "@/lib/db";
import { ok, handleError, ApiError } from "@/lib/api";
import { signupSchema } from "@/lib/validation";
import { hashPassword, passwordPolicy } from "@/lib/auth/password";
import { createSession, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth/session";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { rateLimit } from "@/lib/auth/rate-limit";
import { publicUser } from "@/lib/serializers";

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const ip = clientIp(request);
    rateLimit(`signup:${ip}`, 8, 15 * 60 * 1000);
    const body = signupSchema.parse(await request.json());
    const policy = passwordPolicy(body.password);
    if (policy) throw new ApiError("VALIDATION", policy, 422);
    const exists = await prisma.user.findUnique({ where: { email: body.email } });
    if (exists) throw new ApiError("CONFLICT", "이미 사용 중인 이메일입니다.", 409);
    const user = await prisma.user.create({
      data: {
        name: body.name,
        email: body.email,
        passwordHash: await hashPassword(body.password),
      },
    });
    const { token, expiresAt } = await createSession(user.id, {
      ip,
      userAgent: request.headers.get("user-agent") ?? undefined,
    });
    await writeAudit({ action: "auth.signup", userId: user.id, ip });
    const res = ok({ user: publicUser(user) }, 201);
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
    return res;
  } catch (error) {
    return handleError(error);
  }
}

export const runtime = "nodejs";
