import { NextRequest } from "next/server";
import { handleError, ok, unauthorized } from "@/lib/api";
import { requireUser, destroyAllSessions } from "@/lib/auth/session";
import { passwordChangeSchema } from "@/lib/validation";
import { hashPassword, passwordPolicy, verifyPassword } from "@/lib/auth/password";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { ApiError } from "@/lib/api";

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = passwordChangeSchema.parse(await request.json());
    const okPw = await verifyPassword(body.currentPassword, user.passwordHash);
    if (!okPw) throw unauthorized("현재 비밀번호가 올바르지 않습니다.");
    const policy = passwordPolicy(body.nextPassword);
    if (policy) throw new ApiError("VALIDATION", policy, 422);
    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash: await hashPassword(body.nextPassword) },
    });
    await destroyAllSessions(user.id);
    await writeAudit({ action: "auth.password_change", userId: user.id, ip: clientIp(request) });
    return ok({ restarted: true });
  } catch (error) {
    return handleError(error);
  }
}
