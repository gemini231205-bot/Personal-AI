import { NextRequest } from "next/server";
import { ok, handleError } from "@/lib/api";
import { destroySession, readSessionToken, SESSION_COOKIE, getCurrentUser } from "@/lib/auth/session";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await getCurrentUser();
    const token = await readSessionToken();
    if (token) await destroySession(token);
    if (user) await writeAudit({ action: "auth.logout", userId: user.id, ip: clientIp(request) });
    const res = ok({ ok: true });
    res.cookies.set(SESSION_COOKIE, "", { path: "/", expires: new Date(0) });
    return res;
  } catch (error) {
    return handleError(error);
  }
}
