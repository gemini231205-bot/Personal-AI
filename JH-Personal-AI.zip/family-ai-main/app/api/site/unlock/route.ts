import { NextRequest } from "next/server";
import { handleError, ok, unauthorized } from "@/lib/api";
import { SITE_COOKIE, safeEqual, siteCookieValue, sitePassword, sitePasswordEnabled } from "@/lib/auth/site-gate";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { rateLimit } from "@/lib/auth/rate-limit";
import { z } from "zod";

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    if (!sitePasswordEnabled()) return ok({ unlocked: true, required: false });
    rateLimit(`site-unlock:${clientIp(request)}`, 8, 15 * 60 * 1000);
    const body = z.object({ password: z.string().min(1) }).parse(await request.json());
    const expected = sitePassword();
    if (!safeEqual(body.password, expected)) {
      throw unauthorized("사이트 비밀번호가 올바르지 않습니다.");
    }
    const res = ok({ unlocked: true, required: true });
    res.cookies.set(SITE_COOKIE, await siteCookieValue(), {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });
    return res;
  } catch (error) {
    return handleError(error);
  }
}

export async function GET() {
  return ok({ required: sitePasswordEnabled() });
}
