import { NextRequest } from "next/server";
import { handleError, fail, ApiError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { assertAiBudget, rateLimit } from "@/lib/auth/rate-limit";
import { orchestrateChat } from "@/lib/ai/orchestrate";
import { logUsage } from "@/lib/ai/usage";
import { writeAudit } from "@/lib/security/audit";
import { requireMembership } from "@/lib/family/permissions";
import { z } from "zod";
import type { ChatMessage } from "@/lib/ai/types";

export const maxDuration = 60;

const schema = z.object({
  conversationId: z.string().optional(),
  message: z.string().trim().min(1).max(8000),
  scope: z.enum(["personal", "family"]).default("personal"),
  regenerateOf: z.string().optional(),
  fileId: z.string().optional(),
});

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);

    const user = await requireUser();

    rateLimit(`ai:${user.id}`, 30, 60_000);
    await assertAiBudget(user.id);

    const body = schema.parse(
      await request.json(),
    );

    let conversationId = body.conversationId;

    let fileId: string | undefined;

    if (body.scope === "personal" && body.fileId) {
      const file = await prisma.personalFile.findFirst({
        where: {
          id: body.fileId,
          userId: user.id,
        },
        select: {
          id: true,
        },
      });

      if (!file) {
        throw new ApiError(
          "NOT_FOUND",
          "첨부 파일을 찾을 수 없습니다.",
          404,
        );
      }

      fileId = file.id;
    }

    if (body.scope === "personal") {
      if (conversationId) {
        const owned =
          await prisma.conversation.findFirst({
            where: {
              id: conversationId,
              userId: user.id,
              scope: "PERSONAL",
            },
          });

        if (!owned) {
          throw new ApiError(
            "FORBIDDEN",
            "이 대화에 접근할 수 없습니다.",
            403,
          );
        }
      } else {
        const created =
          await prisma.conversation.create({
            data: {
              title: body.message.slice(0, 32),
              scope: "PERSONAL",
              userId: user.id,
            },
          });

        conversationId = created.id;
      }

      await prisma.message.create({
        data: {
          conversationId,
          authorId: user.id,
          role: "USER",
          content: body.message,
        },
      });
    }

    const membership = user.memberships[0];

    const familyId =
      membership?.familyId ?? null;

    if (body.scope === "family") {
      if (!familyId) {
        throw new ApiError(
          "NOT_FOUND",
          "가족이 없습니다.",
          404,
        );
      }

      await requireMembership(
        user.id,
        familyId,
      );
    }

    const historyRows =
      body.scope === "personal" &&
      conversationId
        ? await prisma.message.findMany({
            where: {
              conversationId,
            },
            orderBy: {
              createdAt: "asc",
            },
            take: 40,
          })
        : [];

    const history: ChatMessage[] =
      historyRows
        .slice(0, -1)
        .map((m) => ({
          role:
            m.role === "ASSISTANT"
              ? "assistant"
              : m.role === "SYSTEM"
                ? "system"
                : "user",
          content: m.content,
        }));

    const {
      provider,
      system,
      citations,
      kind,
    } = await orchestrateChat({
      question: body.message,
      history,
      fileId,
      ctx: {
        userId: user.id,
        familyId:
          body.scope === "family"
            ? familyId
            : null,
        scope: body.scope,
        allowSharedPersonal: Boolean(
          user.shareFamilyContext &&
            body.scope === "family",
        ),
      },
    });

    const encoder = new TextEncoder();

    let full = "";

    const stream =
      new ReadableStream({
        async start(controller) {
          const send = (
            event: string,
            data: unknown,
          ) => {
            controller.enqueue(
              encoder.encode(
                `event: ${event}\ndata: ${JSON.stringify(
                  data,
                )}\n\n`,
              ),
            );
          };

          send("meta", {
            conversationId,
            kind,
            citations,
            provider: provider.name,
            model: provider.model,
          });

          try {
            const gen =
              provider.streamChat({
                system,
                messages: [
                  ...history,
                  {
                    role: "user",
                    content: body.message,
                  },
                ],
              });

            let result = await gen.next();

            while (!result.done) {
              full += result.value;

              send("delta", {
                text: result.value,
              });

              result = await gen.next();
            }

            const usage = result.value;

            await logUsage({
              userId: user.id,
              familyId:
                body.scope === "family"
                  ? familyId
                  : null,
              provider: usage.provider,
              model: usage.model,
              inputTokens:
                usage.inputTokens,
              outputTokens:
                usage.outputTokens,
            });

            if (
              body.scope === "personal" &&
              conversationId
            ) {
              const saved =
                await prisma.message.create({
                  data: {
                    conversationId,
                    role: "ASSISTANT",
                    content:
                      full || usage.content,
                    citations:
                      citations ?? undefined,
                  },
                });

              await prisma.conversation.update(
                {
                  where: {
                    id: conversationId,
                  },
                  data: {
                    updatedAt: new Date(),
                    title:
                      historyRows.length <= 1
                        ? body.message.slice(
                            0,
                            32,
                          )
                        : undefined,
                  },
                },
              );

              send("done", {
                messageId: saved.id,
                content: saved.content,
                citations,
              });
            } else {
              send("done", {
                content:
                  full || usage.content,
                citations,
              });
            }

            await writeAudit({
              action: "ai.use",
              userId: user.id,
              familyId:
                body.scope === "family"
                  ? familyId
                  : null,
              metadata: {
                scope: body.scope,
                kind,
                fileId: fileId ?? null,
              },
              ip: clientIp(request),
            });
          } catch (error) {
            const mapped =
              error instanceof ApiError
                ? error
                : new ApiError(
                    "AI_UNAVAILABLE",
                    error instanceof Error
                      ? error.message
                      : "AI 응답에 실패했습니다.",
                    503,
                  );

            if (
              body.scope === "personal" &&
              conversationId
            ) {
              await prisma.message.create({
                data: {
                  conversationId,
                  role: "ASSISTANT",
                  content: "",
                  error: mapped.message,
                },
              });
            }

            send("error", {
              message: mapped.message,
              code: mapped.code,
              status: mapped.status,
            });
          } finally {
            controller.close();
          }
        },
      });

    return new Response(stream, {
      headers: {
        "Content-Type":
          "text/event-stream; charset=utf-8",
        "Cache-Control":
          "no-cache, no-transform",
        Connection: "keep-alive",
      },
    });
  } catch (error) {
    if (error instanceof ApiError) {
      return fail(
        error.code,
        error.message,
        error.status,
      );
    }

    return handleError(error);
  }
}
