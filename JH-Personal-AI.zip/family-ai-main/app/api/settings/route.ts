import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { privacySchema, profileSchema } from "@/lib/validation";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { publicUser } from "@/lib/serializers";
import { providerStatus } from "@/lib/ai/provider";
import { z } from "zod";

export async function GET() {
  try {
    const user = await requireUser();
    const usage = await prisma.aIUsageLog.aggregate({
      where: { userId: user.id },
      _sum: { inputTokens: true, outputTokens: true, estimatedCost: true },
      _count: true,
    });
    return ok({ user: publicUser(user), ai: providerStatus(), usage });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = z
      .object({
        profile: profileSchema.optional(),
        privacy: privacySchema.optional(),
      })
      .parse(await request.json());
    const updated = await prisma.user.update({
      where: { id: user.id },
      data: {
        ...body.profile,
        ...body.privacy,
      },
    });
    await writeAudit({
      action: "settings.update",
      userId: user.id,
      metadata: { keys: Object.keys(body) },
      ip: clientIp(request),
    });
    return ok({ user: publicUser(updated) });
  } catch (error) {
    return handleError(error);
  }
}
