import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireDmAccess } from "@/lib/dm/access";
import { prisma } from "@/lib/db";
import { assertCsrf } from "@/lib/security/csrf";

export async function POST(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    await requireDmAccess(user.id, id);
    await prisma.conversationMember.update({
      where: { conversationId_userId: { conversationId: id, userId: user.id } },
      data: { lastReadAt: new Date() },
    });
    return ok({ read: true });
  } catch (error) {
    return handleError(error);
  }
}
