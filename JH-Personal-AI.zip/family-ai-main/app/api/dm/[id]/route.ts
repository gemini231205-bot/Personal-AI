import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireDmAccess, peerOf, publicDmMessage } from "@/lib/dm/access";
import { prisma } from "@/lib/db";

export async function GET(_request: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const conversation = await requireDmAccess(user.id, id);
    const messages = await prisma.message.findMany({
      where: { conversationId: conversation.id },
      include: { author: true },
      orderBy: { createdAt: "asc" },
      take: 200,
    });
    return ok({
      conversation: {
        id: conversation.id,
        peer: peerOf(user.id, conversation.members),
        memberCount: conversation.members.length,
      },
      messages: messages.map(publicDmMessage),
    });
  } catch (error) {
    return handleError(error);
  }
}
