import { handleError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireDmAccess, publicDmMessage } from "@/lib/dm/access";
import { prisma } from "@/lib/db";

export const maxDuration = 60;

export async function GET(_request: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    await requireDmAccess(user.id, id);
    const encoder = new TextEncoder();
    let last = new Date();
    let closed = false;
    let interval: ReturnType<typeof setInterval> | undefined;
    let keepalive: ReturnType<typeof setInterval> | undefined;

    const stop = () => {
      if (closed) return;
      closed = true;
      if (interval) clearInterval(interval);
      if (keepalive) clearInterval(keepalive);
    };

    const stream = new ReadableStream({
      start(controller) {
        const send = (chunk: string) => {
          if (closed) return;
          try {
            controller.enqueue(encoder.encode(chunk));
          } catch {
            stop();
          }
        };
        const tick = async () => {
          if (closed) return;
          try {
            await requireDmAccess(user.id, id);
            const messages = await prisma.message.findMany({
              where: { conversationId: id, createdAt: { gt: last } },
              include: { author: true },
              orderBy: { createdAt: "asc" },
            });
            if (messages.length) {
              last = messages[messages.length - 1].createdAt;
              send(`event: messages\ndata: ${JSON.stringify({ messages: messages.map(publicDmMessage) })}\n\n`);
            }
          } catch {
            send(`event: ping\ndata: {}\n\n`);
          }
        };
        interval = setInterval(() => {
          void tick();
        }, 2000);
        keepalive = setInterval(() => {
          send(`event: ping\ndata: {}\n\n`);
        }, 15000);
        void tick();
        send(`event: ready\ndata: {}\n\n`);
      },
      cancel() {
        stop();
      },
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream; charset=utf-8",
        "Cache-Control": "no-cache, no-transform",
        Connection: "keep-alive",
      },
    });
  } catch (error) {
    return handleError(error);
  }
}
