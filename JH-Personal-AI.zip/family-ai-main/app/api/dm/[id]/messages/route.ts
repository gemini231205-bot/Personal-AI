import { NextRequest } from "next/server";
import { handleError, ok, forbidden, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireDmAccess, publicDmMessage } from "@/lib/dm/access";
import { prisma } from "@/lib/db";
import { assertCsrf } from "@/lib/security/csrf";
import { notifyUser } from "@/lib/notifications";
import { z } from "zod";

export async function POST(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    const conversation = await requireDmAccess(user.id, id);
    const body = z.object({ content: z.string().trim().min(1).max(4000) }).parse(await request.json());
    const message = await prisma.message.create({
      data: {
        conversationId: conversation.id,
        authorId: user.id,
        role: "USER",
        content: body.content,
      },
      include: { author: true },
    });
    await prisma.conversation.update({ where: { id: conversation.id }, data: { updatedAt: new Date() } });
    const peer = conversation.members.find((m) => m.userId !== user.id);
    if (peer) {
      await notifyUser({
        userId: peer.userId,
        familyId: conversation.familyId ?? undefined,
        type: "dm.message",
        title: `${user.name}님의 메시지`,
        body: body.content.slice(0, 80),
        href: `/family/dm/${conversation.id}`,
      });
    }
    return ok({ message: publicDmMessage(message) }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    await requireDmAccess(user.id, id);
    const body = z.object({ messageId: z.string(), content: z.string().trim().min(1).max(4000) }).parse(await request.json());
    const existing = await prisma.message.findUnique({ where: { id: body.messageId } });
    if (!existing || existing.conversationId !== id || existing.deletedAt) throw notFound();
    if (existing.authorId !== user.id) throw forbidden("본인 메시지만 수정할 수 있습니다.");
    const message = await prisma.message.update({
      where: { id: existing.id },
      data: { content: body.content, editedAt: new Date() },
      include: { author: true },
    });
    return ok({ message: publicDmMessage(message) });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    await requireDmAccess(user.id, id);
    const body = z.object({ messageId: z.string() }).parse(await request.json());
    const existing = await prisma.message.findUnique({ where: { id: body.messageId } });
    if (!existing || existing.conversationId !== id) throw notFound();
    if (existing.authorId !== user.id) throw forbidden("본인 메시지만 삭제할 수 있습니다.");
    const message = await prisma.message.update({
      where: { id: existing.id },
      data: { deletedAt: new Date(), content: "삭제된 메시지입니다." },
      include: { author: true },
    });
    return ok({ message: publicDmMessage(message) });
  } catch (error) {
    return handleError(error);
  }
}
