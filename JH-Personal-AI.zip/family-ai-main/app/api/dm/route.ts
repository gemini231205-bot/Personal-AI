import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { assertCsrf } from "@/lib/security/csrf";
import { prisma } from "@/lib/db";
import { openOrCreateDm, peerOf } from "@/lib/dm/access";
import { requireFamilyOf } from "@/lib/family/permissions";
import { z } from "zod";

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const conversations = await prisma.conversation.findMany({
      where: {
        scope: "DIRECT",
        familyId: membership.familyId,
        members: { some: { userId: user.id } },
      },
      include: {
        members: { include: { user: true } },
        messages: { orderBy: { createdAt: "desc" }, take: 1 },
      },
      orderBy: { updatedAt: "desc" },
    });
    const items = await Promise.all(
      conversations.map(async (c) => {
        const mine = c.members.find((m) => m.userId === user.id);
        const unread = await prisma.message.count({
          where: {
            conversationId: c.id,
            deletedAt: null,
            authorId: { not: user.id },
            createdAt: mine?.lastReadAt ? { gt: mine.lastReadAt } : undefined,
          },
        });
        const last = c.messages[0];
        return {
          id: c.id,
          peer: peerOf(user.id, c.members),
          lastMessage: last
            ? {
                id: last.id,
                content: last.deletedAt ? "삭제된 메시지입니다." : last.content,
                createdAt: last.createdAt,
                authorId: last.authorId,
              }
            : null,
          updatedAt: c.updatedAt,
          unread,
        };
      }),
    );
    return ok({ conversations: items });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = z.object({ userId: z.string().min(1) }).parse(await request.json());
    const conversation = await openOrCreateDm(user.id, body.userId);
    return ok({
      conversation: {
        id: conversation.id,
        peer: peerOf(user.id, conversation.members),
      },
    });
  } catch (error) {
    return handleError(error);
  }
}
