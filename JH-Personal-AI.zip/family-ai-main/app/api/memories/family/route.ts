import { NextRequest } from "next/server";
import { handleError, ok, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf, requireMembership } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { memorySchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";
import { z } from "zod";

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const memories = await prisma.familyMemory.findMany({
      where: { familyId: membership.familyId },
      orderBy: { updatedAt: "desc" },
    });
    return ok({ memories });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const body = memorySchema.parse(await request.json());
    const memory = await prisma.familyMemory.create({
      data: {
        familyId: membership.familyId,
        title: body.title,
        content: body.content,
        tags: body.tags ?? [],
        createdById: user.id,
      },
    });
    return ok({ memory }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = memorySchema.partial().extend({ id: z.string() }).parse(await request.json());
    const existing = await prisma.familyMemory.findUnique({ where: { id: body.id } });
    if (!existing) throw notFound();
    await requireMembership(user.id, existing.familyId);
    const memory = await prisma.familyMemory.update({
      where: { id: body.id },
      data: { title: body.title, content: body.content, tags: body.tags },
    });
    return ok({ memory });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = z.object({ id: z.string() }).parse(await request.json());
    const existing = await prisma.familyMemory.findUnique({ where: { id } });
    if (!existing) throw notFound();
    await requireMembership(user.id, existing.familyId);
    await prisma.familyMemory.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (error) {
    return handleError(error);
  }
}
