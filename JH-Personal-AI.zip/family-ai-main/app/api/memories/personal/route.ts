import { NextRequest } from "next/server";
import { handleError, ok, forbidden, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { memorySchema } from "@/lib/validation";
import { looksSensitive } from "@/lib/security/sanitize";
import { assertCsrf } from "@/lib/security/csrf";
import { z } from "zod";

export async function GET() {
  try {
    const user = await requireUser();
    const memories = await prisma.personalMemory.findMany({
      where: { userId: user.id },
      orderBy: { updatedAt: "desc" },
    });
    return ok({ memories });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = memorySchema.parse(await request.json());
    if (looksSensitive(body.content)) {
      return ok({
        blocked: true,
        message: "민감해 보이는 정보는 자동으로 저장하지 않습니다. 꼭 필요하면 표현을 바꿔 주세요.",
      });
    }
    const memory = await prisma.personalMemory.create({
      data: {
        userId: user.id,
        title: body.title,
        content: body.content,
        tags: body.tags ?? [],
        sharedToFamily: false,
      },
    });
    return ok({ memory }, 201);
  } catch (error) {
    return handleError(error);
  }
}

const patchSchema = memorySchema.partial().extend({ id: z.string() });

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = patchSchema.parse(await request.json());
    const existing = await prisma.personalMemory.findUnique({ where: { id: body.id } });
    if (!existing) throw notFound();
    if (existing.userId !== user.id) throw forbidden();
    const memory = await prisma.personalMemory.update({
      where: { id: body.id },
      data: {
        title: body.title,
        content: body.content,
        tags: body.tags,
        sharedToFamily: body.sharedToFamily,
      },
    });
    return ok({ memory, needsConfirm: body.sharedToFamily && !existing.sharedToFamily });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = z.object({ id: z.string() }).parse(await request.json());
    const existing = await prisma.personalMemory.findUnique({ where: { id } });
    if (!existing) throw notFound();
    if (existing.userId !== user.id) throw forbidden();
    await prisma.personalMemory.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (error) {
    return handleError(error);
  }
}
