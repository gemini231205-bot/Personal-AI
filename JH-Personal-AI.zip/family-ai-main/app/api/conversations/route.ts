import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { conversationSchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";

export async function GET(request: NextRequest) {
  try {
    const user = await requireUser();
    const q = request.nextUrl.searchParams.get("q") ?? "";
    const conversations = await prisma.conversation.findMany({
      where: {
        userId: user.id,
        scope: "PERSONAL",
        title: q ? { contains: q, mode: "insensitive" } : undefined,
      },
      orderBy: { updatedAt: "desc" },
      take: 50,
      include: { messages: { orderBy: { createdAt: "desc" }, take: 1 } },
    });
    return ok({ conversations });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = conversationSchema.parse(await request.json().catch(() => ({})));
    const conversation = await prisma.conversation.create({
      data: {
        title: body.title ?? "새 대화",
        scope: "PERSONAL",
        userId: user.id,
      },
    });
    return ok({ conversation }, 201);
  } catch (error) {
    return handleError(error);
  }
}
