import { NextRequest } from "next/server";
import { handleError, ok, forbidden, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db";
import { conversationSchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";

async function owned(userId: string, id: string) {
  const conversation = await prisma.conversation.findUnique({ where: { id } });
  if (!conversation) throw notFound("대화를 찾을 수 없습니다.");
  if (conversation.scope !== "PERSONAL" || conversation.userId !== userId) {
    throw forbidden("이 대화에 접근할 수 없습니다.");
  }
  return conversation;
}

export async function GET(_request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const user = await requireUser();
    const { id } = await ctx.params;
    const conversation = await owned(user.id, id);
    const messages = await prisma.message.findMany({
      where: { conversationId: conversation.id },
      orderBy: { createdAt: "asc" },
    });
    return ok({ conversation, messages });
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    await owned(user.id, id);
    const body = conversationSchema.parse(await request.json());
    const conversation = await prisma.conversation.update({
      where: { id },
      data: { title: body.title },
    });
    return ok({ conversation });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = await ctx.params;
    await owned(user.id, id);
    await prisma.conversation.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (error) {
    return handleError(error);
  }
}
