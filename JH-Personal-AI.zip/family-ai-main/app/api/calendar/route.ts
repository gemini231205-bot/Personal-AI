import { NextRequest } from "next/server";
import { handleError, ok, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf, requireMembership } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { eventSchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";
import { notifyFamily } from "@/lib/notifications";
import { endOfMonth, startOfMonth } from "@/lib/utils";
import { z } from "zod";

export async function GET(request: NextRequest) {
  try {
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const from = request.nextUrl.searchParams.get("from");
    const to = request.nextUrl.searchParams.get("to");
    const events = await prisma.calendarEvent.findMany({
      where: {
        familyId: membership.familyId,
        startsAt: {
          gte: from ? new Date(from) : startOfMonth(),
          lte: to ? new Date(to) : endOfMonth(),
        },
      },
      include: { attendees: { include: { user: true } }, createdBy: true },
      orderBy: { startsAt: "asc" },
    });
    return ok({ events });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    const body = eventSchema.parse(await request.json());
    const event = await prisma.calendarEvent.create({
      data: {
        familyId: membership.familyId,
        title: body.title,
        description: body.description,
        location: body.location,
        startsAt: new Date(body.startsAt),
        endsAt: new Date(body.endsAt),
        allDay: body.allDay ?? false,
        recurrence: body.recurrence ?? "NONE",
        createdById: user.id,
        attendees: body.attendeeIds?.length
          ? { create: body.attendeeIds.map((userId) => ({ userId })) }
          : undefined,
      },
      include: { attendees: { include: { user: true } }, createdBy: true },
    });
    await notifyFamily({
      familyId: membership.familyId,
      type: "calendar.create",
      title: "새 가족 일정",
      body: event.title,
      href: "/family/calendar",
      exceptUserId: user.id,
    });
    return ok({ event }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = eventSchema.partial().extend({ id: z.string() }).parse(await request.json());
    const existing = await prisma.calendarEvent.findUnique({ where: { id: body.id } });
    if (!existing) throw notFound();
    await requireMembership(user.id, existing.familyId);
    const event = await prisma.calendarEvent.update({
      where: { id: body.id },
      data: {
        title: body.title,
        description: body.description,
        location: body.location,
        startsAt: body.startsAt ? new Date(body.startsAt) : undefined,
        endsAt: body.endsAt ? new Date(body.endsAt) : undefined,
        allDay: body.allDay,
        recurrence: body.recurrence,
      },
      include: { attendees: { include: { user: true } }, createdBy: true },
    });
    if (body.attendeeIds) {
      await prisma.eventAttendee.deleteMany({ where: { eventId: event.id } });
      if (body.attendeeIds.length) {
        await prisma.eventAttendee.createMany({
          data: body.attendeeIds.map((userId) => ({ eventId: event.id, userId })),
        });
      }
    }
    return ok({ event });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = z.object({ id: z.string() }).parse(await request.json());
    const existing = await prisma.calendarEvent.findUnique({ where: { id } });
    if (!existing) throw notFound();
    await requireMembership(user.id, existing.familyId);
    await prisma.calendarEvent.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (error) {
    return handleError(error);
  }
}
