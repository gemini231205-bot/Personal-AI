import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { familySearch, personalSearch } from "@/lib/search";

export async function GET(request: NextRequest) {
  try {
    const user = await requireUser();
    const q = request.nextUrl.searchParams.get("q") ?? "";
    const scope = request.nextUrl.searchParams.get("scope") ?? "personal";
    if (scope === "family") {
      const membership = user.memberships[0];
      if (!membership) return ok({ results: null });
      const results = await familySearch(user.id, membership.familyId, q);
      return ok({ results });
    }
    const results = await personalSearch(user.id, q);
    return ok({ results });
  } catch (error) {
    return handleError(error);
  }
}
