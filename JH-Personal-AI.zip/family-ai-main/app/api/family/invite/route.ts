import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireRole } from "@/lib/family/permissions";
import { createInvite } from "@/lib/family/invite";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { appUrl } from "@/lib/env";
import { prisma } from "@/lib/db";
import { z } from "zod";

function payload(code: string | null | undefined, expiresAt?: Date | null, memberCount = 0) {
  return {
    code: code ?? null,
    link: code ? `${appUrl()}/signup?invite=${code}` : null,
    expiresAt: expiresAt ?? null,
    memberCount,
  };
}

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await prisma.familyMember.findFirst({ where: { userId: user.id } });
    if (!membership) return ok(payload(null, null, 0));
    const [family, current, memberCount] = await Promise.all([
      prisma.family.findUnique({ where: { id: membership.familyId } }),
      prisma.familyInvite.findFirst({
        where: { familyId: membership.familyId, revoked: false },
        orderBy: { createdAt: "desc" },
      }),
      prisma.familyMember.count({ where: { familyId: membership.familyId } }),
    ]);
    return ok(payload(family?.inviteCode ?? current?.code, current?.expiresAt, memberCount));
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await prisma.familyMember.findFirst({ where: { userId: user.id } });
    if (!membership) return ok(payload(null));
    await requireRole(user.id, membership.familyId, ["OWNER", "ADMIN"]);
    const body = z
      .object({ expiresInDays: z.number().int().min(1).max(90).optional() })
      .parse(await request.json().catch(() => ({})));
    const invite = await createInvite({
      familyId: membership.familyId,
      createdById: user.id,
      expiresInDays: body.expiresInDays,
    });
    const memberCount = await prisma.familyMember.count({ where: { familyId: membership.familyId } });
    await writeAudit({
      action: "family.invite_rotate",
      userId: user.id,
      familyId: membership.familyId,
      ip: clientIp(request),
    });
    return ok(payload(invite.code, invite.expiresAt, memberCount));
  } catch (error) {
    return handleError(error);
  }
}
