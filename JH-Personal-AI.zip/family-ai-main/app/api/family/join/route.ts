import { NextRequest } from "next/server";
import { handleError, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { joinSchema } from "@/lib/validation";
import { joinByCode } from "@/lib/family/invite";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { notifyFamily } from "@/lib/notifications";

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = joinSchema.parse(await request.json());
    const membership = await joinByCode(user.id, body.code);
    await writeAudit({
      action: "family.join",
      userId: user.id,
      familyId: membership.familyId,
      ip: clientIp(request),
    });
    await notifyFamily({
      familyId: membership.familyId,
      type: "family.join",
      title: "새 가족이 참여했습니다",
      body: `${user.name}님이 가족에 참여했습니다.`,
      href: "/family/members",
      exceptUserId: user.id,
    });
    return ok({ membership });
  } catch (error) {
    return handleError(error);
  }
}
