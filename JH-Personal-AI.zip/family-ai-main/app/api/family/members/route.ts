import { NextRequest } from "next/server";
import { handleError, ok, forbidden, ApiError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireMembership, requireRole } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { isOnline, publicMember } from "@/lib/serializers";
import { FamilyRole } from "@prisma/client";
import { z } from "zod";

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await prisma.familyMember.findFirst({ where: { userId: user.id } });
    if (!membership) return ok({ members: [], memberCount: 0 });
    const members = await prisma.familyMember.findMany({
      where: { familyId: membership.familyId },
      include: { user: true, family: true },
      orderBy: { joinedAt: "asc" },
    });
    return ok({
      memberCount: members.length,
      members: members.map((m) => ({ ...publicMember(m), online: isOnline(m.lastSeenAt) })),
    });
  } catch (error) {
    return handleError(error);
  }
}

const patchSchema = z.object({
  userId: z.string(),
  role: z.enum(["OWNER", "ADMIN", "MEMBER"]).optional(),
  remove: z.boolean().optional(),
});

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const actor = await requireUser();
    const body = patchSchema.parse(await request.json());
    const actorMem = await prisma.familyMember.findFirst({ where: { userId: actor.id } });
    if (!actorMem) throw forbidden();
    await requireRole(actor.id, actorMem.familyId, ["OWNER", "ADMIN"]);
    const target = await requireMembership(body.userId, actorMem.familyId);
    if (target.role === "OWNER" && actorMem.role !== "OWNER") {
      throw forbidden("소유자의 권한은 변경할 수 없습니다.");
    }
    if (body.remove) {
      if (target.role === "OWNER") throw forbidden("소유자는 제거할 수 없습니다.");
      await prisma.familyMember.delete({ where: { id: target.id } });
      await writeAudit({
        action: "family.member_remove",
        userId: actor.id,
        familyId: actorMem.familyId,
        metadata: { targetUserId: body.userId },
        ip: clientIp(request),
      });
      return ok({ removed: true });
    }
    if (body.role) {
      if (body.role === "OWNER" && actorMem.role !== "OWNER") {
        throw new ApiError("FORBIDDEN", "소유권 이전은 소유자만 할 수 있습니다.", 403);
      }
      if (body.role === "OWNER") {
        await prisma.$transaction([
          prisma.familyMember.update({ where: { id: actorMem.id }, data: { role: "ADMIN" } }),
          prisma.familyMember.update({ where: { id: target.id }, data: { role: "OWNER" as FamilyRole } }),
        ]);
      } else {
        await prisma.familyMember.update({ where: { id: target.id }, data: { role: body.role } });
      }
      await writeAudit({
        action: "family.role_change",
        userId: actor.id,
        familyId: actorMem.familyId,
        metadata: { targetUserId: body.userId, role: body.role },
        ip: clientIp(request),
      });
    }
    return ok({ updated: true });
  } catch (error) {
    return handleError(error);
  }
}
