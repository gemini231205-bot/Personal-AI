import { NextRequest } from "next/server";
import { handleError, ok, ApiError } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { familyCreateSchema } from "@/lib/validation";
import { prisma } from "@/lib/db";
import { inviteCode } from "@/lib/utils";
import { writeAudit } from "@/lib/security/audit";
import { assertCsrf, clientIp } from "@/lib/security/csrf";
import { requireFamilyOf } from "@/lib/family/permissions";

export async function GET() {
  try {
    const user = await requireUser();
    const membership = await prisma.familyMember.findFirst({
      where: { userId: user.id },
      include: {
        family: {
          include: {
            members: { include: { user: true } },
          },
        },
      },
    });
    return ok({ membership });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const existing = await prisma.familyMember.findFirst({ where: { userId: user.id } });
    if (existing) throw new ApiError("CONFLICT", "이미 가족에 소속되어 있습니다.", 409);
    const body = familyCreateSchema.parse(await request.json());
    const code = inviteCode();
    const family = await prisma.family.create({
      data: {
        name: body.name,
        inviteCode: code,
        createdById: user.id,
        members: { create: { userId: user.id, role: "OWNER" } },
        invites: {
          create: {
            code,
            createdById: user.id,
            expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          },
        },
        shoppingLists: { create: { name: "장보기" } },
      },
    });
    await writeAudit({
      action: "family.create",
      userId: user.id,
      familyId: family.id,
      ip: clientIp(request),
    });
    return ok({ family }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const membership = await requireFamilyOf(user.id);
    if (membership.role !== "OWNER" && membership.role !== "ADMIN") {
      throw new ApiError("FORBIDDEN", "가족 설정을 변경할 권한이 없습니다.", 403);
    }
    const body = familyCreateSchema.partial().parse(await request.json());
    const family = await prisma.family.update({
      where: { id: membership.familyId },
      data: { name: body.name },
    });
    await writeAudit({
      action: "family.update",
      userId: user.id,
      familyId: family.id,
      ip: clientIp(request),
    });
    return ok({ family });
  } catch (error) {
    return handleError(error);
  }
}
