import { NextRequest } from "next/server";
import { handleError, ok, forbidden, notFound } from "@/lib/api";
import { requireUser } from "@/lib/auth/session";
import { requireFamilyOf } from "@/lib/family/permissions";
import { prisma } from "@/lib/db";
import { wishlistSchema } from "@/lib/validation";
import { assertCsrf } from "@/lib/security/csrf";
import { z } from "zod";

export async function GET(request: NextRequest) {
  try {
    const user = await requireUser();
    const scope = request.nextUrl.searchParams.get("scope") ?? "PERSONAL";
    if (scope === "FAMILY") {
      const membership = await requireFamilyOf(user.id);
      const items = await prisma.wishlistItem.findMany({
        where: { familyId: membership.familyId, scope: "FAMILY" },
        include: { user: true },
        orderBy: [{ priority: "asc" }, { createdAt: "desc" }],
      });
      return ok({ items });
    }
    const items = await prisma.wishlistItem.findMany({
      where: { userId: user.id, scope: "PERSONAL" },
      include: { user: true },
      orderBy: [{ priority: "asc" }, { createdAt: "desc" }],
    });
    return ok({ items });
  } catch (error) {
    return handleError(error);
  }
}

export async function POST(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = wishlistSchema.parse(await request.json());
    const scope = body.scope ?? "PERSONAL";
    const membership = scope === "FAMILY" ? await requireFamilyOf(user.id) : null;
    if (scope === "FAMILY" && body.isPublic === false) {
      // family wishlist is shared by definition
    }
    const item = await prisma.wishlistItem.create({
      data: {
        scope,
        userId: user.id,
        familyId: membership?.familyId,
        name: body.name,
        description: body.description,
        url: body.url || null,
        priority: body.priority ?? 2,
        isPublic: scope === "FAMILY" ? true : Boolean(body.isPublic),
      },
      include: { user: true },
    });
    return ok({ item }, 201);
  } catch (error) {
    return handleError(error);
  }
}

export async function PATCH(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const body = wishlistSchema.partial().extend({ id: z.string() }).parse(await request.json());
    const existing = await prisma.wishlistItem.findUnique({ where: { id: body.id } });
    if (!existing) throw notFound();
    if (existing.userId !== user.id) throw forbidden();
    const item = await prisma.wishlistItem.update({
      where: { id: body.id },
      data: {
        name: body.name,
        description: body.description,
        url: body.url,
        priority: body.priority,
        isPublic: body.isPublic,
      },
      include: { user: true },
    });
    return ok({ item });
  } catch (error) {
    return handleError(error);
  }
}

export async function DELETE(request: NextRequest) {
  try {
    assertCsrf(request);
    const user = await requireUser();
    const { id } = z.object({ id: z.string() }).parse(await request.json());
    const existing = await prisma.wishlistItem.findUnique({ where: { id } });
    if (!existing) throw notFound();
    if (existing.userId !== user.id) throw forbidden();
    await prisma.wishlistItem.delete({ where: { id } });
    return ok({ deleted: true });
  } catch (error) {
    return handleError(error);
  }
}
