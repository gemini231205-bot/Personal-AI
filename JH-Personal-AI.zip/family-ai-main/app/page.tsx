import Link from "next/link";
import { getCurrentUser } from "@/lib/auth/session";
import { redirect } from "next/navigation";
import { Button } from "@/components/ui/button";

export default async function LandingPage() {
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");

  return (
    <main className="mx-auto flex min-h-screen max-w-5xl flex-col justify-center px-6 py-16">
      <p className="text-sm uppercase tracking-[0.25em] text-muted-foreground">JH AI</p>
      <h1 className="mt-3 max-w-3xl text-4xl font-semibold leading-tight md:text-6xl">
        나만의 생성형 AI,<br />JH AI
      </h1>
      <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
        개인 대화, 개인 메모리, 개인 파일을 바탕으로 나에게 맞게 작동하는 개인 AI입니다.
        웹 검색과 파일 분석도 한곳에서 사용할 수 있습니다.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Button asChild size="lg">
          <Link href="/signup">JH AI 시작하기</Link>
        </Button>
        <Button asChild size="lg" variant="outline">
          <Link href="/login">로그인</Link>
        </Button>
      </div>
      <div className="mt-16 grid gap-4 md:grid-cols-3">
        {[
          { title: "🧠 개인 AI", body: "대화와 이전 작업을 바탕으로 나에게 맞게 답합니다." },
          { title: "🗂️ 개인 기억", body: "내가 저장한 정보와 프로젝트를 AI가 참고합니다." },
          { title: "📄 파일 + 웹", body: "개인 파일을 분석하고 필요하면 최신 웹 정보를 검색합니다." },
        ].map((card) => (
          <div key={card.title} className="rounded-2xl border border-border bg-card p-5">
            <h2 className="font-semibold">{card.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{card.body}</p>
          </div>
        ))}
      </div>
    </main>
  );
}
