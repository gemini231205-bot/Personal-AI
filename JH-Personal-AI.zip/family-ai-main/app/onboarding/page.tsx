"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { api } from "@/lib/client";

export default function OnboardingPage() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);

  async function createFamily() {
    setBusy(true);
    try {
      await api("/api/family", { method: "POST", body: JSON.stringify({ name }) });
      router.replace("/dashboard");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "가족을 만들지 못했습니다.");
    } finally {
      setBusy(false);
    }
  }

  async function joinFamily() {
    setBusy(true);
    try {
      await api("/api/family/join", { method: "POST", body: JSON.stringify({ code }) });
      router.replace("/dashboard");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "참여하지 못했습니다.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col justify-center px-6">
      <h1 className="text-3xl font-semibold">가족을 만들거나 참여하세요</h1>
      <p className="mt-2 text-muted-foreground">한 계정은 한 가족에만 속합니다. 생성자는 OWNER가 됩니다.</p>
      <div className="mt-10 grid gap-6 md:grid-cols-2">
        <form
          className="rounded-2xl border border-border bg-card p-5"
          onSubmit={(e) => {
            e.preventDefault();
            void createFamily();
          }}
        >
          <h2 className="font-semibold">가족 만들기</h2>
          <Label className="mt-4 block">가족 이름</Label>
          <Input className="mt-2" value={name} onChange={(e) => setName(e.target.value)} placeholder="우리 가족" required />
          <Button className="mt-4 w-full" disabled={busy}>만들기</Button>
        </form>
        <form
          className="rounded-2xl border border-border bg-card p-5"
          onSubmit={(e) => {
            e.preventDefault();
            void joinFamily();
          }}
        >
          <h2 className="font-semibold">초대 코드로 참여</h2>
          <Label className="mt-4 block">초대 코드</Label>
          <Input className="mt-2" value={code} onChange={(e) => setCode(e.target.value)} placeholder="FAMILY-8K4P2" required />
          <Button className="mt-4 w-full" variant="outline" disabled={busy}>참여</Button>
        </form>
      </div>
    </main>
  );
}
