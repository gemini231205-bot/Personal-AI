import type { ReactNode } from "react";
import type { Metadata } from "next";
import { JetBrains_Mono, Noto_Sans_KR, Outfit } from "next/font/google";
import { Providers } from "@/components/providers";
import "./globals.css";

const display = Outfit({ variable: "--font-display", subsets: ["latin"] });
const korean = Noto_Sans_KR({ variable: "--font-kr", subsets: ["latin"], weight: ["400", "500", "600", "700"] });
const mono = JetBrains_Mono({ variable: "--font-mono", subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Family AI — 나의 AI, 그리고 우리 가족의 AI",
  description:
    "각 구성원은 자신만의 개인 AI를 갖고, 가족이 모이면 Family Room에서 Family AI를 함께 부릅니다. 개인 데이터는 기본 비공개입니다.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ko" className={`${display.variable} ${korean.variable} ${mono.variable} h-full antialiased`} suppressHydrationWarning>
      <body className="min-h-full bg-background text-foreground">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
