# JH AI — Personal AI Edition

이 버전은 기존 Family AI 프로젝트에서 **개인 AI(My AI) 부분을 중심으로 사용할 수 있도록 UI/진입 흐름을 정리한 포크**입니다.

핵심 기능:
- 로그인 / 회원가입 / 세션
- 개인 AI 대화 + 스트리밍
- 개인 메모리
- 개인 파일 업로드 + RAG
- Tavily 웹 검색
- OpenAI / Gemini / Local provider abstraction
- 개인 검색
- AI 사용량 / 보안 기능

중요:
- 기존 Prisma 스키마와 일부 Family 관련 서버 코드는 **삭제하지 않았습니다.** DB 마이그레이션을 새로 크게 만들지 않기 위해 보존한 것입니다.
- 기본 화면과 앱 진입 흐름에서는 Family 기능을 사용하지 않습니다.
- 기존 가족 기능을 다시 사용할 필요가 없다면 해당 route/API를 나중에 완전히 제거하는 2차 정리 작업을 할 수 있습니다.

# Family AI

각 가족 구성원은 **자신만의 개인 AI(My AI)** 를 갖고, 가족이 함께 있을 때는 **Family Room**에서 **✨ Family AI**를 호출합니다.

개인 대화·개인 메모리·개인 파일은 기본 비공개입니다. Family AI는 가족방, 가족 메모리, 가족 파일, 일정, 쇼핑, 투표, 위시리스트, 그리고 사용자가 명시적으로 공유한 데이터만 사용합니다.

## 기능

- 회원가입 / 로그인 / 로그아웃 / 세션 / 비밀번호 변경 / 계정 삭제
- 가족 생성, 만료되는 초대 코드·링크, 참여, 역할(OWNER/ADMIN/MEMBER), 구성원 제거 — 인원 수 제한 없음
- 가족 구성원 간 1:1 DM (기존 방 재사용, 읽음/수정/삭제, SSE, 서버 권한 검사)
- 개인 AI 대화: 스트리밍, 마크다운, 코드 복사, 재생성, 중지, 검색
- 개인 메모리·개인 파일·개인 파일 RAG (`personal_file:<userId>`)
- Family Room 실시간 채팅(SSE), 답장/수정/삭제, 읽음, ✨ AI 호출, 메시지→AI
- 가족 메모리, 파일 보관함, 파일 RAG (`family_file:<familyId>`)
- 가족 캘린더, 쇼핑 목록, 투표, 회의 AI, 식사/메뉴 AI, 위시리스트
- 알림, 개인/가족 검색, 웹 검색 abstraction
- AI provider abstraction (`openai` / `gemini` / `local`) + tool calling
- 감사 로그, AI 사용량 로그, 서버 권한 검사, 반응형·다크 모드

## 기술 스택

Next.js 16 (App Router) · TypeScript · Tailwind CSS · shadcn-style UI · Prisma · PostgreSQL · Zod · Vitest

## 폴더 구조

```text
app/            페이지와 Route Handlers
components/     UI, 채팅, 가족방
lib/
  ai/           provider, router, tools, usage
  auth/         세션, 비밀번호, 사이트 게이트(Web Crypto)
proxy.ts        요청 게이트 — 사이트 쿠키 해시 / 로그인 쿠키 존재만 확인
  family/       권한, 초대
  rag/          추출, 청크, 임베딩, 검색
  security/     CSRF, sanitize, audit
  storage/      local / Vercel Blob / S3
prisma/         스키마, 마이그레이션, seed
tests/          인증·가족·프라이버시·기능·배포 테스트
```

## 환경 변수

`.env.example`을 복사해 `.env`와 `.env.local`을 만듭니다.

필수:

- `DATABASE_URL` — PostgreSQL
- `AUTH_SECRET` — 세션 해시용 긴 문자열

선택:

- `AI_PROVIDER=openai|gemini|local`
- `OPENAI_API_KEY`, `OPENAI_MODEL`
- `GEMINI_API_KEY`, `GEMINI_MODEL`
- `WEB_SEARCH_PROVIDER=tavily`, `WEB_SEARCH_API_KEY`
- `PRIVATE_SITE_PASSWORD` 또는 `SITE_PASSWORD` — 사이트 전체 입장 게이트. 비우면 비활성
- `DIRECT_DATABASE_URL` — 마이그레이션용 다이렉트 Postgres URL
- `STORAGE_PROVIDER=local|blob|s3`, `BLOB_READ_WRITE_TOKEN` 또는 S3 자격 증명

키가 없으면 **LocalProvider**가 가족/개인 데이터와 도구를 사용해 동작합니다. API 키는 서버에만 두고 클라이언트에 노출하지 않습니다.

데이터는 세 영역으로 분리됩니다.

- **Personal** — 개인 AI 대화, 개인 메모리, 개인 파일
- **Family** — Family Room, Family AI, 가족 메모리/파일/일정/쇼핑/투표
- **Private DM** — 두 구성원만 보는 1:1 대화. Family AI는 DM을 읽지 않습니다.

선택적 `SITE_PASSWORD`는 위 계정/가족 관계와 별개의 사이트 입장 계층입니다.

## 로컬 실행

```bash
cp .env.example .env
# DATABASE_URL, AUTH_SECRET 입력
npm install
npx prisma migrate dev
npm run db:seed
npm run dev
```

개발 서버: `http://127.0.0.1:43123`

데모 계정(개발 전용, 프로덕션에 쓰지 마세요):

```text
demo@example.com
Demo1234!
```

같은 가족: `dad@example.com`, `jiho@example.com` / 동일 비밀번호 / 초대 코드 `FAMILY-8K4P2`

## DB 설정

PostgreSQL 16+를 준비한 뒤 `DATABASE_URL`을 넣습니다.

```bash
npx prisma generate
npx prisma migrate dev
```

## AI API 설정

1. OpenAI 또는 Gemini 키를 `.env`에만 넣습니다.
2. `AI_PROVIDER`를 `openai` 또는 `gemini`로 바꿉니다.
3. 키가 없거나 잘못되면 앱이 죽지 않고 친절한 오류를 보여 주고, 필요하면 local로 내려갑니다.

## 테스트

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

## 배포 (Vercel)

로컬 PostgreSQL(`127.0.0.1`)은 Vercel에서 사용할 수 없습니다. Neon, Supabase, Vercel Postgres 등 **호스팅 DB**의 `DATABASE_URL`로 교체하세요. 커넥션 풀러를 쓰면 `DIRECT_DATABASE_URL`에 다이렉트(비풀러) URL을 함께 넣습니다.

Vercel 서버리스 디스크는 영구 저장이 아닙니다. `STORAGE_PROVIDER=local` 은 배포에 쓰지 마세요. 파일 업로드는 `STORAGE_PROVIDER=blob` (Vercel Blob) 또는 `STORAGE_PROVIDER=s3` 가 필요합니다.

빌드는 `vercel-build`가 `prisma generate` → `prisma migrate deploy` → `next build`를 실행합니다. localhost `DATABASE_URL`이면 빌드가 실패합니다.

환경 변수는 코드에 넣지 말고 Vercel Project Settings → Environment Variables에만 넣습니다. `.env` / `.env.local`은 Git에 포함되지 않습니다.

### Vercel에 넣어야 하는 환경 변수

필수:

| 이름 | 설명 |
| --- | --- |
| `DATABASE_URL` | 호스팅 PostgreSQL. `127.0.0.1` / `localhost` 금지. 풀러 URL이면 `pgbouncer=true` 권장 |
| `DIRECT_DATABASE_URL` | 마이그레이션용 다이렉트(비풀러) URL. 풀러가 없으면 `DATABASE_URL`과 동일하게 |
| `AUTH_SECRET` | 세션 해시용 무작위 문자열, 16자 이상. `openssl rand -hex 32` |
| `PRIVATE_SITE_PASSWORD` | 사이트 공통 입장 비밀번호. 서버에서만 사용 |
| `AI_PROVIDER` | `openai` |
| `OPENAI_API_KEY` | OpenAI 키 |
| `WEB_SEARCH_PROVIDER` | `tavily` |
| `WEB_SEARCH_API_KEY` | Tavily 키 |
| `STORAGE_PROVIDER` | `blob` (권장) 또는 `s3` |
| `NEXT_PUBLIC_APP_URL` | 배포 URL, 예: `https://your-app.vercel.app` |

`STORAGE_PROVIDER=blob` 일 때:

| 이름 | 설명 |
| --- | --- |
| `BLOB_READ_WRITE_TOKEN` | Vercel 프로젝트에 Blob store를 만들면 자동 주입될 수 있음. 없으면 직접 추가 |

`STORAGE_PROVIDER=s3` 일 때:

| 이름 | 설명 |
| --- | --- |
| `STORAGE_BUCKET` | 버킷 이름 |
| `STORAGE_REGION` | 리전 |
| `STORAGE_ACCESS_KEY` | 액세스 키 |
| `STORAGE_SECRET_KEY` | 시크릿 키 |
| `STORAGE_ENDPOINT` | R2 등 S3 호환일 때만 |

선택:

| 이름 | 설명 |
| --- | --- |
| `OPENAI_MODEL` | 기본 `gpt-4o-mini` |
| `GEMINI_API_KEY` / `GEMINI_MODEL` | Gemini를 쓸 때만 |
| `SITE_PASSWORD` | `PRIVATE_SITE_PASSWORD`가 없을 때 쓰는 대체 게이트 |
| `MAX_UPLOAD_BYTES` | 기본 15MB. Vercel 서버리스 요청 본문은 약 4.5MB 제한 |
| `AI_DAILY_REQUEST_LIMIT` | 기본 250 |
| `AUTH_MAX_ATTEMPTS` | 기본 8 |

배포 전에 환경 변수를 먼저 넣고, 그다음 배포하세요.

```bash
npx vercel login
npx vercel link
npx vercel --prod
```

## 보안

- 비밀번호 bcrypt 해시, 세션은 httpOnly 쿠키 + SHA-256 토큰
- 모든 가족/파일/대화 접근은 서버에서 권한 검사 (IDOR 거부)
- Family AI 도구는 개인 메모리/파일과 1:1 DM을 읽지 않음
- DM API는 로그인·가족 구성원·ConversationMember·DIRECT 범위를 서버에서 검사 (IDOR 거부)
- CSRF(Origin), 로그인 brute-force 제한, 업로드 MIME/확장자/크기/경로 검사
- 프롬프트 인젝션 완화를 위해 검색된 파일 내용을 untrusted 블록으로 감쌈
- 감사 로그와 AI 사용량 로그 기록

## 문제 해결

- DB 연결 실패: PostgreSQL이 떠 있는지, `DATABASE_URL`이 맞는지 확인하세요. Next.js는 `.env.local`을 `.env`보다 우선하므로, `prisma db push`는 되고 앱만 실패하면 `.env.local`의 호스트를 확인하세요.
- AI 오류: 키를 확인하거나 `AI_PROVIDER=local`
- 웹 검색 오류: `WEB_SEARCH_API_KEY`가 없으면 가족 데이터 검색은 그대로 동작
- 파일 업로드 거부: PDF/TXT/DOCX/XLSX/CSV/이미지만, 기본 15MB
